export interface Document {
  id: string;
  title: string;
  description?: string;
  file_url: string;
  file_name: string;
  file_size?: number;
  file_type: string;
  mime_type?: string;
  thumbnail_url?: string;
  tags?: string[];
  user_id: string;
  views_count: number;
  likes_count: number;
  comments_count: number;
  created_at: string;
  updated_at: string;
  profiles?: {
    full_name?: string;
    username?: string;
    avatar_url?: string;
  };
}

// Keep PDF type for backward compatibility
export type PDF = Document;
