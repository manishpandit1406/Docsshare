import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { AuthProvider } from '@/contexts/AuthContext';
import Layout from '@/components/layout/Layout';
import HomePage from '@/pages/HomePage';
import ExplorePage from '@/pages/ExplorePage';
import UploadPDFPage from '@/pages/UploadPDFPage';
import ProfilePage from '@/pages/ProfilePage';
import PDFViewerPage from '@/pages/PDFViewerPage';
import LibraryPage from '@/pages/LibraryPage';
import AccountSettingsPage from '@/pages/AccountSettingsPage';
import DocumentEditor from '@/pages/DocumentEditor';

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router>
          <div className="min-h-screen bg-gray-50">
            <Routes>
              <Route path="/" element={<Layout><HomePage /></Layout>} />
              <Route path="/explore" element={<Layout><ExplorePage /></Layout>} />
              <Route path="/upload" element={<Layout><UploadPDFPage /></Layout>} />
              <Route path="/profile/:id" element={<Layout><ProfilePage /></Layout>} />
              <Route path="/pdf/:id" element={<Layout><PDFViewerPage /></Layout>} />
              <Route path="/library" element={<Layout><LibraryPage /></Layout>} />
              <Route path="/account" element={<Layout><AccountSettingsPage /></Layout>} />
              <Route path="/document-editor/:id" element={<Layout><DocumentEditor /></Layout>} />
            </Routes>
            <Toaster />
          </div>
        </Router>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
