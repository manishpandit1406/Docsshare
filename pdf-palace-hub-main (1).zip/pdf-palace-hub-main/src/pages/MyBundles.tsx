import React, { useState } from 'react';
import { BookOpen, Plus, FolderOpen, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import Layout from '@/components/layout/Layout';
import PDFBundleDialog from '@/components/PDFBundleDialog';
import LibraryCard from '@/components/LibraryCard';
import LibraryViewer from '@/components/LibraryViewer';
import { usePDFBundles } from '@/hooks/usePDFBundles';
import { toast } from '@/hooks/use-toast';

const MyBundles: React.FC = () => {
  const { bundles, isLoading, deleteBundle } = usePDFBundles();
  const [selectedBundle, setSelectedBundle] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredBundles = bundles.filter(bundle => 
    bundle.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (bundle.description?.toLowerCase().includes(searchQuery.toLowerCase()) ?? false)
  );

  const handleDeleteBundle = (bundleId: string, bundleName: string) => {
    if (window.confirm(`Are you sure you want to delete "${bundleName}"?`)) {
      deleteBundle(bundleId);
    }
  };

  const handleShareLibrary = async (bundleId: string, bundleName: string) => {
    const shareUrl = `${window.location.origin}/library/${bundleId}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: bundleName,
          text: `Check out this PDF library: ${bundleName}`,
          url: shareUrl,
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      try {
        await navigator.clipboard.writeText(shareUrl);
        toast({
          title: "Link copied",
          description: "Library link has been copied to clipboard"
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to copy link",
          variant: "destructive"
        });
      }
    }
  };

  const selectedBundleData = bundles.find(b => b.id === selectedBundle);

  if (selectedBundle && selectedBundleData) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <div className="mb-6">
            <Button
              variant="outline"
              onClick={() => setSelectedBundle(null)}
              className="mb-4"
            >
              ← Back to Libraries
            </Button>
          </div>
          <LibraryViewer 
            library={selectedBundleData}
            onBack={() => setSelectedBundle(null)}
          />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold">My PDF Libraries</h1>
            <p className="text-gray-600 mt-1">Organize your PDFs into playlists</p>
          </div>
          <PDFBundleDialog 
            trigger={
              <Button size="lg">
                <Plus className="w-5 h-5 mr-2" />
                Create Library
              </Button>
            }
          />
        </div>

        {/* Search Bar */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          <Input
            placeholder="Search your libraries..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 py-3"
          />
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
          </div>
        ) : filteredBundles.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-16">
              <FolderOpen className="w-20 h-20 text-gray-400 mb-6" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                {searchQuery ? 'No libraries found' : 'No libraries yet'}
              </h3>
              <p className="text-gray-500 text-center mb-6 max-w-md">
                {searchQuery 
                  ? 'Try adjusting your search terms to find your libraries'
                  : 'Create your first library to start organizing your PDFs like YouTube playlists'
                }
              </p>
              {!searchQuery && (
                <PDFBundleDialog 
                  trigger={
                    <Button size="lg">
                      <Plus className="w-5 h-5 mr-2" />
                      Create Your First Library
                    </Button>
                  }
                />
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {filteredBundles.map((bundle) => (
              <LibraryCard 
                key={bundle.id}
                library={bundle}
                onClick={() => setSelectedBundle(bundle.id)}
                showActions={true}
                onDelete={() => handleDeleteBundle(bundle.id, bundle.name)}
                onShare={() => handleShareLibrary(bundle.id, bundle.name)}
              />
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default MyBundles;
