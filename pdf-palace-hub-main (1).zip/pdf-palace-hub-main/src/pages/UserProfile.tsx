
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Calendar, MapPin, Link as LinkIcon, MessageCircle, UserPlus, UserMinus, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { useSubscriptions } from '@/hooks/useSubscriptions';
import Layout from '@/components/layout/Layout';
import ProfileTabs, { ProfileTabType } from '@/components/shared/ProfileTabs';
import AboutSection from '@/components/shared/AboutSection';
import MyPDFsSection from '@/components/dashboard/MyPDFsSection';
import MyLibrariesSection from '@/components/dashboard/MyLibrariesSection';

interface UserProfile {
  id: string;
  full_name?: string;
  username?: string;
  bio?: string;
  avatar_url?: string;
  cover_image_url?: string;
  created_at: string;
  website?: string;
  phone?: string;
  subscribers_count?: number;
}

const UserProfile = () => {
  const { userId } = useParams<{ userId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { subscriptions, subscribe, unsubscribe, isSubscribed } = useSubscriptions();
  
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [userPDFs, setUserPDFs] = useState<any[]>([]);
  const [userStats, setUserStats] = useState({
    totalViews: 0,
    totalLikes: 0,
    totalComments: 0
  });
  const [subscribersCount, setSubscribersCount] = useState(0);
  const [activeTab, setActiveTab] = useState<ProfileTabType>('pdfs');

  const isOwnProfile = user?.id === userId;
  const isUserSubscribed = userId ? isSubscribed(userId) : false;

  useEffect(() => {
    if (userId) {
      fetchUserProfile();
      fetchUserPDFs();
      fetchSubscribersCount();
    }
  }, [userId]);

  const fetchUserProfile = async () => {
    if (!userId) return;

    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) throw error;
      setProfile(data);
    } catch (error) {
      console.error('Error fetching user profile:', error);
      toast({
        title: "Error",
        description: "Failed to load user profile",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchUserPDFs = async () => {
    if (!userId) return;

    try {
      const { data: pdfs, error } = await supabase
        .from('pdfs')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setUserPDFs(pdfs || []);

      // Calculate stats
      const totalViews = pdfs?.reduce((sum, pdf) => sum + (pdf.views_count || 0), 0) || 0;
      const totalLikes = pdfs?.reduce((sum, pdf) => sum + (pdf.likes_count || 0), 0) || 0;
      const totalComments = pdfs?.reduce((sum, pdf) => sum + (pdf.comments_count || 0), 0) || 0;

      setUserStats({ totalViews, totalLikes, totalComments });
    } catch (error) {
      console.error('Error fetching user PDFs:', error);
    }
  };

  const fetchSubscribersCount = async () => {
    if (!userId) return;

    try {
      const { count, error } = await supabase
        .from('user_subscriptions')
        .select('*', { count: 'exact', head: true })
        .eq('subscribed_to_id', userId);

      if (error) throw error;
      setSubscribersCount(count || 0);
    } catch (error) {
      console.error('Error fetching subscribers count:', error);
    }
  };

  const handleSubscribe = async () => {
    if (!user || !userId) {
      navigate('/auth');
      return;
    }

    try {
      if (isUserSubscribed) {
        await unsubscribe(userId);
        setSubscribersCount(prev => prev - 1);
        toast({
          title: "Unsubscribed",
          description: "You have unsubscribed from this user"
        });
      } else {
        await subscribe(userId);
        setSubscribersCount(prev => prev + 1);
        toast({
          title: "Subscribed",
          description: "You are now subscribed to this user"
        });
      }
    } catch (error) {
      console.error('Error updating subscription:', error);
      toast({
        title: "Error",
        description: "Failed to update subscription",
        variant: "destructive"
      });
    }
  };

  const handleDeletePDF = async (pdfId: string) => {
    if (window.confirm('Are you sure you want to delete this PDF?')) {
      try {
        const { error } = await supabase
          .from('pdfs')
          .delete()
          .eq('id', pdfId);

        if (error) throw error;

        setUserPDFs(prev => prev.filter(pdf => pdf.id !== pdfId));
        toast({
          title: "Success",
          description: "PDF deleted successfully"
        });
      } catch (error) {
        console.error('Error deleting PDF:', error);
        toast({
          title: "Error",
          description: "Failed to delete PDF",
          variant: "destructive"
        });
      }
    }
  };

  const handleNavigation = (path: string) => {
    navigate(path);
  };

  const handleViewProfile = (userId: string) => {
    navigate(`/profile/${userId}`);
  };

  const getAvatarUrl = (avatarUrl?: string) => {
    if (!avatarUrl) return undefined;
    
    if (avatarUrl.startsWith('http')) {
      return avatarUrl;
    }
    
    if (avatarUrl.startsWith('avatars/')) {
      const { data } = supabase.storage
        .from('avatars')
        .getPublicUrl(avatarUrl);
      return data.publicUrl;
    }
    
    return avatarUrl;
  };

  const getUserInitials = (profile: UserProfile) => {
    if (profile.full_name) {
      return profile.full_name.split(' ').map(name => name[0]).join('').slice(0, 2).toUpperCase();
    }
    if (profile.username) {
      return profile.username.slice(0, 2).toUpperCase();
    }
    return 'U';
  };

  if (loading) {
    return (
      <Layout>
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (!profile) {
    return (
      <Layout>
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center py-12">
              <h1 className="text-2xl font-bold mb-4">User not found</h1>
              <Button onClick={() => navigate('/')}>
                Go Back Home
              </Button>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          {/* Profile Header */}
          <Card className="relative overflow-hidden">
            {/* Cover Image */}
            <div className="h-48 bg-gradient-to-r from-blue-500 to-purple-600">
              {profile.cover_image_url && (
                <img
                  src={profile.cover_image_url}
                  alt="Cover"
                  className="w-full h-full object-cover"
                />
              )}
            </div>

            <CardContent className="relative -mt-16 pb-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-end space-y-4 sm:space-y-0 sm:space-x-6">
                {/* Avatar */}
                <Avatar className="w-32 h-32 border-4 border-white shadow-lg">
                  <AvatarImage src={getAvatarUrl(profile.avatar_url)} />
                  <AvatarFallback className="bg-gray-500 text-white text-2xl">
                    {getUserInitials(profile)}
                  </AvatarFallback>
                </Avatar>

                {/* Profile Info */}
                <div className="flex-1 min-w-0">
                  <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                    {profile.full_name || profile.username || 'Anonymous User'}
                  </h1>
                  {profile.username && (
                    <p className="text-gray-600 dark:text-gray-400">@{profile.username}</p>
                  )}
                  {profile.bio && (
                    <p className="mt-2 text-gray-700 dark:text-gray-300">{profile.bio}</p>
                  )}

                  {/* Profile Details */}
                  <div className="flex flex-wrap items-center gap-4 mt-4 text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center space-x-1">
                      <Calendar className="w-4 h-4" />
                      <span>Joined {new Date(profile.created_at).toLocaleDateString()}</span>
                    </div>
                    {profile.website && (
                      <a
                        href={profile.website.startsWith('http') ? profile.website : `https://${profile.website}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center space-x-1 text-blue-600 hover:text-blue-700"
                      >
                        <LinkIcon className="w-4 h-4" />
                        <span>Website</span>
                      </a>
                    )}
                    <div className="flex items-center space-x-1">
                      <UserPlus className="w-4 h-4" />
                      <span>{subscribersCount} subscribers</span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex space-x-3">
                  {!isOwnProfile && user && (
                    <>
                      <Button
                        onClick={handleSubscribe}
                        variant={isUserSubscribed ? "outline" : "default"}
                        className="flex items-center space-x-2"
                      >
                        {isUserSubscribed ? <UserMinus className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
                        <span>{isUserSubscribed ? 'Unsubscribe' : 'Subscribe'}</span>
                      </Button>
                      <Button variant="outline" className="flex items-center space-x-2">
                        <MessageCircle className="w-4 h-4" />
                        <span>Message</span>
                      </Button>
                    </>
                  )}
                  
                  {isOwnProfile && (
                    <Button
                      onClick={() => navigate('/profile-settings')}
                      variant="outline"
                      className="flex items-center space-x-2"
                    >
                      <Settings className="w-4 h-4" />
                      <span>Edit Profile</span>
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Profile Tabs */}
          <ProfileTabs
            activeTab={activeTab}
            onTabChange={setActiveTab}
          />

          {/* Tab Content */}
          <div className="grid grid-cols-1 gap-8">
            {activeTab === 'pdfs' && (
              <MyPDFsSection
                loading={false}
                userPDFs={userPDFs}
                onNavigate={handleNavigation}
                onDeletePDF={handleDeletePDF}
                onViewProfile={handleViewProfile}
              />
            )}

            {activeTab === 'libraries' && (
              <MyLibrariesSection />
            )}

            {activeTab === 'about' && (
              <AboutSection
                profile={profile}
                isOwnProfile={isOwnProfile}
                totalPDFs={userPDFs.length}
                totalViews={userStats.totalViews}
                totalLikes={userStats.totalLikes}
                subscribersCount={subscribersCount}
              />
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default UserProfile;
