
import React, { useState, useCallback } from 'react';
import { FileText, Eye, Heart, MessageCircle, TrendingUp, Clock, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { usePDFs } from '@/hooks/usePDFs';
import Layout from '@/components/layout/Layout';
import PDFErrorDisplay from '@/components/PDFErrorBoundary';
import PDFCard from '@/components/PDFCard';

const Explore = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { pdfs, loading, error, searchPDFs } = usePDFs();
  const [activeTab, setActiveTab] = useState('recent');
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = useCallback((query: string) => {
    setSearchQuery(query);
    searchPDFs(query);
  }, [searchPDFs]);

  const handleViewPDF = useCallback((pdf: any) => {
    navigate(`/pdf/${pdf.id}`);
  }, [navigate]);

  const handleLike = useCallback(async (pdfId: string) => {
    if (!user) {
      navigate('/auth');
      return;
    }
    // TODO: Implement like functionality
    console.log('Like PDF:', pdfId);
  }, [user, navigate]);

  const filteredPDFs = useCallback(() => {
    switch (activeTab) {
      case 'trending':
        return [...pdfs].sort((a, b) => b.likes_count - a.likes_count);
      case 'popular':
        return [...pdfs].sort((a, b) => b.views_count - a.views_count);
      default:
        return pdfs;
    }
  }, [pdfs, activeTab]);

  if (error) {
    return (
      <Layout>
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-8">
          <div className="max-w-4xl mx-auto">
            <PDFErrorDisplay 
              error={error} 
              onRetry={() => searchPDFs(searchQuery)}
              type="general"
            />
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout
      showSearchBar={true}
      onSearch={handleSearch}
      searchPlaceholder="Search PDFs or users..."
    >
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Title */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
              Explore PDFs
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              Discover amazing PDFs shared by the community
            </p>
          </div>

          {/* Popular Tags Section - Moved to top */}
          <Card className="mb-8">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4 flex items-center">
                <Tag className="w-5 h-5 mr-2" />
                Popular Tags
              </h3>
              <div className="flex flex-wrap gap-2">
                {['Education', 'Technology', 'Science', 'Business', 'Design', 'Programming', 'Research', 'Tutorial'].map((tag) => (
                  <Badge 
                    key={tag} 
                    variant="outline" 
                    className="cursor-pointer hover:bg-blue-50 hover:border-blue-300"
                    onClick={() => handleSearch(tag)}
                  >
                    {tag}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
            <TabsList className="grid w-full max-w-md grid-cols-3">
              <TabsTrigger value="recent" className="flex items-center space-x-2">
                <Clock size={16} />
                <span>Recent</span>
              </TabsTrigger>
              <TabsTrigger value="trending" className="flex items-center space-x-2">
                <TrendingUp size={16} />
                <span>Trending</span>
              </TabsTrigger>
              <TabsTrigger value="popular" className="flex items-center space-x-2">
                <Eye size={16} />
                <span>Popular</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="mt-6">
              {loading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(6)].map((_, i) => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="p-6">
                        <div className="aspect-[3/4] bg-gray-200 dark:bg-gray-700 rounded-lg mb-4"></div>
                        <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                        <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
                        <div className="flex space-x-2">
                          <div className="h-6 w-16 bg-gray-200 dark:bg-gray-700 rounded"></div>
                          <div className="h-6 w-16 bg-gray-200 dark:bg-gray-700 rounded"></div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : filteredPDFs().length === 0 ? (
                <Card className="p-12 text-center">
                  <CardContent>
                    <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <h4 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                      {searchQuery ? 'No PDFs found' : 'No PDFs yet'}
                    </h4>
                    <p className="text-gray-600 dark:text-gray-400 mb-6">
                      {searchQuery 
                        ? `No results found for "${searchQuery}". Try different keywords.`
                        : 'Be the first to share a PDF with the community!'
                      }
                    </p>
                    {!user && !searchQuery && (
                      <Button onClick={() => navigate('/auth')}>
                        Sign In to Upload
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredPDFs().map((pdf) => (
                    <PDFCard
                      key={pdf.id}
                      pdf={pdf}
                      onView={handleViewPDF}
                      onLike={handleLike}
                      showActions={true}
                    />
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </Layout>
  );
};

export default Explore;
