
import React from 'react';
import { Check, Star, Zap, Shield, Crown, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import Layout from '@/components/layout/Layout';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

const UpgradePro: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const plans = [
    {
      name: 'Free',
      price: '$0',
      period: 'forever',
      description: 'Perfect for getting started',
      features: [
        'Upload up to 10 documents',
        'Basic search functionality',
        '100MB storage',
        'Public sharing',
        'Basic support'
      ],
      current: true,
      popular: false
    },
    {
      name: 'Pro',
      price: '$9.99',
      period: 'per month',
      description: 'For professionals and power users',
      features: [
        'Unlimited document uploads',
        'Advanced search with AI',
        '10GB storage',
        'Priority support',
        'Custom branding',
        'Analytics dashboard',
        'Bulk operations',
        'Advanced sharing controls'
      ],
      current: false,
      popular: true
    },
    {
      name: 'Enterprise',
      price: '$29.99',
      period: 'per month',
      description: 'For teams and organizations',
      features: [
        'Everything in Pro',
        'Unlimited storage',
        'Team collaboration',
        'Admin controls',
        'API access',
        'Custom integrations',
        '24/7 support',
        'SLA guarantee'
      ],
      current: false,
      popular: false
    }
  ];

  const benefits = [
    {
      icon: <Zap className="w-6 h-6" />,
      title: 'Lightning Fast',
      description: 'Upload and access your documents instantly with our optimized platform'
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: 'Secure & Private',
      description: 'Enterprise-grade security with end-to-end encryption'
    },
    {
      icon: <Star className="w-6 h-6" />,
      title: 'Premium Features',
      description: 'Advanced search, AI-powered insights, and collaboration tools'
    }
  ];

  const handleUpgrade = (planName: string) => {
    if (!user) {
      navigate('/auth');
      return;
    }
    // TODO: Implement Stripe payment integration
    console.log(`Upgrading to ${planName}`);
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
        {/* Hero Section */}
        <div className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-purple-600/10" />
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <Crown className="w-16 h-16 text-yellow-500" />
              </div>
              <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-6">
                Upgrade to Pro
              </h1>
              <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
                Unlock unlimited potential with advanced features, priority support, and enhanced collaboration tools
              </p>
              <div className="flex justify-center items-center space-x-4 mb-8">
                <Badge variant="outline" className="bg-white/50">
                  <Star className="w-4 h-4 mr-1 text-yellow-500" />
                  Trusted by 10,000+ users
                </Badge>
                <Badge variant="outline" className="bg-white/50">
                  99.9% Uptime
                </Badge>
              </div>
            </div>
          </div>
        </div>

        {/* Benefits Section */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {benefits.map((benefit, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex justify-center mb-4 text-blue-600">
                    {benefit.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{benefit.title}</h3>
                  <p className="text-gray-600">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Pricing Cards */}
          <div className="grid md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <Card 
                key={index} 
                className={`relative hover:shadow-xl transition-shadow ${
                  plan.popular ? 'ring-2 ring-blue-500 scale-105' : ''
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-blue-500 hover:bg-blue-600">
                      Most Popular
                    </Badge>
                  </div>
                )}
                
                <CardHeader className="text-center pb-4">
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <div className="mt-4">
                    <span className="text-4xl font-bold">{plan.price}</span>
                    <span className="text-gray-500">/{plan.period}</span>
                  </div>
                  <p className="text-gray-600 mt-2">{plan.description}</p>
                </CardHeader>
                
                <CardContent className="pt-0">
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center">
                        <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button
                    onClick={() => handleUpgrade(plan.name)}
                    disabled={plan.current}
                    className={`w-full ${
                      plan.popular 
                        ? 'bg-blue-600 hover:bg-blue-700' 
                        : plan.current 
                        ? 'bg-gray-300 cursor-not-allowed'
                        : 'bg-gray-800 hover:bg-gray-700'
                    }`}
                  >
                    {plan.current ? 'Current Plan' : `Upgrade to ${plan.name}`}
                    {!plan.current && <ArrowRight className="w-4 h-4 ml-2" />}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* FAQ Section */}
          <div className="mt-20 text-center">
            <h2 className="text-3xl font-bold mb-8">Frequently Asked Questions</h2>
            <div className="max-w-3xl mx-auto space-y-6">
              <Card>
                <CardContent className="p-6 text-left">
                  <h3 className="font-semibold mb-2">Can I cancel anytime?</h3>
                  <p className="text-gray-600">Yes, you can cancel your subscription at any time. Your access will continue until the end of your billing period.</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-left">
                  <h3 className="font-semibold mb-2">What happens to my data if I downgrade?</h3>
                  <p className="text-gray-600">Your data remains safe. However, you may lose access to certain premium features until you upgrade again.</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-left">
                  <h3 className="font-semibold mb-2">Do you offer discounts for students?</h3>
                  <p className="text-gray-600">Yes! We offer 50% off for verified students and educational institutions. Contact support for details.</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default UpgradePro;
