import React, { useState, useEffect } from 'react';
import { X, Download, Heart, MessageCircle, Bookmark, Share2, MoreHorizontal, Reply, Trash2, ChevronDown, ChevronUp, Maximize, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { usePDFInteractions } from '@/hooks/usePDFInteractions';
import { useWishlist } from '@/hooks/useWishlist';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import EmojiPicker from '@/components/EmojiPicker';
import FullscreenPDFViewer from '@/components/FullscreenPDFViewer';
import PDFBundleDialog from '@/components/PDFBundleDialog';
import type { PDF } from '@/types/pdf';

interface PDFViewerProps {
  pdf: PDF | null;
  isOpen: boolean;
  onClose: () => void;
}

interface Comment {
  id: string;
  content: string;
  created_at: string;
  user_id: string;
  profiles: {
    full_name?: string;
    username?: string;
    avatar_url?: string;
  };
  replies_count: number;
}

interface Reply {
  id: string;
  content: string;
  created_at: string;
  user_id: string;
  profiles: {
    full_name?: string;
    username?: string;
    avatar_url?: string;
  };
}

const PDFViewer: React.FC<PDFViewerProps> = ({ pdf, isOpen, onClose }) => {
  const [comment, setComment] = useState('');
  const [showReplies, setShowReplies] = useState<{ [key: string]: boolean }>({});
  const [replies, setReplies] = useState<{ [key: string]: Reply[] }>({});
  const [replyText, setReplyText] = useState<{ [key: string]: string }>({});
  const [loadingReplies, setLoadingReplies] = useState<{ [key: string]: boolean }>({});
  const [showShareMenu, setShowShareMenu] = useState(false);
  const [showFullscreen, setShowFullscreen] = useState(false);
  const { user } = useAuth();
  const { hasLiked, comments, loading, toggleLike, addComment, deleteComment } = usePDFInteractions(pdf?.id || '');
  const { isInWishlist, addToWishlist, removeFromWishlist } = useWishlist();

  // Close fullscreen and return to PDF viewer dialog
  const handleFullscreenClose = () => {
    setShowFullscreen(false);
    // The dialog will automatically reopen since isOpen is still true
  };

  // Handle main dialog close - this should navigate back properly
  const handleMainClose = () => {
    onClose(); // This will trigger navigation back to previous page
  };

  const handleAddComment = async () => {
    if (!comment.trim()) return;
    await addComment(comment);
    setComment('');
  };

  const handleWishlistToggle = async () => {
    if (!pdf) return;
    
    if (isInWishlist(pdf.id)) {
      await removeFromWishlist(pdf.id);
    } else {
      await addToWishlist(pdf.id);
    }
  };

  const handleDeleteComment = async (commentId: string) => {
    if (window.confirm('Are you sure you want to delete this comment?')) {
      await deleteComment(commentId);
    }
  };

  const getUserDisplayName = (profiles: any) => {
    if (profiles?.full_name) return profiles.full_name;
    if (profiles?.username) return profiles.username;
    return 'Anonymous User';
  };

  const getUserInitials = (profiles: any) => {
    const displayName = getUserDisplayName(profiles);
    if (displayName === 'Anonymous User') return 'A';
    return displayName.split(' ').map((name: string) => name[0]).join('').slice(0, 2).toUpperCase();
  };

  const getAvatarUrl = (avatarUrl?: string) => {
    if (!avatarUrl) return undefined;
    
    if (avatarUrl.startsWith('http')) {
      return avatarUrl;
    }
    
    if (avatarUrl.startsWith('avatars/')) {
      const { data } = supabase.storage
        .from('avatars')
        .getPublicUrl(avatarUrl);
      return data.publicUrl;
    }
    
    return avatarUrl;
  };

  const loadReplies = async (commentId: string) => {
    if (loadingReplies[commentId]) return;
    
    setLoadingReplies(prev => ({ ...prev, [commentId]: true }));
    
    try {
      const { data: repliesData, error } = await supabase
        .from('pdf_comment_replies')
        .select('id, content, created_at, user_id')
        .eq('comment_id', commentId)
        .order('created_at', { ascending: true });

      if (error) throw error;

      // Fetch profiles for each reply separately
      const repliesWithProfiles = await Promise.all(
        (repliesData || []).map(async (reply) => {
          try {
            const { data: profileData } = await supabase
              .from('profiles')
              .select('full_name, username, avatar_url')
              .eq('id', reply.user_id)
              .maybeSingle();

            return {
              ...reply,
              profiles: profileData || { full_name: undefined, username: undefined, avatar_url: undefined }
            };
          } catch (error) {
            console.error('Error fetching profile for reply:', error);
            return {
              ...reply,
              profiles: { full_name: undefined, username: undefined, avatar_url: undefined }
            };
          }
        })
      );

      setReplies(prev => ({ ...prev, [commentId]: repliesWithProfiles }));
    } catch (error) {
      console.error('Error loading replies:', error);
      toast({
        title: "Error",
        description: "Failed to load replies",
        variant: "destructive"
      });
    } finally {
      setLoadingReplies(prev => ({ ...prev, [commentId]: false }));
    }
  };

  const toggleReplies = async (commentId: string) => {
    const isShowing = showReplies[commentId];
    
    if (!isShowing && !replies[commentId]) {
      await loadReplies(commentId);
    }
    
    setShowReplies(prev => ({
      ...prev,
      [commentId]: !isShowing
    }));
  };

  const addReply = async (commentId: string) => {
    const content = replyText[commentId]?.trim();
    if (!content || !user) return;

    try {
      const { error } = await supabase
        .from('pdf_comment_replies')
        .insert({
          comment_id: commentId,
          content,
          user_id: user.id
        });

      if (error) throw error;

      setReplyText(prev => ({ ...prev, [commentId]: '' }));
      await loadReplies(commentId);
      
      toast({
        title: "Reply added",
        description: "Your reply has been posted"
      });
    } catch (error) {
      console.error('Error adding reply:', error);
      toast({
        title: "Error",
        description: "Failed to add reply",
        variant: "destructive"
      });
    }
  };

  const handleShare = (platform: string) => {
    if (!pdf) return;

    const url = window.location.href;
    const text = `Check out this PDF: ${pdf.title}`;

    switch (platform) {
      case 'copy':
        navigator.clipboard.writeText(url);
        toast({ title: "Link copied", description: "PDF link copied to clipboard" });
        break;
      case 'facebook':
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
        break;
      case 'twitter':
        window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`, '_blank');
        break;
      case 'linkedin':
        window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`, '_blank');
        break;
    }
    setShowShareMenu(false);
  };

  const handleFullscreen = () => {
    setShowFullscreen(true);
  };

  if (!pdf) return null;

  return (
    <>
      <Dialog open={isOpen && !showFullscreen} onOpenChange={handleMainClose}>
        <DialogContent className="max-w-6xl h-[90vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold">{pdf.title}</h2>
                <p className="text-sm text-gray-600 mt-1">{pdf.description}</p>
              </div>
              <div className="flex items-center space-x-2">
                {user && (
                  <>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={toggleLike}
                      disabled={loading}
                      className={hasLiked ? "text-red-600" : ""}
                    >
                      <Heart className={`w-4 h-4 ${hasLiked ? "fill-current" : ""}`} />
                      <span className="ml-1">{pdf.likes_count}</span>
                    </Button>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleWishlistToggle}
                      className={isInWishlist(pdf.id) ? "text-blue-600" : ""}
                    >
                      <Bookmark className={`w-4 h-4 ${isInWishlist(pdf.id) ? "fill-current" : ""}`} />
                    </Button>

                    <PDFBundleDialog 
                      pdfId={pdf.id}
                      trigger={
                        <Button variant="outline" size="sm">
                          <BookOpen className="w-4 h-4" />
                        </Button>
                      }
                    />
                  </>
                )}
                
                <Button variant="outline" size="sm" onClick={handleFullscreen}>
                  <Maximize className="w-4 h-4 mr-1" />
                  Fullscreen
                </Button>
                
                <DropdownMenu open={showShareMenu} onOpenChange={setShowShareMenu}>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Share2 className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleShare('copy')}>
                      Copy Link
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleShare('facebook')}>
                      Share on Facebook
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleShare('twitter')}>
                      Share on Twitter
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleShare('linkedin')}>
                      Share on LinkedIn
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                
                <Button variant="outline" size="sm">
                  <Download className="w-4 h-4" />
                </Button>
              </div>
            </DialogTitle>
          </DialogHeader>

          <div className="flex-1 flex gap-4 overflow-hidden">
            {/* PDF Viewer */}
            <div className="flex-1 bg-gray-100 rounded-lg overflow-hidden">
              <iframe
                src={`${pdf.file_url}#toolbar=0&navpanes=0&scrollbar=1`}
                className="w-full h-full"
                title={pdf.title}
              />
            </div>

            {/* Comments Section */}
            <div className="w-80 flex flex-col space-y-4">
              <div className="flex items-center space-x-4 text-sm text-gray-600">
                <span className="flex items-center space-x-1">
                  <MessageCircle className="w-4 h-4" />
                  <span>{pdf.comments_count} comments</span>
                </span>
                <span>{pdf.views_count} views</span>
              </div>

              {pdf.tags && pdf.tags.length > 0 && (
                <div className="flex flex-wrap gap-1">
                  {pdf.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}

              {user && (
                <div className="space-y-2">
                  <div className="relative">
                    <Textarea
                      placeholder="Add a comment..."
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      className="resize-none pr-10"
                      rows={2}
                    />
                    <EmojiPicker onEmojiSelect={(emoji) => setComment(prev => prev + emoji)} />
                  </div>
                  <Button onClick={handleAddComment} size="sm" className="w-full">
                    Post Comment
                  </Button>
                </div>
              )}

              <div className="flex-1 overflow-y-auto space-y-3">
                {comments.map((comment) => (
                  <Card key={comment.id}>
                    <CardContent className="p-3">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <Avatar className="w-6 h-6">
                            <AvatarImage src={getAvatarUrl(comment.profiles?.avatar_url)} />
                            <AvatarFallback className="bg-gray-500 text-white text-xs">
                              {getUserInitials(comment.profiles)}
                            </AvatarFallback>
                          </Avatar>
                          <span className="font-medium text-sm">
                            {getUserDisplayName(comment.profiles)}
                          </span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <span className="text-xs text-gray-500">
                            {new Date(comment.created_at).toLocaleDateString()}
                          </span>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                                <MoreHorizontal className="w-3 h-3" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => toggleReplies(comment.id)}>
                                <Reply className="w-4 h-4 mr-2" />
                                {showReplies[comment.id] ? 'Hide Replies' : `View Replies (${comment.replies_count})`}
                              </DropdownMenuItem>
                              {user && comment.user_id === user.id && (
                                <DropdownMenuItem 
                                  onClick={() => handleDeleteComment(comment.id)}
                                  className="text-red-600"
                                >
                                  <Trash2 className="w-4 h-4 mr-2" />
                                  Delete
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                      <p className="text-sm text-gray-700 mb-2">{comment.content}</p>
                      
                      {comment.replies_count > 0 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleReplies(comment.id)}
                          className="text-xs text-blue-600 hover:text-blue-800 p-0 h-auto"
                        >
                          {showReplies[comment.id] ? (
                            <>
                              <ChevronUp className="w-3 h-3 mr-1" />
                              Hide {comment.replies_count} replies
                            </>
                          ) : (
                            <>
                              <ChevronDown className="w-3 h-3 mr-1" />
                              Show {comment.replies_count} replies
                            </>
                          )}
                        </Button>
                      )}

                      {showReplies[comment.id] && (
                        <div className="mt-3 ml-4 space-y-2 border-l-2 border-gray-100 pl-3">
                          {loadingReplies[comment.id] ? (
                            <div className="text-xs text-gray-500">Loading replies...</div>
                          ) : (
                            replies[comment.id]?.map((reply) => (
                              <div key={reply.id} className="bg-gray-50 rounded p-2">
                                <div className="flex items-center space-x-2 mb-1">
                                  <Avatar className="w-4 h-4">
                                    <AvatarImage src={getAvatarUrl(reply.profiles?.avatar_url)} />
                                    <AvatarFallback className="bg-gray-500 text-white text-xs">
                                      {getUserInitials(reply.profiles)}
                                    </AvatarFallback>
                                  </Avatar>
                                  <span className="font-medium text-xs">
                                    {getUserDisplayName(reply.profiles)}
                                  </span>
                                  <span className="text-xs text-gray-500">
                                    {new Date(reply.created_at).toLocaleDateString()}
                                  </span>
                                </div>
                                <p className="text-xs text-gray-700">{reply.content}</p>
                              </div>
                            ))
                          )}
                          
                          {user && (
                            <div className="space-y-1">
                              <Textarea
                                placeholder="Write a reply..."
                                value={replyText[comment.id] || ''}
                                onChange={(e) => setReplyText(prev => ({ ...prev, [comment.id]: e.target.value }))}
                                className="resize-none text-xs"
                                rows={1}
                              />
                              <Button 
                                onClick={() => addReply(comment.id)}
                                size="sm" 
                                className="h-6 text-xs px-2"
                              >
                                Reply
                              </Button>
                            </div>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
                
                {comments.length === 0 && (
                  <p className="text-center text-gray-500 text-sm">No comments yet</p>
                )}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <FullscreenPDFViewer
        pdf={pdf}
        isOpen={showFullscreen}
        onClose={handleFullscreenClose}
      />
    </>
  );
};

export default PDFViewer;
