
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Home from './Home';

const Index = () => {
  return <Home />;
};

export default Index;
