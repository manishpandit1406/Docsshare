import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Search as SearchIcon, FileText, User, BookOpen, Filter, Loader2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import Layout from '@/components/layout/Layout';
import DocumentCard from '@/components/DocumentCard';
import LibraryCard from '@/components/LibraryCard';
import UserStripeCard from '@/components/UserStripeCard';
import { useDocuments } from '@/hooks/useDocuments';
import { usePDFBundles } from '@/hooks/usePDFBundles';
import { useTrendingSearches } from '@/hooks/useTrendingSearches';
import { supabase } from '@/integrations/supabase/client';

interface UserProfile {
  id: string;
  full_name?: string;
  username?: string;
  avatar_url?: string;
  bio?: string;
  subscribers_count?: number;
}

const Search: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const query = searchParams.get('q') || '';
  const type = searchParams.get('type') || 'all';
  
  const [searchQuery, setSearchQuery] = useState(query);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(false);
  const [publicLibraries, setPublicLibraries] = useState<any[]>([]);
  const { saveSearch } = useTrendingSearches();
  
  const { documents, searchDocuments, loading: documentsLoading } = useDocuments();

  // Filter results based on query with highlighted terms
  const filteredDocuments = documents.filter(doc => 
    doc.title.toLowerCase().includes(query.toLowerCase()) ||
    doc.description?.toLowerCase().includes(query.toLowerCase())
  );

  useEffect(() => {
    if (query) {
      setLoading(true);
      searchDocuments(query);
      searchUsers(query);
      searchPublicLibraries(query);
      saveSearch(query);
    }
  }, [query]);

  const searchUsers = async (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setUsers([]);
      return;
    }
    
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name, username, avatar_url, bio, subscribers_count')
        .or(`full_name.ilike.%${searchQuery}%, username.ilike.%${searchQuery}%`)
        .limit(20);

      if (error) throw error;
      setUsers(data || []);
    } catch (error) {
      console.error('Error searching users:', error);
      setUsers([]);
    }
  };

  const searchPublicLibraries = async (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setPublicLibraries([]);
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('pdf_library_bundles')
        .select(`
          *,
          pdf_count:pdf_bundle_items(count)
        `)
        .eq('is_public', true)
        .or(`name.ilike.%${searchQuery}%, description.ilike.%${searchQuery}%`)
        .limit(20);

      if (error) throw error;
      
      const transformedData = data.map(bundle => ({
        ...bundle,
        pdf_count: Array.isArray(bundle.pdf_count) ? bundle.pdf_count.length : bundle.pdf_count
      }));
      
      setPublicLibraries(transformedData || []);
    } catch (error) {
      console.error('Error searching public libraries:', error);
      setPublicLibraries([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (newQuery: string) => {
    setSearchQuery(newQuery);
    if (newQuery.trim()) {
      setSearchParams({ q: newQuery, type });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && searchQuery.trim()) {
      handleSearch(searchQuery);
    }
  };

  const handleTypeChange = (newType: string) => {
    setSearchParams({ q: query, type: newType });
  };

  const handleDocumentView = (doc: any) => {
    // All documents now navigate to document viewer
    navigate(`/document/${doc.id}`);
  };

  const highlightText = (text: string, highlight: string) => {
    if (!highlight.trim()) return text;
    
    const regex = new RegExp(`(${highlight})`, 'gi');
    const parts = text.split(regex);
    
    return parts.map((part, index) => 
      regex.test(part) ? (
        <mark key={index} className="bg-yellow-200 px-1 rounded">
          {part}
        </mark>
      ) : part
    );
  };

  const totalResults = filteredDocuments.length + publicLibraries.length + users.length;
  const isLoading = loading || documentsLoading;

  return (
    <Layout showSearchBar={false}>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Enhanced Search Header */}
          <div className="mb-8">
            <div className="relative mb-6">
              <SearchIcon className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-6 h-6" />
              <Input
                placeholder="Search documents, libraries, or users..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={handleKeyPress}
                className="pl-12 py-4 text-lg bg-white shadow-lg border-2 border-transparent focus:border-blue-500 rounded-xl"
              />
              {isLoading && (
                <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
                  <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
                </div>
              )}
            </div>
            
            {query && (
              <div className="flex items-center justify-between bg-white rounded-lg p-4 shadow-sm">
                <div>
                  <p className="text-gray-700 text-lg">
                    <span className="font-semibold text-blue-600">{totalResults}</span> results for 
                    <span className="font-medium ml-1">"{highlightText(query, query)}"</span>
                  </p>
                  {isLoading && (
                    <p className="text-sm text-gray-500 mt-1 flex items-center">
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      Searching...
                    </p>
                  )}
                </div>
                <Button variant="outline" size="sm" className="flex items-center space-x-2">
                  <Filter className="w-4 h-4" />
                  <span>Filters</span>
                </Button>
              </div>
            )}
          </div>

          {query ? (
            <Tabs value={type} onValueChange={handleTypeChange} className="w-full">
              <TabsList className="grid w-full max-w-md grid-cols-4 mb-8 bg-white shadow-sm">
                <TabsTrigger value="all" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white">
                  All ({totalResults})
                </TabsTrigger>
                <TabsTrigger value="users" className="data-[state=active]:bg-green-500 data-[state=active]:text-white">
                  Users ({users.length})
                </TabsTrigger>
                <TabsTrigger value="libraries" className="data-[state=active]:bg-purple-500 data-[state=active]:text-white">
                  Libraries ({publicLibraries.length})
                </TabsTrigger>
                <TabsTrigger value="documents" className="data-[state=active]:bg-orange-500 data-[state=active]:text-white">
                  Documents ({filteredDocuments.length})
                </TabsTrigger>
              </TabsList>

              <TabsContent value="all" className="mt-6">
                {isLoading ? (
                  <div className="flex items-center justify-center py-12">
                    <Loader2 className="w-8 h-8 animate-spin text-blue-500 mr-3" />
                    <span className="text-gray-600">Searching for results...</span>
                  </div>
                ) : (
                  <div className="space-y-10">
                    {/* Users Section */}
                    {users.length > 0 && (
                      <div>
                        <div className="flex items-center justify-between mb-6">
                          <h3 className="text-2xl font-bold text-gray-900 flex items-center">
                            <User className="w-6 h-6 mr-3 text-green-500" />
                            Users
                            <Badge variant="secondary" className="ml-3">
                              {users.length}
                            </Badge>
                          </h3>
                          {users.length > 4 && (
                            <Button 
                              variant="outline" 
                              onClick={() => handleTypeChange('users')}
                              className="text-green-600 border-green-200 hover:bg-green-50"
                            >
                              View all users
                            </Button>
                          )}
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {users.slice(0, 4).map((user) => (
                            <UserStripeCard 
                              key={user.id}
                              profile={user}
                              onClick={() => navigate(`/profile/${user.id}`)}
                              compact={true}
                            />
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Libraries Section */}
                    {publicLibraries.length > 0 && (
                      <div>
                        <div className="flex items-center justify-between mb-6">
                          <h3 className="text-2xl font-bold text-gray-900 flex items-center">
                            <BookOpen className="w-6 h-6 mr-3 text-purple-500" />
                            Libraries
                            <Badge variant="secondary" className="ml-3">
                              {publicLibraries.length}
                            </Badge>
                          </h3>
                          {publicLibraries.length > 4 && (
                            <Button 
                              variant="outline" 
                              onClick={() => handleTypeChange('libraries')}
                              className="text-purple-600 border-purple-200 hover:bg-purple-50"
                            >
                              View all libraries
                            </Button>
                          )}
                        </div>
                        <div className="space-y-3">
                          {publicLibraries.slice(0, 4).map((library) => (
                            <LibraryCard 
                              key={library.id}
                              library={library}
                              onClick={() => navigate(`/library/${library.id}`)}
                              showActions={false}
                            />
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Documents Section */}
                    {filteredDocuments.length > 0 && (
                      <div>
                        <div className="flex items-center justify-between mb-6">
                          <h3 className="text-2xl font-bold text-gray-900 flex items-center">
                            <FileText className="w-6 h-6 mr-3 text-orange-500" />
                            Documents
                            <Badge variant="secondary" className="ml-3">
                              {filteredDocuments.length}
                            </Badge>
                          </h3>
                          {filteredDocuments.length > 8 && (
                            <Button 
                              variant="outline" 
                              onClick={() => handleTypeChange('documents')}
                              className="text-orange-600 border-orange-200 hover:bg-orange-50"
                            >
                              View all documents
                            </Button>
                          )}
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                          {filteredDocuments.slice(0, 12).map((doc) => (
                            <DocumentCard 
                              key={doc.id}
                              document={doc}
                              showActions={false}
                              compact={true}
                              onView={handleDocumentView}
                            />
                          ))}
                        </div>
                      </div>
                    )}

                    {totalResults === 0 && !isLoading && (
                      <Card className="p-16 text-center bg-white shadow-lg">
                        <CardContent>
                          <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                            <SearchIcon className="w-12 h-12 text-gray-400" />
                          </div>
                          <h3 className="text-2xl font-bold text-gray-900 mb-4">
                            No results found
                          </h3>
                          <p className="text-gray-600 mb-6 max-w-md mx-auto">
                            We couldn't find anything matching "{query}". Try different keywords or browse popular content.
                          </p>
                          <div className="flex flex-wrap gap-2 justify-center">
                            {['Technology', 'Education', 'Science', 'Business', 'Design'].map((tag) => (
                              <Badge 
                                key={tag} 
                                variant="outline" 
                                className="cursor-pointer hover:bg-blue-50 hover:border-blue-300"
                                onClick={() => handleSearch(tag)}
                              >
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="documents" className="mt-6">
                {filteredDocuments.length > 0 ? (
                  <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                    {filteredDocuments.map((doc) => (
                      <DocumentCard 
                        key={doc.id}
                        document={doc}
                        showActions={false}
                        compact={true}
                        onView={handleDocumentView}
                      />
                    ))}
                  </div>
                ) : (
                  <Card className="p-12 text-center bg-white shadow-lg">
                    <CardContent>
                      <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        No documents found
                      </h3>
                      <p className="text-gray-600">
                        No documents match your search query
                      </p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="libraries" className="mt-6">
                {publicLibraries.length > 0 ? (
                  <div className="space-y-3">
                    {publicLibraries.map((library) => (
                      <LibraryCard 
                        key={library.id}
                        library={library}
                        onClick={() => navigate(`/library/${library.id}`)}
                        showActions={false}
                      />
                    ))}
                  </div>
                ) : (
                  <Card className="p-12 text-center bg-white shadow-lg">
                    <CardContent>
                      <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        No libraries found
                      </h3>
                      <p className="text-gray-600">
                        No public libraries match your search query
                      </p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="users" className="mt-6">
                {users.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {users.map((user) => (
                      <UserStripeCard 
                        key={user.id}
                        profile={user}
                        onClick={() => navigate(`/profile/${user.id}`)}
                        compact={true}
                      />
                    ))}
                  </div>
                ) : (
                  <Card className="p-12 text-center bg-white shadow-lg">
                    <CardContent>
                      <User className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        No users found
                      </h3>
                      <p className="text-gray-600">
                        No users match your search query
                      </p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          ) : (
            <div className="text-center py-16">
              <div className="w-32 h-32 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-8">
                <SearchIcon className="w-16 h-16 text-blue-500" />
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Search PDFShare
              </h2>
              <p className="text-gray-600 mb-8 max-w-md mx-auto text-lg">
                Find documents, libraries, and users across the platform. Start typing to see results.
              </p>
              
              <div className="flex flex-wrap gap-3 justify-center">
                {['Technology', 'Education', 'Science', 'Business', 'Design', 'Research', 'Tutorial', 'Guide'].map((tag) => (
                  <Badge 
                    key={tag} 
                    variant="outline" 
                    className="cursor-pointer hover:bg-blue-50 hover:border-blue-300 text-base px-4 py-2"
                    onClick={() => handleSearch(tag)}
                  >
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default Search;
