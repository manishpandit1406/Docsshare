
import React from 'react';
import { Bookmark, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useWishlist } from '@/hooks/useWishlist';
import { usePDFs } from '@/hooks/usePDFs';
import { useNavigate } from 'react-router-dom';
import Layout from '@/components/layout/Layout';
import PDFCard from '@/components/PDFCard';

const Wishlist = () => {
  const navigate = useNavigate();
  const { wishlistItems, removeFromWishlist } = useWishlist();
  const { pdfs } = usePDFs();

  const wishlistPDFs = pdfs.filter(pdf => wishlistItems.includes(pdf.id));

  const handleViewPDF = (pdf: any) => {
    navigate(`/pdf/${pdf.id}`);
  };

  const handleLike = (pdfId: string) => {
    console.log('Like PDF:', pdfId);
  };

  const handleRemoveFromWishlist = async (pdfId: string) => {
    await removeFromWishlist(pdfId);
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold flex items-center">
              <Bookmark className="w-8 h-8 mr-3 text-blue-600" />
              My Wishlist
            </h1>
            <p className="text-gray-600 mt-1">PDFs you've saved for later</p>
          </div>

          {wishlistPDFs.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <Bookmark className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Your wishlist is empty</h3>
                <p className="text-gray-600 mb-6">
                  Start adding PDFs to your wishlist to keep track of documents you want to read later.
                </p>
                <Button onClick={() => navigate('/explore')}>
                  Explore PDFs
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {wishlistPDFs.map((pdf) => (
                <div key={pdf.id} className="relative">
                  <PDFCard
                    pdf={pdf}
                    onView={handleViewPDF}
                    onLike={handleLike}
                    showActions={false}
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleRemoveFromWishlist(pdf.id)}
                    className="absolute top-2 right-2 text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default Wishlist;
