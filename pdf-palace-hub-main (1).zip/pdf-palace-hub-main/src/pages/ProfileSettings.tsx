
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Menu } from 'lucide-react';
import Layout from '@/components/layout/Layout';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import SettingsSidebar from '@/components/settings/SettingsSidebar';
import ProfileSection from '@/components/settings/ProfileSection';
import AccountSection from '@/components/settings/AccountSection';
import NotificationsSection from '@/components/settings/NotificationsSection';
import AppearanceSection from '@/components/settings/AppearanceSection';
import WebsiteSection from '@/components/settings/WebsiteSection';
import ContentSection from '@/components/settings/ContentSection';
import SecuritySection from '@/components/settings/SecuritySection';
import PrivacySection from '@/components/settings/PrivacySection';
import DataSection from '@/components/settings/DataSection';

const ProfileSettings = () => {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState('profile');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const renderActiveSection = () => {
    switch (activeSection) {
      case 'profile':
        return <ProfileSection />;
      case 'account':
        return <AccountSection />;
      case 'notifications':
        return <NotificationsSection />;
      case 'appearance':
        return <AppearanceSection />;
      case 'website':
        return <WebsiteSection />;
      case 'content':
        return <ContentSection />;
      case 'security':
        return <SecuritySection />;
      case 'privacy':
        return <PrivacySection />;
      case 'data':
        return <DataSection />;
      default:
        return <ProfileSection />;
    }
  };

  const getSectionTitle = () => {
    switch (activeSection) {
      case 'profile':
        return 'Profile Settings';
      case 'account':
        return 'Account Settings';
      case 'notifications':
        return 'Notification Settings';
      case 'appearance':
        return 'Appearance Settings';
      case 'website':
        return 'Website Settings';
      case 'content':
        return 'Content Management';
      case 'security':
        return 'Security Settings';
      case 'privacy':
        return 'Privacy Settings';
      case 'data':
        return 'Data & Storage';
      default:
        return 'Settings';
    }
  };

  return (
    <Layout showFooter={false}>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex w-full">
        {/* Desktop Sidebar */}
        <div className="hidden lg:block">
          <SettingsSidebar 
            activeSection={activeSection} 
            onSectionChange={setActiveSection} 
          />
        </div>

        {/* Mobile Sidebar Sheet */}
        <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
          <SheetContent side="left" className="p-0 w-80">
            <SettingsSidebar 
              activeSection={activeSection} 
              onSectionChange={(section) => {
                setActiveSection(section);
                setSidebarOpen(false);
              }} 
            />
          </SheetContent>
        </Sheet>
        
        {/* Main Content */}
        <div className="flex-1 lg:ml-0">
          <div className="p-4 lg:p-8">
            <div className="max-w-4xl mx-auto">
              <div className="mb-8 flex items-center gap-4">
                {/* Mobile menu trigger */}
                <div className="lg:hidden">
                  <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
                    <SheetTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <Menu className="w-5 h-5" />
                      </Button>
                    </SheetTrigger>
                  </Sheet>
                </div>
                
                <Button
                  variant="ghost"
                  onClick={() => navigate('/dashboard')}
                  className="p-2"
                >
                  <ArrowLeft className="w-5 h-5" />
                </Button>
                <div>
                  <h1 className="text-3xl font-bold">{getSectionTitle()}</h1>
                  <p className="text-gray-600 dark:text-gray-400 mt-1">
                    Manage your account settings and preferences
                  </p>
                </div>
              </div>

              {renderActiveSection()}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ProfileSettings;
