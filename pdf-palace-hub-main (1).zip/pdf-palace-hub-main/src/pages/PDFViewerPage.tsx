
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import PDFViewer from './PDFViewer';
import { supabase } from '@/integrations/supabase/client';
import type { PDF } from '@/types/pdf';
import { toast } from '@/hooks/use-toast';

const PDFViewerPage: React.FC = () => {
  const { id, pdfId } = useParams<{ id?: string; pdfId?: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const [pdf, setPdf] = useState<PDF | null>(null);
  const [loading, setLoading] = useState(true);

  // Use either id or pdfId parameter
  const actualId = id || pdfId;

  useEffect(() => {
    const fetchPDF = async () => {
      if (!actualId) {
        navigate('/explore');
        return;
      }

      console.log('Fetching PDF with ID:', actualId);

      try {
        // First fetch the PDF data
        const { data: pdfData, error: pdfError } = await supabase
          .from('pdfs')
          .select('*')
          .eq('id', actualId)
          .single();

        if (pdfError) {
          console.error('PDF fetch error:', pdfError);
          throw pdfError;
        }

        console.log('PDF data fetched:', pdfData);

        // Then fetch the profile separately
        let profileData = null;
        if (pdfData.user_id) {
          try {
            const { data: profile } = await supabase
              .from('profiles')
              .select('full_name, username, avatar_url')
              .eq('id', pdfData.user_id)
              .maybeSingle();
            
            profileData = profile;
          } catch (error) {
            console.error('Error fetching profile:', error);
          }
        }

        const pdfWithProfile = {
          ...pdfData,
          profiles: profileData || { full_name: undefined, username: undefined, avatar_url: undefined }
        };

        setPdf(pdfWithProfile);
        console.log('PDF set successfully:', pdfWithProfile);
      } catch (error) {
        console.error('Error fetching PDF:', error);
        toast({
          title: "Error",
          description: "Failed to load PDF",
          variant: "destructive"
        });
        navigate('/explore');
      } finally {
        setLoading(false);
      }
    };

    fetchPDF();
  }, [actualId, navigate]);

  const handleClose = () => {
    // Check if there's a previous page in history or if we came from a specific route
    const from = location.state?.from;
    
    if (from) {
      // Navigate back to the specific page we came from
      navigate(from);
    } else if (window.history.length > 1) {
      // Go back to previous page if there's history
      navigate(-1);
    } else {
      // Default fallback to explore
      navigate('/explore');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-gray-900 mx-auto mb-4"></div>
          <p className="mt-4 text-gray-600 text-lg">Loading PDF...</p>
          <p className="text-sm text-gray-500 mt-2">Preparing your document viewer</p>
        </div>
      </div>
    );
  }

  if (!pdf) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100">
        <div className="text-center">
          <p className="mt-4 text-gray-600 text-lg">PDF not found</p>
          <button onClick={handleClose} className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <PDFViewer
      pdf={pdf}
      isOpen={true}
      onClose={handleClose}
    />
  );
};

export default PDFViewerPage;
