
import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { DocumentEditorService, DocumentContent, DocumentElement, PageContent } from '@/services/documentEditorService';
import { DocumentEditorToolbar } from '@/components/document-editor/DocumentEditorToolbar';
import { DocumentCanvas } from '@/components/document-editor/DocumentCanvas';
import { DocumentSidebar } from '@/components/document-editor/DocumentSidebar';
import { DocumentPropertiesPanel } from '@/components/document-editor/DocumentPropertiesPanel';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import type { PDF } from '@/types/pdf';

const DocumentEditor: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [document, setDocument] = useState<PDF | null>(null);
  const [documentContent, setDocumentContent] = useState<DocumentContent>({
    pages: [{
      id: 'page-1',
      elements: [],
      background: { color: '#ffffff' },
      size: { width: 794, height: 1123 } // A4 size in pixels
    }],
    metadata: {
      title: 'Untitled Document',
      author: user?.email || 'Unknown',
      createdAt: new Date().toISOString(),
      modifiedAt: new Date().toISOString()
    }
  });
  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  const [selectedTool, setSelectedTool] = useState<string>('select');
  const [currentPage, setCurrentPage] = useState(0);
  const [editingSession, setEditingSession] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (!id) {
      navigate('/explore');
      return;
    }
    initializeEditor();
  }, [id, navigate]);

  const initializeEditor = async () => {
    try {
      // Fetch document details
      const { data: pdfData, error: pdfError } = await supabase
        .from('pdfs')
        .select('*')
        .eq('id', id)
        .single();

      if (pdfError) throw pdfError;
      setDocument(pdfData);

      // Check if user can edit this document
      if (pdfData.user_id !== user?.id) {
        toast({
          title: "Access Denied",
          description: "You don't have permission to edit this document",
          variant: "destructive"
        });
        navigate('/explore');
        return;
      }

      // Start editing session
      const session = await DocumentEditorService.startEditingSession(id);
      setEditingSession(session);

      // Load latest document version if exists
      const versions = await DocumentEditorService.getDocumentVersions(id);
      if (versions.length > 0) {
        const latestVersion = versions[0];
        if (latestVersion.content) {
          setDocumentContent(latestVersion.content as DocumentContent);
        }
      }

      setDocumentContent(prev => ({
        ...prev,
        metadata: {
          ...prev.metadata,
          title: pdfData.title,
          author: pdfData.profiles?.full_name || user?.email || 'Unknown'
        }
      }));

    } catch (error) {
      console.error('Error initializing editor:', error);
      toast({
        title: "Error",
        description: "Failed to load document for editing",
        variant: "destructive"
      });
      navigate('/explore');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = useCallback(async (publish = false) => {
    if (!id || isSaving) return;

    setIsSaving(true);
    try {
      const updatedContent = {
        ...documentContent,
        metadata: {
          ...documentContent.metadata,
          modifiedAt: new Date().toISOString()
        }
      };

      const versionId = await DocumentEditorService.saveDocumentContent(
        id,
        updatedContent,
        'Manual save'
      );

      if (publish && versionId) {
        await DocumentEditorService.publishDocument(id, versionId);
      }

      setDocumentContent(updatedContent);
      
      toast({
        title: "Success",
        description: publish ? "Document published successfully!" : "Document saved successfully!",
      });
    } catch (error) {
      console.error('Error saving document:', error);
      toast({
        title: "Error",
        description: "Failed to save document",
        variant: "destructive"
      });
    } finally {
      setIsSaving(false);
    }
  }, [id, documentContent, isSaving]);

  const handleAddElement = useCallback((type: string) => {
    const newElement: DocumentElement = {
      id: `element-${Date.now()}`,
      type: type as any,
      position: {
        x: 100,
        y: 100,
        width: type === 'text' ? 200 : 150,
        height: type === 'text' ? 50 : 100
      },
      content: getDefaultContent(type),
      style: getDefaultStyle(type),
      zIndex: documentContent.pages[currentPage].elements.length
    };

    setDocumentContent(prev => ({
      ...prev,
      pages: prev.pages.map((page, index) => 
        index === currentPage 
          ? { ...page, elements: [...page.elements, newElement] }
          : page
      )
    }));

    setSelectedElement(newElement.id);
  }, [currentPage, documentContent.pages]);

  const handleUpdateElement = useCallback((elementId: string, updates: Partial<DocumentElement>) => {
    setDocumentContent(prev => ({
      ...prev,
      pages: prev.pages.map((page, index) => 
        index === currentPage
          ? {
              ...page,
              elements: page.elements.map(element =>
                element.id === elementId ? { ...element, ...updates } : element
              )
            }
          : page
      )
    }));
  }, [currentPage]);

  const handleDeleteElement = useCallback((elementId: string) => {
    setDocumentContent(prev => ({
      ...prev,
      pages: prev.pages.map((page, index) => 
        index === currentPage
          ? {
              ...page,
              elements: page.elements.filter(element => element.id !== elementId)
            }
          : page
      )
    }));
    setSelectedElement(null);
  }, [currentPage]);

  const getDefaultContent = (type: string) => {
    switch (type) {
      case 'text':
        return { text: 'Double click to edit text' };
      case 'image':
        return { src: '', alt: 'Image' };
      case 'shape':
        return { shape: 'rectangle', fill: '#3b82f6' };
      case 'table':
        return { rows: 3, cols: 3, data: [] };
      case 'chart':
        return { type: 'bar', data: [] };
      default:
        return {};
    }
  };

  const getDefaultStyle = (type: string) => {
    switch (type) {
      case 'text':
        return {
          fontSize: 16,
          fontFamily: 'Arial',
          color: '#000000',
          textAlign: 'left',
          fontWeight: 'normal'
        };
      case 'shape':
        return {
          fill: '#3b82f6',
          stroke: '#1e40af',
          strokeWidth: 2
        };
      default:
        return {};
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-lg text-gray-600">Loading document editor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      <DocumentEditorToolbar
        selectedTool={selectedTool}
        onToolSelect={setSelectedTool}
        onSave={() => handleSave(false)}
        onPublish={() => handleSave(true)}
        onAddElement={handleAddElement}
        isSaving={isSaving}
        documentTitle={documentContent.metadata.title}
        onTitleChange={(title) => 
          setDocumentContent(prev => ({
            ...prev,
            metadata: { ...prev.metadata, title }
          }))
        }
      />
      
      <div className="flex-1 flex overflow-hidden">
        <DocumentSidebar
          pages={documentContent.pages}
          currentPage={currentPage}
          onPageSelect={setCurrentPage}
          onAddPage={() => {
            const newPage: PageContent = {
              id: `page-${documentContent.pages.length + 1}`,
              elements: [],
              background: { color: '#ffffff' },
              size: { width: 794, height: 1123 }
            };
            setDocumentContent(prev => ({
              ...prev,
              pages: [...prev.pages, newPage]
            }));
          }}
        />
        
        <div className="flex-1 flex">
          <DocumentCanvas
            page={documentContent.pages[currentPage]}
            selectedElement={selectedElement}
            selectedTool={selectedTool}
            onElementSelect={setSelectedElement}
            onElementUpdate={handleUpdateElement}
            onElementDelete={handleDeleteElement}
          />
          
          <DocumentPropertiesPanel
            selectedElement={selectedElement ? 
              documentContent.pages[currentPage].elements.find(el => el.id === selectedElement) 
              : null
            }
            onElementUpdate={handleUpdateElement}
          />
        </div>
      </div>
    </div>
  );
};

export default DocumentEditor;
