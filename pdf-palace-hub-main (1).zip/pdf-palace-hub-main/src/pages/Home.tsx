
import React, { useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { usePDFs } from '@/hooks/usePDFs';
import Layout from '@/components/layout/Layout';
import PDFSection from '@/components/home/PDFSection';
import CTASection from '@/components/home/CTASection';

const Home = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { pdfs, loading, searchPDFs } = usePDFs();

  // Memoize handlers to prevent re-renders
  const handleLike = useCallback(async (pdfId: string) => {
    if (!user) {
      navigate('/auth');
      return;
    }
    console.log('Like PDF:', pdfId);
  }, [user, navigate]);

  const handleViewPDF = useCallback((pdf: any) => {
    navigate(`/pdf/${pdf.id}`);
  }, [navigate]);

  const handleViewProfile = useCallback((userId: string) => {
    navigate(`/profile/${userId}`);
  }, [navigate]);

  // Stable search handler that doesn't change on every render
  const handleSearch = useCallback((query: string) => {
    console.log('Searching for:', query);
    searchPDFs(query);
  }, [searchPDFs]);

  // Memoize the loading component to prevent unnecessary re-renders
  const loadingComponent = useMemo(() => (
    <Layout 
      showSearchBar={true}
      onSearch={handleSearch}
      searchPlaceholder="Search PDFs or users..."
    >
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading PDFs...</p>
        </div>
      </div>
    </Layout>
  ), [handleSearch]);

  if (loading) {
    return loadingComponent;
  }

  return (
    <Layout 
      showSearchBar={true}
      onSearch={handleSearch}
      searchPlaceholder="Search PDFs or users..."
    >
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
        <PDFSection 
          pdfs={pdfs}
          onLike={handleLike}
          onViewPDF={handleViewPDF}
          onViewProfile={handleViewProfile}
        />
        {!user && <CTASection />}
      </div>
    </Layout>
  );
};

export default Home;
