
import React, { useState, useRef } from 'react';
import { Upload as UploadIcon, FileText, Image, Zap, Shield, Search, Database, Globe, Cpu, Crown, Sparkles, BookOpen, Plus, File } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { toast } from '@/hooks/use-toast';
import { useDocuments } from '@/hooks/useDocuments';
import { usePDFBundles } from '@/hooks/usePDFBundles';
import Layout from '@/components/layout/Layout';
import DocumentThumbnailGenerator from '@/components/DocumentThumbnailGenerator';
import PDFBundleDialog from '@/components/PDFBundleDialog';

const Upload = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { uploadDocument } = useDocuments();
  const { bundles, createBundle, addPDFToBundle } = usePDFBundles();
  
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState('');
  const [uploading, setUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null);
  const [selectedLibrary, setSelectedLibrary] = useState<string>('');
  const [newLibraryName, setNewLibraryName] = useState('');
  const [createNewLibrary, setCreateNewLibrary] = useState(false);

  // Supported file types
  const supportedFileTypes = {
    'application/pdf': '.pdf',
    'application/msword': '.doc',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
    'application/vnd.ms-excel': '.xls',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx',
    'application/vnd.ms-powerpoint': '.ppt',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation': '.pptx',
    'text/plain': '.txt',
    'application/rtf': '.rtf',
    'application/vnd.oasis.opendocument.text': '.odt'
  };

  const acceptedFileTypes = Object.values(supportedFileTypes).join(',');

  // Processing options
  const [processingOptions, setProcessingOptions] = useState({
    ocrEnabled: false,
    compressionEnabled: true,
    watermarkEnabled: false,
    thumbnailGeneration: true,
    metadataExtraction: true,
    duplicateDetection: false,
    securityScan: false,
    autoTagging: false
  });

  const processingFeatures = [
    {
      key: 'ocrEnabled',
      icon: Search,
      title: 'OCR Text Recognition',
      description: 'Extract and index text from scanned documents using advanced AI',
      premium: true,
      aiPowered: true
    },
    {
      key: 'compressionEnabled',
      icon: Zap,
      title: 'Smart Compression',
      description: 'Reduce file size while maintaining quality using AI optimization',
      premium: false,
      aiPowered: true
    },
    {
      key: 'watermarkEnabled',
      icon: Shield,
      title: 'Watermark Protection',
      description: 'Add custom watermarks to protect your content',
      premium: true,
      aiPowered: false
    },
    {
      key: 'thumbnailGeneration',
      icon: Image,
      title: 'Thumbnail Generation',
      description: 'Automatically create preview thumbnails',
      premium: false,
      aiPowered: false
    },
    {
      key: 'metadataExtraction',
      icon: Database,
      title: 'Metadata Extraction',
      description: 'Extract document properties and information using AI analysis',
      premium: false,
      aiPowered: true
    },
    {
      key: 'duplicateDetection',
      icon: Globe,
      title: 'Duplicate Detection',
      description: 'Check for existing similar documents using AI content analysis',
      premium: true,
      aiPowered: true
    },
    {
      key: 'securityScan',
      icon: Shield,
      title: 'Security Scanning',
      description: 'Scan for malicious content and vulnerabilities using AI detection',
      premium: true,
      aiPowered: true
    },
    {
      key: 'autoTagging',
      icon: Cpu,
      title: 'AI Auto-Tagging',
      description: 'Automatically generate relevant tags using advanced AI analysis',
      premium: true,
      aiPowered: true
    }
  ];

  if (!user) {
    return (
      <Layout>
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
          <Card className="w-full max-w-md">
            <CardContent className="p-6 text-center">
              <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h2 className="text-xl font-semibold mb-2">Sign in to Upload</h2>
              <p className="text-gray-600 mb-4">
                You need to be signed in to upload documents.
              </p>
              <Button onClick={() => navigate('/auth')}>
                Sign In
              </Button>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile && Object.keys(supportedFileTypes).includes(droppedFile.type)) {
      setFile(droppedFile);
      if (!title) {
        const fileName = droppedFile.name;
        const fileNameWithoutExt = fileName.substring(0, fileName.lastIndexOf('.')) || fileName;
        setTitle(fileNameWithoutExt);
      }
    } else {
      toast({
        title: "Invalid file type",
        description: "Please upload a supported document file (PDF, Word, Excel, PowerPoint, Text, etc.)",
        variant: "destructive"
      });
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      if (!title) {
        const fileName = selectedFile.name;
        const fileNameWithoutExt = fileName.substring(0, fileName.lastIndexOf('.')) || fileName;
        setTitle(fileNameWithoutExt);
      }
    }
  };

  const addTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim()) && tags.length < 10) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addTag();
    }
  };

  const handleProcessingOptionChange = (key: string, checked: boolean) => {
    setProcessingOptions(prev => ({
      ...prev,
      [key]: checked
    }));
  };

  const handleThumbnailGenerated = (thumbnail: string) => {
    console.log('Thumbnail generated:', thumbnail);
  };

  const handleCustomThumbnail = (file: File) => {
    setThumbnailFile(file);
  };

  const handleUpload = async () => {
    if (!file || !title.trim()) {
      toast({
        title: "Missing information",
        description: "Please provide a file and title",
        variant: "destructive"
      });
      return;
    }

    setUploading(true);
    try {
      // Upload the document
      const uploadedDocument = await uploadDocument(file, title, description, tags, thumbnailFile);
      
      // If creating a new library, create it first
      if (createNewLibrary && newLibraryName.trim()) {
        createBundle({ 
          name: newLibraryName, 
          description: `Library containing ${title}`, 
          isPublic: false 
        });
        // Note: We can't add to the new library immediately since createBundle doesn't return the ID
        // The user will need to add the document to the library manually from the dashboard
      } else if (selectedLibrary && uploadedDocument) {
        // Add to existing library
        addPDFToBundle({ bundleId: selectedLibrary, pdfId: uploadedDocument.id });
      }
      
      toast({
        title: "Document uploaded successfully",
        description: selectedLibrary || createNewLibrary 
          ? "Your document has been uploaded and added to the library" 
          : "Your document has been uploaded and is now available"
      });
      navigate('/dashboard');
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: "Upload failed",
        description: "There was an error uploading your document",
        variant: "destructive"
      });
    } finally {
      setUploading(false);
    }
  };

  const getFileIcon = () => {
    if (!file) return <UploadIcon className="w-12 h-12 text-gray-400" />;
    
    const fileType = file.type;
    if (fileType.includes('pdf')) return <FileText className="w-12 h-12 text-red-600" />;
    if (fileType.includes('word') || fileType.includes('document')) return <FileText className="w-12 h-12 text-blue-600" />;
    if (fileType.includes('sheet') || fileType.includes('excel')) return <File className="w-12 h-12 text-green-600" />;
    if (fileType.includes('presentation') || fileType.includes('powerpoint')) return <File className="w-12 h-12 text-orange-600" />;
    return <File className="w-12 h-12 text-gray-600" />;
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold flex items-center">
              <UploadIcon className="w-8 h-8 mr-3 text-blue-600" />
              Upload Document
            </h1>
            <p className="text-gray-600 mt-1">Share your documents with the community</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Upload Form */}
            <div className="space-y-6">
              {/* File Upload Area */}
              <Card>
                <CardHeader>
                  <CardTitle>Select Document File</CardTitle>
                </CardHeader>
                <CardContent>
                  <div
                    className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                      dragOver ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
                    }`}
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={handleDrop}
                  >
                    {file ? (
                      <div>
                        {getFileIcon()}
                        <p className="text-lg font-medium mt-4">{file.name}</p>
                        <p className="text-gray-500">
                          {(file.size / (1024 * 1024)).toFixed(2)} MB
                        </p>
                        <Button
                          variant="outline"
                          className="mt-4"
                          onClick={() => setFile(null)}
                        >
                          Remove File
                        </Button>
                      </div>
                    ) : (
                      <div>
                        <UploadIcon className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-lg font-medium mb-2">
                          Drag and drop your document here
                        </p>
                        <p className="text-gray-500 mb-2">
                          Supports PDF, Word, Excel, PowerPoint, Text, and more
                        </p>
                        <p className="text-gray-500 mb-4">or</p>
                        <Button onClick={() => fileInputRef.current?.click()}>
                          Browse Files
                        </Button>
                        <input
                          ref={fileInputRef}
                          type="file"
                          accept={acceptedFileTypes}
                          onChange={handleFileSelect}
                          className="hidden"
                        />
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Library Selection */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BookOpen className="w-5 h-5" />
                    <span>Library Options</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="create-new-library"
                      checked={createNewLibrary}
                      onCheckedChange={(checked) => setCreateNewLibrary(checked === true)}
                    />
                    <label htmlFor="create-new-library" className="text-sm font-medium">
                      Create new library
                    </label>
                  </div>

                  {createNewLibrary ? (
                    <div>
                      <label className="block text-sm font-medium mb-2">New Library Name</label>
                      <Input
                        placeholder="Enter library name"
                        value={newLibraryName}
                        onChange={(e) => setNewLibraryName(e.target.value)}
                      />
                    </div>
                  ) : (
                    <div>
                      <label className="block text-sm font-medium mb-2">Add to Existing Library (Optional)</label>
                      <Select value={selectedLibrary} onValueChange={setSelectedLibrary}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a library or leave empty" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">No library</SelectItem>
                          {bundles.map((bundle) => (
                            <SelectItem key={bundle.id} value={bundle.id}>
                              {bundle.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Thumbnail Generation */}
              {file && (
                <Card>
                  <CardHeader>
                    <CardTitle>Thumbnail Options</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <DocumentThumbnailGenerator
                      file={file}
                      onThumbnailGenerated={handleThumbnailGenerated}
                      onCustomThumbnail={handleCustomThumbnail}
                    />
                  </CardContent>
                </Card>
              )}

              {/* Document Information */}
              <Card>
                <CardHeader>
                  <CardTitle>Document Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Title *</label>
                    <Input
                      placeholder="Enter document title"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Description</label>
                    <Textarea
                      placeholder="Describe your document content"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      rows={3}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Tags</label>
                    <div className="flex flex-wrap gap-2 mb-2">
                      {tags.map((tag) => (
                        <Badge
                          key={tag}
                          variant="secondary"
                          className="cursor-pointer"
                          onClick={() => removeTag(tag)}
                        >
                          {tag} ×
                        </Badge>
                      ))}
                    </div>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add tags (press Enter)"
                        value={tagInput}
                        onChange={(e) => setTagInput(e.target.value)}
                        onKeyPress={handleKeyPress}
                      />
                      <Button variant="outline" onClick={addTag}>
                        Add
                      </Button>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      Add up to 10 tags to help others find your document
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Processing Options */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Sparkles className="w-5 h-5 text-purple-600" />
                    <span>AI-Powered Processing Options</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {processingFeatures.map((feature) => {
                    const IconComponent = feature.icon;
                    return (
                      <div key={feature.key} className="flex items-start space-x-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                        <Checkbox
                          id={feature.key}
                          checked={processingOptions[feature.key as keyof typeof processingOptions]}
                          onCheckedChange={(checked) => 
                            handleProcessingOptionChange(feature.key, checked === true)
                          }
                          disabled={feature.premium}
                          className="mt-1"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2 mb-2">
                            <IconComponent className="w-5 h-5 text-gray-600" />
                            <label 
                              htmlFor={feature.key}
                              className="text-base font-medium cursor-pointer"
                            >
                              {feature.title}
                            </label>
                            <div className="flex items-center space-x-1">
                              {feature.premium && (
                                <Badge variant="outline" className="text-xs bg-amber-50 text-amber-700 border-amber-200">
                                  <Crown className="w-3 h-3 mr-1" />
                                  Pro
                                </Badge>
                              )}
                              {feature.aiPowered && (
                                <Badge variant="outline" className="text-xs bg-purple-50 text-purple-700 border-purple-200">
                                  <Sparkles className="w-3 h-3 mr-1" />
                                  AI
                                </Badge>
                              )}
                            </div>
                          </div>
                          <p className="text-sm text-gray-600 leading-relaxed">
                            {feature.description}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                  
                  <div className="bg-gradient-to-r from-amber-50 to-yellow-50 border border-amber-200 rounded-lg p-4 mt-6">
                    <div className="flex items-center space-x-2 mb-2">
                      <Crown className="w-5 h-5 text-amber-600" />
                      <h3 className="font-semibold text-amber-800">Unlock Pro Features</h3>
                    </div>
                    <p className="text-sm text-amber-700 mb-3">
                      Get access to advanced AI-powered processing options including OCR, watermarks, duplicate detection, and security scanning.
                    </p>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => navigate('/premium')}
                      className="bg-white hover:bg-amber-50 text-amber-700 border-amber-300"
                    >
                      <Crown className="w-4 h-4 mr-2" />
                      Upgrade to Pro
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <Button
                    onClick={handleUpload}
                    disabled={!file || !title.trim() || uploading}
                    className="w-full"
                    size="lg"
                  >
                    {uploading ? 'Uploading...' : 'Upload Document'}
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Upload;
