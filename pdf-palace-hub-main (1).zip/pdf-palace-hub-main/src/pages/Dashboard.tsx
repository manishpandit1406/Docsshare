
import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useDashboardData } from '@/hooks/useDashboardData';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import DashboardHeader from '@/components/dashboard/DashboardHeader';
import DashboardStats from '@/components/dashboard/DashboardStats';
import MyPDFsSection from '@/components/dashboard/MyPDFsSection';
import MyLibrariesSection from '@/components/dashboard/MyLibrariesSection';
import SubscriptionsModal from '@/components/SubscriptionsModal';
import ProfileTabs, { ProfileTabType } from '@/components/shared/ProfileTabs';
import AboutSection from '@/components/shared/AboutSection';
import Layout from '@/components/layout/Layout';

const Dashboard = () => {
  const { signOut } = useAuth();
  const navigate = useNavigate();
  const {
    user,
    userPDFs,
    loading,
    error,
    deletePDF,
    wishlistItems,
    userStats,
    subscriptionsCount,
    subscribersCount
  } = useDashboardData();
  
  const [showSubscriptions, setShowSubscriptions] = useState(false);
  const [activeTab, setActiveTab] = useState<ProfileTabType>('pdfs');

  const handleDeletePDF = useCallback(async (pdfId: string) => {
    if (window.confirm('Are you sure you want to delete this PDF?')) {
      await deletePDF(pdfId);
    }
  }, [deletePDF]);

  const handleNavigation = useCallback((path: string) => {
    navigate(path);
  }, [navigate]);

  const handleViewProfile = useCallback((userId: string) => {
    navigate(`/profile/${userId}`);
  }, [navigate]);

  const handleViewSubscriptions = useCallback(() => {
    setShowSubscriptions(true);
  }, []);

  if (!user) {
    navigate('/auth');
    return null;
  }

  if (error) {
    return (
      <Layout>
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <Card className="p-8 text-center">
              <CardContent>
                <h3 className="text-xl font-semibold text-red-600 mb-2">
                  Error Loading PDFs
                </h3>
                <p className="text-gray-600 mb-4">{error}</p>
                <Button onClick={() => window.location.reload()}>
                  Refresh Page
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <DashboardHeader
            user={user}
            wishlistCount={wishlistItems.length}
            onNavigate={handleNavigation}
            onSignOut={signOut}
            onViewSubscriptions={handleViewSubscriptions}
            totalComments={userStats.totalComments}
          />

          <DashboardStats
            totalPDFs={userPDFs.length}
            totalViews={userStats.totalViews}
            totalLikes={userStats.totalLikes}
            totalComments={userStats.totalComments}
            subscribersCount={subscribersCount}
          />

          <ProfileTabs
            activeTab={activeTab}
            onTabChange={setActiveTab}
          />

          <div className="grid grid-cols-1 gap-8">
            {activeTab === 'pdfs' && (
              <MyPDFsSection
                loading={loading}
                userPDFs={userPDFs}
                onNavigate={handleNavigation}
                onDeletePDF={handleDeletePDF}
                onViewProfile={handleViewProfile}
              />
            )}

            {activeTab === 'libraries' && (
              <MyLibrariesSection />
            )}

            {activeTab === 'about' && user && (
              <AboutSection
                profile={user}
                isOwnProfile={true}
                totalPDFs={userPDFs.length}
                totalViews={userStats.totalViews}
                totalLikes={userStats.totalLikes}
                subscribersCount={subscribersCount}
              />
            )}
          </div>

          <SubscriptionsModal 
            isOpen={showSubscriptions}
            onClose={() => setShowSubscriptions(false)}
          />
        </div>
      </div>
    </Layout>
  );
};

export default Dashboard;
