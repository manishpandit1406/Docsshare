
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import DocumentViewer from '@/components/DocumentViewer';
import { supabase } from '@/integrations/supabase/client';
import type { Document } from '@/types/document';
import { toast } from '@/hooks/use-toast';

const DocumentViewerPage: React.FC = () => {
  const { id, pdfId, documentId } = useParams<{ id?: string; pdfId?: string; documentId?: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const [document, setDocument] = useState<Document | null>(null);
  const [loading, setLoading] = useState(true);

  // Use any of the available ID parameters
  const actualId = id || pdfId || documentId;

  useEffect(() => {
    const fetchDocument = async () => {
      if (!actualId) {
        navigate('/explore');
        return;
      }

      console.log('Fetching document with ID:', actualId);

      try {
        // First fetch the document data
        const { data: documentData, error: documentError } = await supabase
          .from('pdfs')
          .select('*')
          .eq('id', actualId)
          .single();

        if (documentError) {
          console.error('Document fetch error:', documentError);
          throw documentError;
        }

        console.log('Document data fetched:', documentData);

        // Then fetch the profile separately
        let profileData = null;
        if (documentData.user_id) {
          try {
            const { data: profile } = await supabase
              .from('profiles')
              .select('full_name, username, avatar_url')
              .eq('id', documentData.user_id)
              .maybeSingle();
            
            profileData = profile;
          } catch (error) {
            console.error('Error fetching profile:', error);
          }
        }

        const documentWithProfile = {
          ...documentData,
          profiles: profileData || { full_name: undefined, username: undefined, avatar_url: undefined }
        };

        setDocument(documentWithProfile);
        console.log('Document set successfully:', documentWithProfile);
      } catch (error) {
        console.error('Error fetching document:', error);
        toast({
          title: "Error",
          description: "Failed to load document",
          variant: "destructive"
        });
        navigate('/explore');
      } finally {
        setLoading(false);
      }
    };

    fetchDocument();
  }, [actualId, navigate]);

  const handleClose = () => {
    // Check if there's a previous page in history or if we came from a specific route
    const from = location.state?.from;
    
    if (from) {
      // Navigate back to the specific page we came from
      navigate(from);
    } else if (window.history.length > 1) {
      // Go back to previous page if there's history
      navigate(-1);
    } else {
      // Default fallback to explore
      navigate('/explore');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-gray-900 mx-auto mb-4"></div>
          <p className="mt-4 text-gray-600 text-lg">Loading document...</p>
          <p className="text-sm text-gray-500 mt-2">Preparing your document viewer</p>
        </div>
      </div>
    );
  }

  if (!document) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100">
        <div className="text-center">
          <p className="mt-4 text-gray-600 text-lg">Document not found</p>
          <button onClick={handleClose} className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <DocumentViewer
      document={document}
      isOpen={true}
      onClose={handleClose}
    />
  );
};

export default DocumentViewerPage;
