export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      audit_logs: {
        Row: {
          action: Database["public"]["Enums"]["audit_action"]
          created_at: string | null
          details: Json | null
          id: string
          ip_address: unknown | null
          target_id: string | null
          target_type: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action: Database["public"]["Enums"]["audit_action"]
          created_at?: string | null
          details?: Json | null
          id?: string
          ip_address?: unknown | null
          target_id?: string | null
          target_type?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action?: Database["public"]["Enums"]["audit_action"]
          created_at?: string | null
          details?: Json | null
          id?: string
          ip_address?: unknown | null
          target_id?: string | null
          target_type?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "audit_logs_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      document_collaborators: {
        Row: {
          accepted_at: string | null
          document_id: string
          id: string
          invited_at: string
          invited_by: string
          permission_level: string
          status: string
          user_id: string
        }
        Insert: {
          accepted_at?: string | null
          document_id: string
          id?: string
          invited_at?: string
          invited_by: string
          permission_level?: string
          status?: string
          user_id: string
        }
        Update: {
          accepted_at?: string | null
          document_id?: string
          id?: string
          invited_at?: string
          invited_by?: string
          permission_level?: string
          status?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "document_collaborators_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "pdfs"
            referencedColumns: ["id"]
          },
        ]
      }
      document_edit_sessions: {
        Row: {
          created_at: string
          document_id: string
          expires_at: string
          id: string
          is_active: boolean | null
          last_saved_at: string | null
          session_data: Json | null
          user_id: string
        }
        Insert: {
          created_at?: string
          document_id: string
          expires_at?: string
          id?: string
          is_active?: boolean | null
          last_saved_at?: string | null
          session_data?: Json | null
          user_id: string
        }
        Update: {
          created_at?: string
          document_id?: string
          expires_at?: string
          id?: string
          is_active?: boolean | null
          last_saved_at?: string | null
          session_data?: Json | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "document_edit_sessions_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "pdfs"
            referencedColumns: ["id"]
          },
        ]
      }
      document_versions: {
        Row: {
          changes_summary: string | null
          content: Json
          created_at: string
          created_by: string
          document_id: string
          file_size: number | null
          file_url: string | null
          id: string
          is_published: boolean | null
          version_number: number
        }
        Insert: {
          changes_summary?: string | null
          content?: Json
          created_at?: string
          created_by: string
          document_id: string
          file_size?: number | null
          file_url?: string | null
          id?: string
          is_published?: boolean | null
          version_number?: number
        }
        Update: {
          changes_summary?: string | null
          content?: Json
          created_at?: string
          created_by?: string
          document_id?: string
          file_size?: number | null
          file_url?: string | null
          id?: string
          is_published?: boolean | null
          version_number?: number
        }
        Relationships: [
          {
            foreignKeyName: "document_versions_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "pdfs"
            referencedColumns: ["id"]
          },
        ]
      }
      email_verification_tokens: {
        Row: {
          created_at: string | null
          expires_at: string
          id: string
          token: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          expires_at: string
          id?: string
          token: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          expires_at?: string
          id?: string
          token?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "email_verification_tokens_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      password_reset_tokens: {
        Row: {
          created_at: string | null
          email: string
          expires_at: string
          id: string
          token: string
          used: boolean | null
        }
        Insert: {
          created_at?: string | null
          email: string
          expires_at: string
          id?: string
          token: string
          used?: boolean | null
        }
        Update: {
          created_at?: string | null
          email?: string
          expires_at?: string
          id?: string
          token?: string
          used?: boolean | null
        }
        Relationships: []
      }
      pdf_bundle_items: {
        Row: {
          added_at: string
          bundle_id: string
          id: string
          pdf_id: string
          sort_order: number | null
        }
        Insert: {
          added_at?: string
          bundle_id: string
          id?: string
          pdf_id: string
          sort_order?: number | null
        }
        Update: {
          added_at?: string
          bundle_id?: string
          id?: string
          pdf_id?: string
          sort_order?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "pdf_bundle_items_bundle_id_fkey"
            columns: ["bundle_id"]
            isOneToOne: false
            referencedRelation: "pdf_library_bundles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pdf_bundle_items_pdf_id_fkey"
            columns: ["pdf_id"]
            isOneToOne: false
            referencedRelation: "pdfs"
            referencedColumns: ["id"]
          },
        ]
      }
      pdf_comment_replies: {
        Row: {
          comment_id: string
          content: string
          created_at: string
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          comment_id: string
          content: string
          created_at?: string
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          comment_id?: string
          content?: string
          created_at?: string
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "pdf_comment_replies_comment_id_fkey"
            columns: ["comment_id"]
            isOneToOne: false
            referencedRelation: "pdf_comments"
            referencedColumns: ["id"]
          },
        ]
      }
      pdf_comments: {
        Row: {
          content: string
          created_at: string | null
          id: string
          pdf_id: string
          replies_count: number | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string | null
          id?: string
          pdf_id: string
          replies_count?: number | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string | null
          id?: string
          pdf_id?: string
          replies_count?: number | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "pdf_comments_pdf_id_fkey"
            columns: ["pdf_id"]
            isOneToOne: false
            referencedRelation: "pdfs"
            referencedColumns: ["id"]
          },
        ]
      }
      pdf_library_bundles: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_public: boolean | null
          name: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_public?: boolean | null
          name: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_public?: boolean | null
          name?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      pdf_likes: {
        Row: {
          created_at: string | null
          id: string
          pdf_id: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          pdf_id: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          pdf_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "pdf_likes_pdf_id_fkey"
            columns: ["pdf_id"]
            isOneToOne: false
            referencedRelation: "pdfs"
            referencedColumns: ["id"]
          },
        ]
      }
      pdf_views: {
        Row: {
          created_at: string | null
          id: string
          ip_address: unknown | null
          pdf_id: string
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          ip_address?: unknown | null
          pdf_id: string
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          ip_address?: unknown | null
          pdf_id?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "pdf_views_pdf_id_fkey"
            columns: ["pdf_id"]
            isOneToOne: false
            referencedRelation: "pdfs"
            referencedColumns: ["id"]
          },
        ]
      }
      pdf_wishlist: {
        Row: {
          created_at: string
          id: string
          pdf_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          pdf_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          pdf_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "pdf_wishlist_pdf_id_fkey"
            columns: ["pdf_id"]
            isOneToOne: false
            referencedRelation: "pdfs"
            referencedColumns: ["id"]
          },
        ]
      }
      pdfs: {
        Row: {
          comments_count: number | null
          created_at: string | null
          description: string | null
          file_name: string
          file_size: number | null
          file_type: string
          file_url: string
          id: string
          likes_count: number | null
          mime_type: string | null
          tags: string[] | null
          thumbnail_url: string | null
          title: string
          updated_at: string | null
          user_id: string
          views_count: number | null
        }
        Insert: {
          comments_count?: number | null
          created_at?: string | null
          description?: string | null
          file_name: string
          file_size?: number | null
          file_type?: string
          file_url: string
          id?: string
          likes_count?: number | null
          mime_type?: string | null
          tags?: string[] | null
          thumbnail_url?: string | null
          title: string
          updated_at?: string | null
          user_id: string
          views_count?: number | null
        }
        Update: {
          comments_count?: number | null
          created_at?: string | null
          description?: string | null
          file_name?: string
          file_size?: number | null
          file_type?: string
          file_url?: string
          id?: string
          likes_count?: number | null
          mime_type?: string | null
          tags?: string[] | null
          thumbnail_url?: string | null
          title?: string
          updated_at?: string | null
          user_id?: string
          views_count?: number | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          bio: string | null
          cover_image_url: string | null
          created_at: string | null
          email_verified: boolean | null
          full_name: string | null
          id: string
          last_login: string | null
          locked_until: string | null
          login_attempts: number | null
          phone: string | null
          role: Database["public"]["Enums"]["user_role"] | null
          status: Database["public"]["Enums"]["user_status"] | null
          subscribers_count: number | null
          updated_at: string | null
          username: string | null
          website: string | null
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          cover_image_url?: string | null
          created_at?: string | null
          email_verified?: boolean | null
          full_name?: string | null
          id: string
          last_login?: string | null
          locked_until?: string | null
          login_attempts?: number | null
          phone?: string | null
          role?: Database["public"]["Enums"]["user_role"] | null
          status?: Database["public"]["Enums"]["user_status"] | null
          subscribers_count?: number | null
          updated_at?: string | null
          username?: string | null
          website?: string | null
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          cover_image_url?: string | null
          created_at?: string | null
          email_verified?: boolean | null
          full_name?: string | null
          id?: string
          last_login?: string | null
          locked_until?: string | null
          login_attempts?: number | null
          phone?: string | null
          role?: Database["public"]["Enums"]["user_role"] | null
          status?: Database["public"]["Enums"]["user_status"] | null
          subscribers_count?: number | null
          updated_at?: string | null
          username?: string | null
          website?: string | null
        }
        Relationships: []
      }
      settings_categories: {
        Row: {
          created_at: string
          description: string | null
          icon: string | null
          id: string
          name: string
          sort_order: number | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          name: string
          sort_order?: number | null
        }
        Update: {
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          name?: string
          sort_order?: number | null
        }
        Relationships: []
      }
      support_tickets: {
        Row: {
          assigned_to: string | null
          category: string | null
          created_at: string
          customer_id: string | null
          description: string | null
          id: string
          priority: string | null
          resolved_at: string | null
          status: string | null
          title: string
          updated_at: string
        }
        Insert: {
          assigned_to?: string | null
          category?: string | null
          created_at?: string
          customer_id?: string | null
          description?: string | null
          id?: string
          priority?: string | null
          resolved_at?: string | null
          status?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          assigned_to?: string | null
          category?: string | null
          created_at?: string
          customer_id?: string | null
          description?: string | null
          id?: string
          priority?: string | null
          resolved_at?: string | null
          status?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "support_tickets_assigned_to_fkey"
            columns: ["assigned_to"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      trending_searches: {
        Row: {
          created_at: string | null
          id: string
          last_searched: string | null
          query: string
          search_count: number | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          last_searched?: string | null
          query: string
          search_count?: number | null
        }
        Update: {
          created_at?: string | null
          id?: string
          last_searched?: string | null
          query?: string
          search_count?: number | null
        }
        Relationships: []
      }
      user_appearance_settings: {
        Row: {
          card_style: string | null
          compact_mode: boolean | null
          created_at: string | null
          custom_accent_color: string | null
          density: string | null
          font_size: string | null
          high_contrast: boolean | null
          id: string
          language: string | null
          reduce_animations: boolean | null
          sidebar_position: string | null
          theme: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          card_style?: string | null
          compact_mode?: boolean | null
          created_at?: string | null
          custom_accent_color?: string | null
          density?: string | null
          font_size?: string | null
          high_contrast?: boolean | null
          id?: string
          language?: string | null
          reduce_animations?: boolean | null
          sidebar_position?: string | null
          theme?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          card_style?: string | null
          compact_mode?: boolean | null
          created_at?: string | null
          custom_accent_color?: string | null
          density?: string | null
          font_size?: string | null
          high_contrast?: boolean | null
          id?: string
          language?: string | null
          reduce_animations?: boolean | null
          sidebar_position?: string | null
          theme?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_content_settings: {
        Row: {
          allowed_file_types: string[] | null
          auto_backup: boolean | null
          auto_categorization: boolean | null
          auto_tag_pdfs: boolean | null
          batch_processing: boolean | null
          compression_enabled: boolean | null
          created_at: string
          duplicate_detection: boolean | null
          id: string
          max_upload_size_mb: number | null
          ocr_enabled: boolean | null
          thumbnail_quality: string | null
          updated_at: string
          user_id: string
          version_control: boolean | null
          watermark_enabled: boolean | null
          watermark_text: string | null
        }
        Insert: {
          allowed_file_types?: string[] | null
          auto_backup?: boolean | null
          auto_categorization?: boolean | null
          auto_tag_pdfs?: boolean | null
          batch_processing?: boolean | null
          compression_enabled?: boolean | null
          created_at?: string
          duplicate_detection?: boolean | null
          id?: string
          max_upload_size_mb?: number | null
          ocr_enabled?: boolean | null
          thumbnail_quality?: string | null
          updated_at?: string
          user_id: string
          version_control?: boolean | null
          watermark_enabled?: boolean | null
          watermark_text?: string | null
        }
        Update: {
          allowed_file_types?: string[] | null
          auto_backup?: boolean | null
          auto_categorization?: boolean | null
          auto_tag_pdfs?: boolean | null
          batch_processing?: boolean | null
          compression_enabled?: boolean | null
          created_at?: string
          duplicate_detection?: boolean | null
          id?: string
          max_upload_size_mb?: number | null
          ocr_enabled?: boolean | null
          thumbnail_quality?: string | null
          updated_at?: string
          user_id?: string
          version_control?: boolean | null
          watermark_enabled?: boolean | null
          watermark_text?: string | null
        }
        Relationships: []
      }
      user_notification_settings: {
        Row: {
          created_at: string | null
          desktop_notifications: boolean | null
          email_new_followers: boolean | null
          email_pdf_comments: boolean | null
          email_pdf_likes: boolean | null
          email_promotions: boolean | null
          email_weekly_digest: boolean | null
          id: string
          mobile_notifications: boolean | null
          notification_frequency: string | null
          push_mentions: boolean | null
          push_new_followers: boolean | null
          push_pdf_comments: boolean | null
          push_pdf_likes: boolean | null
          quiet_hours_enabled: boolean | null
          quiet_hours_end: string | null
          quiet_hours_start: string | null
          sound_enabled: boolean | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          desktop_notifications?: boolean | null
          email_new_followers?: boolean | null
          email_pdf_comments?: boolean | null
          email_pdf_likes?: boolean | null
          email_promotions?: boolean | null
          email_weekly_digest?: boolean | null
          id?: string
          mobile_notifications?: boolean | null
          notification_frequency?: string | null
          push_mentions?: boolean | null
          push_new_followers?: boolean | null
          push_pdf_comments?: boolean | null
          push_pdf_likes?: boolean | null
          quiet_hours_enabled?: boolean | null
          quiet_hours_end?: string | null
          quiet_hours_start?: string | null
          sound_enabled?: boolean | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          desktop_notifications?: boolean | null
          email_new_followers?: boolean | null
          email_pdf_comments?: boolean | null
          email_pdf_likes?: boolean | null
          email_promotions?: boolean | null
          email_weekly_digest?: boolean | null
          id?: string
          mobile_notifications?: boolean | null
          notification_frequency?: string | null
          push_mentions?: boolean | null
          push_new_followers?: boolean | null
          push_pdf_comments?: boolean | null
          push_pdf_likes?: boolean | null
          quiet_hours_enabled?: boolean | null
          quiet_hours_end?: string | null
          quiet_hours_start?: string | null
          sound_enabled?: boolean | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_notifications: {
        Row: {
          created_at: string | null
          data: Json | null
          id: string
          message: string
          read: boolean | null
          title: string
          type: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          data?: Json | null
          id?: string
          message: string
          read?: boolean | null
          title: string
          type?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          data?: Json | null
          id?: string
          message?: string
          read?: boolean | null
          title?: string
          type?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_privacy_settings: {
        Row: {
          allow_messages: boolean | null
          analytics_opt_out: boolean | null
          created_at: string | null
          id: string
          index_profile: boolean | null
          profile_visibility: string | null
          show_email: boolean | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          allow_messages?: boolean | null
          analytics_opt_out?: boolean | null
          created_at?: string | null
          id?: string
          index_profile?: boolean | null
          profile_visibility?: string | null
          show_email?: boolean | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          allow_messages?: boolean | null
          analytics_opt_out?: boolean | null
          created_at?: string | null
          id?: string
          index_profile?: boolean | null
          profile_visibility?: string | null
          show_email?: boolean | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_security_settings: {
        Row: {
          api_access_enabled: boolean | null
          audit_logging: boolean | null
          auto_logout_inactive: boolean | null
          created_at: string
          device_management: boolean | null
          download_restrictions: boolean | null
          failed_login_lockout: boolean | null
          id: string
          ip_whitelist: string[] | null
          login_alerts: boolean | null
          max_failed_attempts: number | null
          password_change_required: boolean | null
          secure_sharing_only: boolean | null
          session_timeout_minutes: number | null
          suspicious_activity_alerts: boolean | null
          two_factor_enabled: boolean | null
          updated_at: string
          user_id: string
        }
        Insert: {
          api_access_enabled?: boolean | null
          audit_logging?: boolean | null
          auto_logout_inactive?: boolean | null
          created_at?: string
          device_management?: boolean | null
          download_restrictions?: boolean | null
          failed_login_lockout?: boolean | null
          id?: string
          ip_whitelist?: string[] | null
          login_alerts?: boolean | null
          max_failed_attempts?: number | null
          password_change_required?: boolean | null
          secure_sharing_only?: boolean | null
          session_timeout_minutes?: number | null
          suspicious_activity_alerts?: boolean | null
          two_factor_enabled?: boolean | null
          updated_at?: string
          user_id: string
        }
        Update: {
          api_access_enabled?: boolean | null
          audit_logging?: boolean | null
          auto_logout_inactive?: boolean | null
          created_at?: string
          device_management?: boolean | null
          download_restrictions?: boolean | null
          failed_login_lockout?: boolean | null
          id?: string
          ip_whitelist?: string[] | null
          login_alerts?: boolean | null
          max_failed_attempts?: number | null
          password_change_required?: boolean | null
          secure_sharing_only?: boolean | null
          session_timeout_minutes?: number | null
          suspicious_activity_alerts?: boolean | null
          two_factor_enabled?: boolean | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_sessions: {
        Row: {
          created_at: string | null
          device_info: string | null
          expires_at: string
          id: string
          ip_address: unknown | null
          is_active: boolean | null
          last_activity: string | null
          session_token: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          device_info?: string | null
          expires_at: string
          id?: string
          ip_address?: unknown | null
          is_active?: boolean | null
          last_activity?: string | null
          session_token: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          device_info?: string | null
          expires_at?: string
          id?: string
          ip_address?: unknown | null
          is_active?: boolean | null
          last_activity?: string | null
          session_token?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_sessions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_subscriptions: {
        Row: {
          created_at: string
          id: string
          subscribed_to_id: string
          subscriber_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          subscribed_to_id: string
          subscriber_id: string
        }
        Update: {
          created_at?: string
          id?: string
          subscribed_to_id?: string
          subscriber_id?: string
        }
        Relationships: []
      }
      user_website_settings: {
        Row: {
          auto_follow_uploaders: boolean | null
          bookmark_sync: boolean | null
          created_at: string
          default_view_mode: string | null
          enable_comments: boolean | null
          enable_likes: boolean | null
          id: string
          pdf_auto_download: boolean | null
          pdf_quality_preference: string | null
          reading_progress_tracking: boolean | null
          show_pdf_previews: boolean | null
          updated_at: string
          user_id: string
        }
        Insert: {
          auto_follow_uploaders?: boolean | null
          bookmark_sync?: boolean | null
          created_at?: string
          default_view_mode?: string | null
          enable_comments?: boolean | null
          enable_likes?: boolean | null
          id?: string
          pdf_auto_download?: boolean | null
          pdf_quality_preference?: string | null
          reading_progress_tracking?: boolean | null
          show_pdf_previews?: boolean | null
          updated_at?: string
          user_id: string
        }
        Update: {
          auto_follow_uploaders?: boolean | null
          bookmark_sync?: boolean | null
          created_at?: string
          default_view_mode?: string | null
          enable_comments?: boolean | null
          enable_likes?: boolean | null
          id?: string
          pdf_auto_download?: boolean | null
          pdf_quality_preference?: string | null
          reading_progress_tracking?: boolean | null
          show_pdf_previews?: boolean | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      cleanup_expired_edit_sessions: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      create_audit_log: {
        Args: {
          p_user_id: string
          p_action: Database["public"]["Enums"]["audit_action"]
          p_target_type?: string
          p_target_id?: string
          p_details?: Json
          p_ip_address?: unknown
          p_user_agent?: string
        }
        Returns: string
      }
      create_document_version: {
        Args: {
          p_document_id: string
          p_content: Json
          p_changes_summary?: string
          p_file_url?: string
          p_file_size?: number
        }
        Returns: string
      }
      create_notification: {
        Args: {
          target_user_id: string
          notification_title: string
          notification_message: string
          notification_type?: string
          notification_data?: Json
        }
        Returns: string
      }
      has_role: {
        Args: {
          p_user_id: string
          p_role: Database["public"]["Enums"]["user_role"]
        }
        Returns: boolean
      }
      increment_document_view_count: {
        Args: {
          document_uuid: string
          viewer_user_id?: string
          viewer_ip_address?: unknown
        }
        Returns: boolean
      }
      increment_pdf_view_count: {
        Args: {
          pdf_uuid: string
          viewer_user_id?: string
          viewer_ip_address?: unknown
        }
        Returns: boolean
      }
      mark_all_notifications_read: {
        Args: Record<PropertyKey, never>
        Returns: number
      }
      mark_notification_read: {
        Args: { notification_id: string }
        Returns: boolean
      }
      update_last_login: {
        Args: { p_user_id: string; p_ip_address?: unknown }
        Returns: undefined
      }
    }
    Enums: {
      audit_action:
        | "login"
        | "logout"
        | "create"
        | "update"
        | "delete"
        | "password_change"
        | "role_change"
        | "status_change"
      user_role: "admin" | "manager" | "user"
      user_status: "active" | "inactive" | "banned" | "pending_verification"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      audit_action: [
        "login",
        "logout",
        "create",
        "update",
        "delete",
        "password_change",
        "role_change",
        "status_change",
      ],
      user_role: ["admin", "manager", "user"],
      user_status: ["active", "inactive", "banned", "pending_verification"],
    },
  },
} as const
