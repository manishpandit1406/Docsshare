
import React, { useState } from 'react';
import { PDFBundle, BundleItem, useBundleItems, usePDFBundles } from '@/hooks/usePDFBundles';
import { useNavigate } from 'react-router-dom';
import { toast } from '@/hooks/use-toast';
import AddPDFToLibraryDialog from '@/components/AddPDFToLibraryDialog';
import LibraryHeader from '@/components/library/LibraryHeader';
import LibraryPDFList from '@/components/library/LibraryPDFList';

interface LibraryViewerProps {
  library: PDFBundle;
  onBack: () => void;
}

const LibraryViewer: React.FC<LibraryViewerProps> = ({ library, onBack }) => {
  const { data: items = [] } = useBundleItems(library.id);
  const { removePDFFromBundle } = usePDFBundles();
  const navigate = useNavigate();
  const [showAddPDFDialog, setShowAddPDFDialog] = useState(false);

  const handlePDFClick = (pdfId: string) => {
    navigate(`/document/${pdfId}`);
  };

  const handleRemovePDF = (pdfId: string) => {
    if (window.confirm('Remove this PDF from the library?')) {
      removePDFFromBundle({ bundleId: library.id, pdfId });
    }
  };

  const handleShare = async () => {
    const shareUrl = `${window.location.origin}/library/${library.id}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: library.name,
          text: library.description || 'Check out this PDF library',
          url: shareUrl,
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      try {
        await navigator.clipboard.writeText(shareUrl);
        toast({
          title: "Link copied",
          description: "Library link has been copied to clipboard"
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to copy link",
          variant: "destructive"
        });
      }
    }
  };

  const handleEditLibrary = () => {
    toast({
      title: "Coming Soon",
      description: "Library editing functionality will be available soon"
    });
  };

  const handleUpdateImage = () => {
    toast({
      title: "Coming Soon",
      description: "Image upload functionality will be available soon"
    });
  };

  return (
    <div className="space-y-6">
      <LibraryHeader
        library={library}
        itemCount={items.length}
        onAddPDFs={() => setShowAddPDFDialog(true)}
        onShare={handleShare}
        onEditLibrary={handleEditLibrary}
        onUpdateImage={handleUpdateImage}
      />

      <LibraryPDFList
        items={items}
        onAddPDFs={() => setShowAddPDFDialog(true)}
        onPDFClick={handlePDFClick}
        onRemovePDF={handleRemovePDF}
      />

      {showAddPDFDialog && (
        <AddPDFToLibraryDialog
          isOpen={showAddPDFDialog}
          onClose={() => setShowAddPDFDialog(false)}
          libraryId={library.id}
        />
      )}
    </div>
  );
};

export default LibraryViewer;
