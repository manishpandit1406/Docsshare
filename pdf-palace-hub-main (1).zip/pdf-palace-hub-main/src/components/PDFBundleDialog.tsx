
import React, { useState } from 'react';
import { Plus, FolderPlus, BookOpen } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { usePDFBundles } from '@/hooks/usePDFBundles';

interface PDFBundleDialogProps {
  trigger?: React.ReactNode;
  pdfId?: string;
}

const PDFBundleDialog: React.FC<PDFBundleDialogProps> = ({ trigger, pdfId }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [bundleName, setBundleName] = useState('');
  const [description, setDescription] = useState('');
  const [isPublic, setIsPublic] = useState(false);
  const { bundles, createBundle, addPDFToBundle, isCreating, isAdding } = usePDFBundles();

  const handleCreateBundle = () => {
    if (!bundleName.trim()) return;
    
    createBundle({ 
      name: bundleName, 
      description: description || undefined, 
      isPublic 
    });
    
    setBundleName('');
    setDescription('');
    setIsPublic(false);
    setIsOpen(false);
  };

  const handleAddToBundle = (bundleId: string) => {
    if (!pdfId) return;
    addPDFToBundle({ bundleId, pdfId });
    setIsOpen(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" size="sm">
            <BookOpen className="w-4 h-4 mr-2" />
            Add to Bundle
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>
            {pdfId ? 'Add to Bundle' : 'Create New Bundle'}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {pdfId && bundles.length > 0 && (
            <div>
              <Label className="text-sm font-medium">Existing Bundles</Label>
              <div className="mt-2 space-y-2 max-h-32 overflow-y-auto">
                {bundles.map((bundle) => (
                  <Button
                    key={bundle.id}
                    variant="outline"
                    size="sm"
                    onClick={() => handleAddToBundle(bundle.id)}
                    disabled={isAdding}
                    className="w-full justify-start"
                  >
                    <BookOpen className="w-4 h-4 mr-2" />
                    {bundle.name}
                  </Button>
                ))}
              </div>
              <div className="my-4 border-t pt-4">
                <Label className="text-sm font-medium">Or create a new bundle</Label>
              </div>
            </div>
          )}

          <div>
            <Label htmlFor="bundle-name">Bundle Name</Label>
            <Input
              id="bundle-name"
              value={bundleName}
              onChange={(e) => setBundleName(e.target.value)}
              placeholder="Enter bundle name"
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="bundle-description">Description (Optional)</Label>
            <Textarea
              id="bundle-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe your bundle"
              className="mt-1"
              rows={2}
            />
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="public-bundle"
              checked={isPublic}
              onCheckedChange={setIsPublic}
            />
            <Label htmlFor="public-bundle">Make bundle public</Label>
          </div>

          <Button 
            onClick={handleCreateBundle}
            disabled={!bundleName.trim() || isCreating}
            className="w-full"
          >
            <FolderPlus className="w-4 h-4 mr-2" />
            {isCreating ? 'Creating...' : 'Create Bundle'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default PDFBundleDialog;
