
import React, { useState } from 'react';
import { Search, Plus, BookOpen } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { usePDFs } from '@/hooks/usePDFs';
import { usePDFBundles } from '@/hooks/usePDFBundles';
import { toast } from '@/hooks/use-toast';

interface AddPDFToLibraryDialogProps {
  isOpen: boolean;
  onClose: () => void;
  libraryId: string;
}

const AddPDFToLibraryDialog: React.FC<AddPDFToLibraryDialogProps> = ({
  isOpen,
  onClose,
  libraryId
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const { pdfs } = usePDFs();
  const { addPDFToBundle, isAdding } = usePDFBundles();

  const filteredPDFs = pdfs.filter(pdf => 
    pdf.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    pdf.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddPDF = async (pdfId: string) => {
    try {
      addPDFToBundle({ bundleId: libraryId, pdfId });
      toast({
        title: "PDF Added",
        description: "PDF has been added to the library"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add PDF to library",
        variant: "destructive"
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Plus className="w-5 h-5" />
            <span>Add PDFs to Library</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <Input
              placeholder="Search your PDFs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* PDF Grid */}
          <div className="max-h-[50vh] overflow-y-auto">
            {filteredPDFs.length === 0 ? (
              <div className="text-center py-12">
                <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  {searchQuery ? 'No PDFs found' : 'No PDFs available'}
                </h3>
                <p className="text-gray-500">
                  {searchQuery 
                    ? 'Try adjusting your search terms' 
                    : 'Upload some PDFs first to add them to your library'
                  }
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredPDFs.map((pdf) => (
                  <Card key={pdf.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start space-x-3">
                        <div className="flex-shrink-0">
                          <div className="w-16 h-20 bg-gray-100 rounded overflow-hidden">
                            {pdf.thumbnail_url ? (
                              <img 
                                src={pdf.thumbnail_url} 
                                alt={pdf.title}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center">
                                <BookOpen className="w-6 h-6 text-gray-400" />
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-sm line-clamp-2 mb-1">
                            {pdf.title}
                          </h4>
                          {pdf.description && (
                            <p className="text-xs text-gray-600 line-clamp-2 mb-2">
                              {pdf.description}
                            </p>
                          )}
                          <Button
                            size="sm"
                            onClick={() => handleAddPDF(pdf.id)}
                            disabled={isAdding}
                            className="w-full"
                          >
                            <Plus className="w-3 h-3 mr-1" />
                            Add
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AddPDFToLibraryDialog;
