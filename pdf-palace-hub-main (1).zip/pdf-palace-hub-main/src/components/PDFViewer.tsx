
import React, { useState, useEffect } from 'react';
import { X, Download, Heart, MessageCircle, Bookmark } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { usePDFInteractions } from '@/hooks/usePDFInteractions';
import { useWishlist } from '@/hooks/useWishlist';
import { useAuth } from '@/contexts/AuthContext';
import type { PDF } from '@/types/pdf';

interface PDFViewerProps {
  pdf: PDF | null;
  isOpen: boolean;
  onClose: () => void;
}

const PDFViewer: React.FC<PDFViewerProps> = ({ pdf, isOpen, onClose }) => {
  const [comment, setComment] = useState('');
  const { user } = useAuth();
  const { hasLiked, comments, loading, toggleLike, addComment } = usePDFInteractions(pdf?.id || '');
  const { isInWishlist, addToWishlist, removeFromWishlist } = useWishlist();

  const handleAddComment = async () => {
    if (!comment.trim()) return;
    await addComment(comment);
    setComment('');
  };

  const handleWishlistToggle = async () => {
    if (!pdf) return;
    
    if (isInWishlist(pdf.id)) {
      await removeFromWishlist(pdf.id);
    } else {
      await addToWishlist(pdf.id);
    }
  };

  if (!pdf) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold">{pdf.title}</h2>
              <p className="text-sm text-gray-600 mt-1">{pdf.description}</p>
            </div>
            <div className="flex items-center space-x-2">
              {user && (
                <>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={toggleLike}
                    disabled={loading}
                    className={hasLiked ? "text-red-600" : ""}
                  >
                    <Heart className={`w-4 h-4 ${hasLiked ? "fill-current" : ""}`} />
                    <span className="ml-1">{pdf.likes_count}</span>
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleWishlistToggle}
                    className={isInWishlist(pdf.id) ? "text-blue-600" : ""}
                  >
                    <Bookmark className={`w-4 h-4 ${isInWishlist(pdf.id) ? "fill-current" : ""}`} />
                  </Button>
                </>
              )}
              
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4" />
              </Button>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex gap-4 overflow-hidden">
          {/* PDF Viewer */}
          <div className="flex-1 bg-gray-100 rounded-lg overflow-hidden">
            <iframe
              src={pdf.file_url}
              className="w-full h-full"
              title={pdf.title}
            />
          </div>

          {/* Comments Section */}
          <div className="w-80 flex flex-col space-y-4">
            <div className="flex items-center space-x-4 text-sm text-gray-600">
              <span className="flex items-center space-x-1">
                <MessageCircle className="w-4 h-4" />
                <span>{pdf.comments_count} comments</span>
              </span>
              <span>{pdf.views_count} views</span>
            </div>

            {pdf.tags && pdf.tags.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {pdf.tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>
            )}

            {user && (
              <div className="space-y-2">
                <Textarea
                  placeholder="Add a comment..."
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  className="resize-none"
                  rows={3}
                />
                <Button onClick={handleAddComment} size="sm" className="w-full">
                  Post Comment
                </Button>
              </div>
            )}

            <div className="flex-1 overflow-y-auto space-y-3">
              {comments.map((comment) => (
                <Card key={comment.id}>
                  <CardContent className="p-3">
                    <div className="flex items-start justify-between mb-2">
                      <span className="font-medium text-sm">
                        {comment.profiles?.full_name || comment.profiles?.username || 'Anonymous'}
                      </span>
                      <span className="text-xs text-gray-500">
                        {new Date(comment.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-sm text-gray-700">{comment.content}</p>
                  </CardContent>
                </Card>
              ))}
              
              {comments.length === 0 && (
                <p className="text-center text-gray-500 text-sm">No comments yet</p>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default PDFViewer;
