
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { usePDFRenderer } from '@/components/pdf-viewer/usePDFRenderer';
import PDFViewerHeader from '@/components/pdf-viewer/PDFViewerHeader';
import PDFViewerContent from '@/components/pdf-viewer/PDFViewerContent';
import PDFPageNavigation from '@/components/pdf-viewer/PDFPageNavigation';
import type { PDF } from '@/types/pdf';

interface FullscreenPDFViewerProps {
  pdf: PDF;
  isOpen: boolean;
  onClose: () => void;
}

const FullscreenPDFViewer: React.FC<FullscreenPDFViewerProps> = ({ pdf, isOpen, onClose }) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);

  const {
    currentPage,
    setCurrentPage,
    totalPages,
    zoom,
    setZoom,
    rotation,
    setRotation,
    pageImages,
    loading,
    error,
    pageInput,
    setPageInput,
    renderingPage,
    retryRender
  } = usePDFRenderer({ pdf, isOpen });

  const handleZoomIn = () => {
    setZoom(prev => Math.min(3, prev + 0.25));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(0.5, prev - 0.25));
  };

  const handleRotate = () => {
    setRotation(prev => (prev + 90) % 360);
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = pdf.file_url;
    link.download = pdf.title + '.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const goToPreviousPage = () => {
    if (currentPage > 1) {
      const newPage = currentPage - 1;
      console.log(`Navigating to previous page: ${newPage}`);
      setCurrentPage(newPage);
      setPageInput(newPage.toString());
    }
  };

  const goToNextPage = () => {
    if (currentPage < totalPages) {
      const newPage = currentPage + 1;
      console.log(`Navigating to next page: ${newPage}`);
      setCurrentPage(newPage);
      setPageInput(newPage.toString());
    }
  };

  const goToFirstPage = () => {
    if (currentPage !== 1) {
      console.log('Navigating to first page');
      setCurrentPage(1);
      setPageInput('1');
    }
  };

  const goToLastPage = () => {
    if (currentPage !== totalPages) {
      console.log(`Navigating to last page: ${totalPages}`);
      setCurrentPage(totalPages);
      setPageInput(totalPages.toString());
    }
  };

  const handlePageInputChange = (value: string) => {
    setPageInput(value);
  };

  const handlePageInputSubmit = () => {
    const pageNum = parseInt(pageInput);
    if (pageNum >= 1 && pageNum <= totalPages && pageNum !== currentPage) {
      console.log(`Navigating to page: ${pageNum}`);
      setCurrentPage(pageNum);
    } else {
      setPageInput(currentPage.toString());
    }
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const handleZoomSlider = (value: number[]) => {
    setZoom(value[0]);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black">
      <PDFViewerHeader
        pdf={pdf}
        currentPage={currentPage}
        totalPages={totalPages}
        zoom={zoom}
        rotation={rotation}
        loading={loading}
        showControls={showControls}
        isFullscreen={isFullscreen}
        onClose={onClose}
        onZoomIn={handleZoomIn}
        onZoomOut={handleZoomOut}
        onRotate={handleRotate}
        onDownload={handleDownload}
        onPreviousPage={goToPreviousPage}
        onNextPage={goToNextPage}
        onFirstPage={goToFirstPage}
        onLastPage={goToLastPage}
        onToggleFullscreen={toggleFullscreen}
        onZoomChange={handleZoomSlider}
      />

      <PDFViewerContent
        pdf={pdf}
        currentPage={currentPage}
        zoom={zoom}
        rotation={rotation}
        pageImages={pageImages}
        loading={loading}
        error={error}
        renderingPage={renderingPage}
        showControls={showControls}
        onRetryRender={retryRender}
      />

      <PDFPageNavigation
        currentPage={currentPage}
        totalPages={totalPages}
        pageInput={pageInput}
        loading={loading}
        error={error}
        showControls={showControls}
        onPreviousPage={goToPreviousPage}
        onNextPage={goToNextPage}
        onPageInputChange={handlePageInputChange}
        onPageInputSubmit={handlePageInputSubmit}
      />

      {!showControls && (
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowControls(true)}
          className="absolute top-4 right-4 bg-black/60 backdrop-blur-sm border-white/20 text-white hover:bg-black/80"
          title="Show controls"
        >
          Show Controls
        </Button>
      )}
    </div>
  );
};

export default FullscreenPDFViewer;
