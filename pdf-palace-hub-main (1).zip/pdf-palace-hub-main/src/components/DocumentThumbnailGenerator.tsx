
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Upload, FileText, File, Image } from 'lucide-react';

interface DocumentThumbnailGeneratorProps {
  file: File;
  onThumbnailGenerated: (thumbnail: string) => void;
  onCustomThumbnail: (file: File) => void;
}

const DocumentThumbnailGenerator: React.FC<DocumentThumbnailGeneratorProps> = ({
  file,
  onThumbnailGenerated,
  onCustomThumbnail
}) => {
  const [generatedThumbnail, setGeneratedThumbnail] = useState<string | null>(null);
  const [customThumbnail, setCustomThumbnail] = useState<File | null>(null);

  useEffect(() => {
    generateThumbnailFromFile();
  }, [file]);

  const getFileTypeInfo = (file: File) => {
    const extension = file.name.split('.').pop()?.toLowerCase() || '';
    const mimeType = file.type;

    const typeMap: Record<string, { color: string; icon: any; label: string }> = {
      'pdf': { color: '#dc2626', icon: FileText, label: 'PDF' },
      'doc': { color: '#2563eb', icon: FileText, label: 'Word' },
      'docx': { color: '#2563eb', icon: FileText, label: 'Word' },
      'xls': { color: '#16a34a', icon: File, label: 'Excel' },
      'xlsx': { color: '#16a34a', icon: File, label: 'Excel' },
      'ppt': { color: '#ea580c', icon: File, label: 'PowerPoint' },
      'pptx': { color: '#ea580c', icon: File, label: 'PowerPoint' },
      'txt': { color: '#6b7280', icon: File, label: 'Text' },
      'rtf': { color: '#6b7280', icon: File, label: 'RTF' },
      'odt': { color: '#0891b2', icon: File, label: 'ODT' }
    };

    return typeMap[extension] || { color: '#6b7280', icon: File, label: 'Document' };
  };

  const generateThumbnailFromFile = async () => {
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = 200;
      canvas.height = 280;
      
      if (ctx) {
        const fileInfo = getFileTypeInfo(file);
        
        // Background
        ctx.fillStyle = '#f8fafc';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Border
        ctx.strokeStyle = '#e2e8f0';
        ctx.lineWidth = 2;
        ctx.strokeRect(0, 0, canvas.width, canvas.height);
        
        // File type color bar
        ctx.fillStyle = fileInfo.color;
        ctx.fillRect(0, 0, canvas.width, 8);
        
        // Icon area background
        ctx.fillStyle = '#f1f5f9';
        ctx.fillRect(20, 30, canvas.width - 40, 120);
        
        // File type text
        ctx.fillStyle = fileInfo.color;
        ctx.font = 'bold 24px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(fileInfo.label, canvas.width / 2, 100);
        
        // File name
        ctx.fillStyle = '#334155';
        ctx.font = '12px Arial';
        const fileName = file.name.length > 25 ? file.name.substring(0, 22) + '...' : file.name;
        ctx.fillText(fileName, canvas.width / 2, 180);
        
        // File size
        const fileSize = (file.size / (1024 * 1024)).toFixed(2) + ' MB';
        ctx.fillStyle = '#64748b';
        ctx.font = '10px Arial';
        ctx.fillText(fileSize, canvas.width / 2, 200);
        
        // Extension badge
        ctx.fillStyle = fileInfo.color;
        ctx.fillRect(canvas.width - 60, 220, 50, 20);
        ctx.fillStyle = 'white';
        ctx.font = 'bold 10px Arial';
        ctx.fillText(file.name.split('.').pop()?.toUpperCase() || '', canvas.width - 35, 232);
        
        const thumbnail = canvas.toDataURL('image/jpeg', 0.8);
        setGeneratedThumbnail(thumbnail);
        onThumbnailGenerated(thumbnail);
      }
    } catch (error) {
      console.error('Error generating thumbnail:', error);
    }
  };

  const handleCustomThumbnailUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      setCustomThumbnail(file);
      onCustomThumbnail(file);
      
      // Also create a preview
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setGeneratedThumbnail(e.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-4">
        {generatedThumbnail && (
          <div className="flex-1">
            <label className="block text-sm font-medium mb-2">
              {customThumbnail ? 'Custom Thumbnail' : 'Generated Thumbnail'}
            </label>
            <div className="relative">
              <img 
                src={generatedThumbnail} 
                alt="Document thumbnail" 
                className="w-24 h-32 object-cover rounded border shadow-sm"
              />
              {customThumbnail && (
                <div className="absolute -top-1 -right-1 bg-green-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                  ✓
                </div>
              )}
            </div>
          </div>
        )}
        
        <div className="flex-1">
          <label className="block text-sm font-medium mb-2">Custom Thumbnail (Optional)</label>
          <input
            type="file"
            accept="image/*"
            onChange={handleCustomThumbnailUpload}
            className="hidden"
            id="custom-thumbnail"
          />
          <Button
            type="button"
            variant="outline"
            onClick={() => document.getElementById('custom-thumbnail')?.click()}
            className="w-full"
          >
            <Upload className="w-4 h-4 mr-2" />
            Upload Custom
          </Button>
          {customThumbnail && (
            <p className="text-sm text-green-600 mt-1">{customThumbnail.name}</p>
          )}
          <p className="text-xs text-gray-500 mt-1">
            Upload a custom image to use as thumbnail
          </p>
        </div>
      </div>
    </div>
  );
};

export default DocumentThumbnailGenerator;
