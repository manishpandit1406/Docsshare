
import React from 'react';
import NavigationBar from './NavigationBar';
import Footer from './Footer';

interface LayoutProps {
  children: React.ReactNode;
  showNavigation?: boolean;
  showFooter?: boolean;
  showSearchBar?: boolean;
  onSearch?: (query: string) => void;
  searchPlaceholder?: string;
}

const Layout: React.FC<LayoutProps> = ({ 
  children, 
  showNavigation = true, 
  showFooter = true,
  showSearchBar = false,
  onSearch,
  searchPlaceholder = "Search PDFs or users..."
}) => {
  return (
    <div className="min-h-screen flex flex-col">
      {showNavigation && (
        <NavigationBar 
          showSearchBar={showSearchBar}
          onSearch={onSearch}
          searchPlaceholder={searchPlaceholder}
        />
      )}
      <main className="flex-1">
        {children}
      </main>
      {showFooter && <Footer />}
    </div>
  );
};

export default Layout;
