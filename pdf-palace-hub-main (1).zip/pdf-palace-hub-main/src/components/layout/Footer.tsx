
import React from 'react';
import { FileText, Github, Twitter, Mail, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const Footer = () => {
  const navigate = useNavigate();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <FileText className="w-8 h-8 text-blue-600" />
              <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                PDFShare
              </h2>
            </div>
            <p className="text-gray-600 dark:text-gray-400 mb-4 max-w-md">
              Share, discover, and explore amazing PDFs from the community. 
              Upload your documents and connect with others who share your interests.
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="sm" className="text-gray-600 hover:text-blue-600">
                <Github className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-600 hover:text-blue-600">
                <Twitter className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-600 hover:text-blue-600">
                <Mail className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Button 
                  variant="ghost" 
                  onClick={() => navigate('/')}
                  className="text-gray-600 dark:text-gray-400 hover:text-blue-600 p-0 h-auto font-normal justify-start"
                >
                  Home
                </Button>
              </li>
              <li>
                <Button 
                  variant="ghost" 
                  onClick={() => navigate('/explore')}
                  className="text-gray-600 dark:text-gray-400 hover:text-blue-600 p-0 h-auto font-normal justify-start"
                >
                  Explore PDFs
                </Button>
              </li>
              <li>
                <Button 
                  variant="ghost" 
                  onClick={() => navigate('/upload')}
                  className="text-gray-600 dark:text-gray-400 hover:text-blue-600 p-0 h-auto font-normal justify-start"
                >
                  Upload PDF
                </Button>
              </li>
              <li>
                <Button 
                  variant="ghost" 
                  onClick={() => navigate('/auth')}
                  className="text-gray-600 dark:text-gray-400 hover:text-blue-600 p-0 h-auto font-normal justify-start"
                >
                  Sign Up
                </Button>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Support</h3>
            <ul className="space-y-2">
              <li>
                <Button 
                  variant="ghost" 
                  className="text-gray-600 dark:text-gray-400 hover:text-blue-600 p-0 h-auto font-normal justify-start"
                >
                  Help Center
                </Button>
              </li>
              <li>
                <Button 
                  variant="ghost" 
                  className="text-gray-600 dark:text-gray-400 hover:text-blue-600 p-0 h-auto font-normal justify-start"
                >
                  Contact Us
                </Button>
              </li>
              <li>
                <Button 
                  variant="ghost" 
                  className="text-gray-600 dark:text-gray-400 hover:text-blue-600 p-0 h-auto font-normal justify-start"
                >
                  Privacy Policy
                </Button>
              </li>
              <li>
                <Button 
                  variant="ghost" 
                  className="text-gray-600 dark:text-gray-400 hover:text-blue-600 p-0 h-auto font-normal justify-start"
                >
                  Terms of Service
                </Button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-8 pt-8 border-t border-gray-200 dark:border-gray-700">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-600 dark:text-gray-400 text-sm">
              © {currentYear} PDFShare. All rights reserved.
            </p>
            <p className="text-gray-600 dark:text-gray-400 text-sm flex items-center mt-2 md:mt-0">
              Made with <Heart className="w-4 h-4 mx-1 text-red-500" /> for the community
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
