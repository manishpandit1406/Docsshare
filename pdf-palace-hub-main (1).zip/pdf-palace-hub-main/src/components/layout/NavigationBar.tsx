
import React, { useState } from 'react';
import { FileText, User, LogIn, Search, Upload, BookOpen, Bookmark, Bell, Settings, LayoutDashboard, LogOut, Crown, Plus, Edit, MoreHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Input } from '@/components/ui/input';
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Badge } from '@/components/ui/badge';
import NotificationsDropdown from '@/components/NotificationsDropdown';
import { useNotifications } from '@/hooks/useNotifications';

interface NavigationBarProps {
  showSearchBar?: boolean;
  onSearch?: (query: string) => void;
  searchPlaceholder?: string;
}

const NavigationBar: React.FC<NavigationBarProps> = ({ 
  showSearchBar = true, 
  onSearch,
  searchPlaceholder = "Search documents, libraries, or users..." 
}) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, signOut } = useAuth();
  const { unreadCount } = useNotifications();
  const [searchQuery, setSearchQuery] = useState('');
  const [createMenuOpen, setCreateMenuOpen] = useState(false);

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const handleSearch = (query: string) => {
    const trimmedQuery = query.trim();
    if (trimmedQuery) {
      // Clear the search input
      setSearchQuery('');
      // Navigate to search page with query
      navigate(`/search?q=${encodeURIComponent(trimmedQuery)}`);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSearch(searchQuery);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSearch(searchQuery);
  };

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="bg-white shadow-sm border-b sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div 
            className="flex items-center space-x-2 cursor-pointer" 
            onClick={() => navigate('/')}
          >
            <FileText className="w-8 h-8 text-blue-600" />
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              PDFShare
            </h1>
          </div>

          {/* Enhanced Search Bar */}
          {showSearchBar && (
            <div className="flex-1 max-w-2xl mx-8">
              <form onSubmit={handleSearchSubmit} className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="text"
                  placeholder={searchPlaceholder}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="pl-10 pr-4 py-2 w-full bg-gray-50 border-gray-200 focus:bg-white focus:border-blue-500 rounded-full transition-all duration-200"
                />
              </form>
            </div>
          )}

          {/* Navigation Items */}
          <div className="hidden md:flex items-center space-x-1">
            <Button 
              variant={isActive('/') ? "default" : "ghost"} 
              onClick={() => navigate('/')}
              className={isActive('/') 
                ? "bg-blue-100 text-blue-700 hover:bg-blue-200 dark:bg-blue-900 dark:text-blue-300 dark:hover:bg-blue-800" 
                : "text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800"
              }
            >
              Home
            </Button>
            
            {user ? (
              <>
                {/* Create Dropdown Menu - Same style as Account */}
                <NavigationMenu>
                  <NavigationMenuList>
                    <NavigationMenuItem>
                      <NavigationMenuTrigger 
                        className={`flex items-center space-x-2 ${createMenuOpen ? "bg-green-100 text-green-700 hover:bg-green-200 dark:bg-green-900 dark:text-green-300 dark:hover:bg-green-800" : ""}`}
                        onClick={() => setCreateMenuOpen(!createMenuOpen)}
                      >
                        <Plus className="w-4 h-4" />
                        <span>Create</span>
                      </NavigationMenuTrigger>
                      <NavigationMenuContent className="p-4 w-48">
                        <div className="flex flex-col space-y-2">
                          <Button 
                            variant="ghost" 
                            onClick={() => navigate('/upload')}
                            className="justify-start hover:bg-gray-100 dark:hover:bg-gray-800"
                          >
                            <Upload className="w-4 h-4 mr-2" />
                            Upload Document
                          </Button>
                          <Button 
                            variant="ghost" 
                            onClick={() => navigate('/edit-document')}
                            className="justify-start hover:bg-gray-100 dark:hover:bg-gray-800"
                          >
                            <Edit className="w-4 h-4 mr-2" />
                            Edit Document
                          </Button>
                          <Button 
                            variant="ghost" 
                            onClick={() => navigate('/create-library')}
                            className="justify-start hover:bg-gray-100 dark:hover:bg-gray-800"
                          >
                            <BookOpen className="w-4 h-4 mr-2" />
                            Create Library
                          </Button>
                          <Button 
                            variant="ghost"
                            className="justify-start hover:bg-gray-100 dark:hover:bg-gray-800"
                          >
                            <MoreHorizontal className="w-4 h-4 mr-2" />
                            More Options
                          </Button>
                        </div>
                      </NavigationMenuContent>
                    </NavigationMenuItem>
                  </NavigationMenuList>
                </NavigationMenu>

                <Button 
                  variant={isActive('/wishlist') ? "default" : "ghost"} 
                  onClick={() => navigate('/wishlist')}
                  className={isActive('/wishlist') 
                    ? "bg-pink-100 text-pink-700 hover:bg-pink-200 dark:bg-pink-900 dark:text-pink-300 dark:hover:bg-pink-800" 
                    : "text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800"
                  }
                >
                  <Bookmark className="w-4 h-4 mr-2" />
                  Saved
                </Button>
                
                {/* User Menu with Notifications */}
                <NavigationMenu>
                  <NavigationMenuList>
                    <NavigationMenuItem>
                      <NavigationMenuTrigger className="flex items-center space-x-2">
                        <User className="w-4 h-4" />
                        <span>Account</span>
                        {unreadCount > 0 && (
                          <Badge 
                            variant="destructive" 
                            className="h-5 w-5 flex items-center justify-center p-0 text-xs ml-1"
                          >
                            {unreadCount > 9 ? '9+' : unreadCount}
                          </Badge>
                        )}
                      </NavigationMenuTrigger>
                      <NavigationMenuContent className="p-4 w-48">
                        <div className="flex flex-col space-y-2">
                          <Button 
                            variant="outline" 
                            onClick={() => navigate('/upgrade')}
                            className="justify-start bg-gradient-to-r from-amber-50 to-yellow-50 hover:from-amber-100 hover:to-yellow-100 border-amber-200 text-amber-800"
                          >
                            <Crown className="w-4 h-4 mr-2 text-amber-600" />
                            Upgrade to Pro
                          </Button>
                          <NotificationsDropdown 
                            trigger={
                              <Button variant="ghost" className="justify-start relative">
                                <Bell className="w-4 h-4 mr-2" />
                                Notifications
                                {unreadCount > 0 && (
                                  <Badge 
                                    variant="destructive" 
                                    className="h-4 w-4 flex items-center justify-center p-0 text-xs ml-auto"
                                  >
                                    {unreadCount > 9 ? '9+' : unreadCount}
                                  </Badge>
                                )}
                              </Button>
                            }
                          />
                          <Button 
                            variant="ghost" 
                            onClick={() => navigate('/dashboard')}
                            className={isActive('/dashboard') 
                              ? "justify-start bg-indigo-100 text-indigo-700 hover:bg-indigo-200 dark:bg-indigo-900 dark:text-indigo-300 dark:hover:bg-indigo-800" 
                              : "justify-start hover:bg-gray-100 dark:hover:bg-gray-800"
                            }
                          >
                            <LayoutDashboard className="w-4 h-4 mr-2" />
                            Dashboard
                          </Button>
                          <Button 
                            variant="ghost" 
                            onClick={() => navigate('/profile-settings')}
                            className={isActive('/profile-settings') 
                              ? "justify-start bg-teal-100 text-teal-700 hover:bg-teal-200 dark:bg-teal-900 dark:text-teal-300 dark:hover:bg-teal-800" 
                              : "justify-start hover:bg-gray-100 dark:hover:bg-gray-800"
                            }
                          >
                            <Settings className="w-4 h-4 mr-2" />
                            Settings
                          </Button>
                          <Button 
                            variant="ghost" 
                            onClick={handleSignOut}
                            className="justify-start text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
                          >
                            <LogOut className="w-4 h-4 mr-2" />
                            Sign Out
                          </Button>
                        </div>
                      </NavigationMenuContent>
                    </NavigationMenuItem>
                  </NavigationMenuList>
                </NavigationMenu>
              </>
            ) : (
              <Button 
                onClick={() => navigate('/auth')}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <LogIn className="w-4 h-4 mr-2" />
                Sign In
              </Button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center space-x-2">
            {/* Mobile Search Bar */}
            {showSearchBar && (
              <div className="flex-1 max-w-xs">
                <form onSubmit={handleSearchSubmit} className="relative">
                  <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    type="text"
                    placeholder="Search..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyPress={handleKeyPress}
                    className="pl-8 pr-2 py-1 text-sm w-full bg-gray-50 border-gray-200 focus:bg-white focus:border-blue-500 rounded-full"
                  />
                </form>
              </div>
            )}
            
            {user ? (
              <>
                {/* Mobile Create Button */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      <Plus className="w-5 h-5" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48 bg-white shadow-lg border">
                    <DropdownMenuItem onClick={() => navigate('/upload')}>
                      <Upload className="w-4 h-4 mr-2" />
                      Upload Document
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('/edit-document')}>
                      <Edit className="w-4 h-4 mr-2" />
                      Edit Document
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => navigate('/create-library')}>
                      <BookOpen className="w-4 h-4 mr-2" />
                      Create Library
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                {/* Mobile User Menu with Notification Badge */}
                <Button 
                  variant="ghost" 
                  onClick={() => navigate('/dashboard')}
                  className={`relative ${isActive('/dashboard') 
                    ? "bg-indigo-100 text-indigo-700 hover:bg-indigo-200 dark:bg-indigo-900 dark:text-indigo-300" 
                    : "text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800"
                  }`}
                >
                  <User className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <Badge 
                      variant="destructive" 
                      className="absolute -top-1 -right-1 h-4 w-4 flex items-center justify-center p-0 text-xs"
                    >
                      {unreadCount > 9 ? '9+' : unreadCount}
                    </Badge>
                  )}
                </Button>
              </>
            ) : (
              <Button 
                onClick={() => navigate('/auth')}
                size="sm"
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                Sign In
              </Button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default NavigationBar;
