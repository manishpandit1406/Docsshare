
import React from 'react';
import { Library, Plus } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { usePDFBundles } from '@/hooks/usePDFBundles';
import LibraryCard from '@/components/LibraryCard';
import PDFBundleDialog from '@/components/PDFBundleDialog';
import { useNavigate } from 'react-router-dom';

const MyLibrariesSection: React.FC = () => {
  const { bundles, isLoading, deleteBundle } = usePDFBundles();
  const navigate = useNavigate();

  const handleDeleteBundle = (bundleId: string, bundleName: string) => {
    if (window.confirm(`Are you sure you want to delete "${bundleName}"?`)) {
      deleteBundle(bundleId);
    }
  };

  const handleLibraryClick = (bundleId: string) => {
    navigate(`/library/${bundleId}`);
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Library className="w-5 h-5" />
            <span>My Libraries</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Library className="w-5 h-5" />
            <span>My Libraries</span>
            <span className="text-sm font-normal text-gray-500">({bundles.length})</span>
          </div>
          <PDFBundleDialog 
            trigger={
              <Button size="sm">
                <Plus className="w-4 h-4 mr-2" />
                Create Library
              </Button>
            }
          />
        </CardTitle>
      </CardHeader>
      <CardContent>
        {bundles.length === 0 ? (
          <div className="text-center py-12">
            <Library className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No libraries yet</h3>
            <p className="text-gray-500 mb-4">Create your first library to organize your PDFs</p>
            <PDFBundleDialog 
              trigger={
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Library
                </Button>
              }
            />
          </div>
        ) : (
          <div className="space-y-3">
            {bundles.slice(0, 6).map((bundle) => (
              <LibraryCard 
                key={bundle.id}
                library={bundle}
                onClick={() => handleLibraryClick(bundle.id)}
                showActions={true}
                onDelete={() => handleDeleteBundle(bundle.id, bundle.name)}
              />
            ))}
          </div>
        )}
        
        {bundles.length > 6 && (
          <div className="mt-4 text-center">
            <Button 
              variant="outline" 
              onClick={() => navigate('/my-bundles')}
            >
              View All Libraries ({bundles.length})
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default MyLibrariesSection;
