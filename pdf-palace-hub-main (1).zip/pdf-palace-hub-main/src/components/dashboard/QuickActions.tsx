
import React from 'react';
import { Upload, Eye, Bookmark, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface QuickActionsProps {
  onNavigate: (path: string) => void;
  onViewSubscriptions: () => void;
  subscriptionsCount: number;
}

const QuickActions: React.FC<QuickActionsProps> = ({
  onNavigate,
  onViewSubscriptions,
  subscriptionsCount
}) => {
  return (
    <Card className="mb-8">
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-4">
          <Button onClick={() => onNavigate('/upload')}>
            <Upload className="w-4 h-4 mr-2" />
            Upload New PDF
          </Button>
          <Button variant="outline" onClick={() => onNavigate('/explore')}>
            <Eye className="w-4 h-4 mr-2" />
            Explore PDFs
          </Button>
          <Button variant="outline" onClick={() => onNavigate('/wishlist')}>
            <Bookmark className="w-4 h-4 mr-2" />
            View Wishlist
          </Button>
          <Button variant="outline" onClick={onViewSubscriptions}>
            <Users className="w-4 h-4 mr-2" />
            View Subscriptions ({subscriptionsCount})
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default QuickActions;
