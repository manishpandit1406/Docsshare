
import React from 'react';
import { FileText, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import PDFCard from '@/components/PDFCard';
import type { PDF } from '@/types/pdf';

interface MyPDFsSectionProps {
  loading: boolean;
  userPDFs: PDF[];
  onNavigate: (path: string) => void;
  onDeletePDF: (pdfId: string) => void;
  onViewProfile: (userId: string) => void;
}

const MyPDFsSection: React.FC<MyPDFsSectionProps> = ({
  loading,
  userPDFs,
  onNavigate,
  onDeletePDF,
  onViewProfile
}) => {
  const handleEditPDF = (pdf: PDF) => {
    // Navigate to edit page with PDF ID
    onNavigate(`/upload?edit=${pdf.id}`);
  };

  if (loading) {
    return (
      <Card className="p-12 text-center">
        <CardContent>
          <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h4 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
            Loading PDFs...
          </h4>
        </CardContent>
      </Card>
    );
  }

  if (userPDFs.length === 0) {
    return (
      <Card className="p-12 text-center">
        <CardContent>
          <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h4 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
            No PDFs uploaded yet
          </h4>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Share your knowledge by uploading your first PDF!
          </p>
          <Button onClick={() => onNavigate('/upload')}>
            <Plus className="w-4 h-4 mr-2" />
            Upload PDF
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <section className="mt-8">
      <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
        My PDFs
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {userPDFs.map((pdf) => (
          <PDFCard
            key={pdf.id}
            pdf={pdf}
            onView={() => onNavigate(`/pdf/${pdf.id}`)}
            onEdit={handleEditPDF}
            onDelete={onDeletePDF}
            onViewProfile={onViewProfile}
            showActions={false}
            showEditDelete={true}
          />
        ))}
      </div>
    </section>
  );
};

export default MyPDFsSection;
