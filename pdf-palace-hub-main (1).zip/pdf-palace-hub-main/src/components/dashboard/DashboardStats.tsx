
import React from 'react';
import { FileText, Eye, Heart, MessageCircle, Users } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

interface DashboardStatsProps {
  totalPDFs: number;
  totalViews: number;
  totalLikes: number;
  totalComments: number;
  subscribersCount: number;
}

const DashboardStats: React.FC<DashboardStatsProps> = ({
  totalPDFs,
  totalViews,
  totalLikes,
  totalComments,
  subscribersCount
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total PDFs</p>
              <p className="text-2xl font-bold">{totalPDFs}</p>
            </div>
            <FileText className="w-8 h-8 text-blue-600" />
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Views</p>
              <p className="text-2xl font-bold">{totalViews}</p>
            </div>
            <Eye className="w-8 h-8 text-green-600" />
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Likes</p>
              <p className="text-2xl font-bold">{totalLikes}</p>
            </div>
            <Heart className="w-8 h-8 text-red-600" />
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Comments</p>
              <p className="text-2xl font-bold">{totalComments}</p>
            </div>
            <MessageCircle className="w-8 h-8 text-purple-600" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Subscribers</p>
              <p className="text-2xl font-bold">{subscribersCount}</p>
            </div>
            <Users className="w-8 h-8 text-indigo-600" />
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DashboardStats;
