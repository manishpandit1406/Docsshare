
import React from 'react';
import { User, Users, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

interface DashboardHeaderProps {
  user: any;
  wishlistCount: number;
  onNavigate: (path: string) => void;
  onSignOut: () => void;
  onViewSubscriptions: () => void;
  totalComments?: number;
}

const DashboardHeader: React.FC<DashboardHeaderProps> = ({
  user,
  wishlistCount,
  onNavigate,
  onSignOut,
  onViewSubscriptions,
  totalComments = 0
}) => {
  // Get user's full name with fallback
  const getUserFullName = () => {
    if (user?.profiles?.full_name) return user.profiles.full_name;
    if (user?.user_metadata?.full_name) return user.user_metadata.full_name;
    return user?.email?.split('@')[0] || 'User';
  };

  // Get username with @ prefix
  const getUsername = () => {
    if (user?.profiles?.username) return `@${user.profiles.username}`;
    return '@username';
  };

  const getUserInitials = () => {
    const fullName = getUserFullName();
    return fullName.split(' ').map(name => name[0]).join('').slice(0, 2).toUpperCase();
  };

  const getAvatarUrl = () => {
    return user?.profiles?.avatar_url || user?.user_metadata?.avatar_url;
  };

  const getCoverImageUrl = () => {
    return user?.profiles?.cover_image_url;
  };

  return (
    <div className="mb-8">
      {/* Cover Image Section */}
      <div className="relative w-full h-64 bg-gradient-to-r from-blue-500 to-purple-600 rounded-t-lg overflow-hidden mb-6">
        {getCoverImageUrl() ? (
          <img 
            src={getCoverImageUrl()} 
            alt="Cover" 
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-r from-blue-500 to-purple-600" />
        )}
        
        {/* Profile Section Overlay */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/50 to-transparent p-8">
          <div className="flex items-end space-x-6">
            <Avatar className="w-28 h-28 ring-4 ring-white">
              <AvatarImage src={getAvatarUrl()} alt={getUserFullName()} />
              <AvatarFallback className="bg-blue-500 text-white text-xl font-bold">
                {getUserInitials()}
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col text-white mb-3">
              <h1 className="text-4xl font-bold">
                {getUserFullName()}
              </h1>
              <p className="text-white/80 font-medium text-xl">
                {getUsername()}
              </p>
              <div className="flex items-center space-x-4 text-sm text-white/70 mt-2">
                <span className="bg-white/20 px-3 py-1 rounded-full">
                  Member since {new Date(user?.created_at || Date.now()).getFullYear()}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex items-center justify-start space-x-2">
        <Button variant="outline" onClick={() => onNavigate(`/profile/${user?.id}`)}>
          <User className="w-4 h-4 mr-2" />
          View Profile
        </Button>
        <Button variant="outline" onClick={onViewSubscriptions}>
          <Users className="w-4 h-4 mr-2" />
          View Subscriptions
        </Button>
        <Button onClick={onSignOut} variant="outline">
          <LogOut className="w-4 h-4 mr-2" />
          Sign Out
        </Button>
      </div>
    </div>
  );
};

export default DashboardHeader;
