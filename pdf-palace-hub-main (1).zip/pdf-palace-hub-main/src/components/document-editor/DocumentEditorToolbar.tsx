
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import {
  Save,
  Upload,
  Type,
  Image,
  Square,
  Table,
  BarChart3,
  MousePointer2,
  Undo,
  Redo,
  ZoomIn,
  ZoomOut,
  Download,
  Share2
} from 'lucide-react';

interface DocumentEditorToolbarProps {
  selectedTool: string;
  onToolSelect: (tool: string) => void;
  onSave: () => void;
  onPublish: () => void;
  onAddElement: (type: string) => void;
  isSaving: boolean;
  documentTitle: string;
  onTitleChange: (title: string) => void;
}

export const DocumentEditorToolbar: React.FC<DocumentEditorToolbarProps> = ({
  selectedTool,
  onToolSelect,
  onSave,
  onPublish,
  onAddElement,
  isSaving,
  documentTitle,
  onTitleChange
}) => {
  const tools = [
    { id: 'select', icon: MousePointer2, label: 'Select' },
    { id: 'text', icon: Type, label: 'Text' },
    { id: 'image', icon: Image, label: 'Image' },
    { id: 'shape', icon: Square, label: 'Shape' },
    { id: 'table', icon: Table, label: 'Table' },
    { id: 'chart', icon: BarChart3, label: 'Chart' }
  ];

  return (
    <div className="bg-white border-b border-gray-200 px-4 py-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          {/* Document Title */}
          <Input
            value={documentTitle}
            onChange={(e) => onTitleChange(e.target.value)}
            className="text-lg font-semibold border-none bg-transparent focus:bg-white focus:border-gray-300 max-w-xs"
            placeholder="Document Title"
          />
          
          <Separator orientation="vertical" className="h-6" />
          
          {/* File Operations */}
          <div className="flex items-center space-x-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={onSave}
              disabled={isSaving}
              className="flex items-center space-x-1"
            >
              <Save className="h-4 w-4" />
              <span>{isSaving ? 'Saving...' : 'Save'}</span>
            </Button>
            
            <Button
              variant="default"
              size="sm"
              onClick={onPublish}
              disabled={isSaving}
              className="flex items-center space-x-1"
            >
              <Upload className="h-4 w-4" />
              <span>Publish</span>
            </Button>
          </div>
          
          <Separator orientation="vertical" className="h-6" />
          
          {/* Edit Tools */}
          <div className="flex items-center space-x-1">
            <Button variant="ghost" size="sm" className="p-2">
              <Undo className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" className="p-2">
              <Redo className="h-4 w-4" />
            </Button>
          </div>
          
          <Separator orientation="vertical" className="h-6" />
          
          {/* Drawing Tools */}
          <div className="flex items-center space-x-1">
            {tools.map((tool) => (
              <Button
                key={tool.id}
                variant={selectedTool === tool.id ? "default" : "ghost"}
                size="sm"
                onClick={() => {
                  onToolSelect(tool.id);
                  if (tool.id !== 'select') {
                    onAddElement(tool.id);
                  }
                }}
                className="p-2"
                title={tool.label}
              >
                <tool.icon className="h-4 w-4" />
              </Button>
            ))}
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          {/* Zoom Controls */}
          <Button variant="ghost" size="sm" className="p-2">
            <ZoomOut className="h-4 w-4" />
          </Button>
          <span className="text-sm text-gray-600 min-w-[50px] text-center">100%</span>
          <Button variant="ghost" size="sm" className="p-2">
            <ZoomIn className="h-4 w-4" />
          </Button>
          
          <Separator orientation="vertical" className="h-6" />
          
          {/* Export & Share */}
          <Button variant="ghost" size="sm" className="flex items-center space-x-1">
            <Download className="h-4 w-4" />
            <span>Export</span>
          </Button>
          
          <Button variant="ghost" size="sm" className="flex items-center space-x-1">
            <Share2 className="h-4 w-4" />
            <span>Share</span>
          </Button>
        </div>
      </div>
    </div>
  );
};
