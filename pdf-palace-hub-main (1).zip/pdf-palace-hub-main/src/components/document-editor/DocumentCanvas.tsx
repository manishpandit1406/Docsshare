
import React, { useRef, useCallback, useState } from 'react';
import { DocumentElement, PageContent } from '@/services/documentEditorService';

interface DocumentCanvasProps {
  page: PageContent;
  selectedElement: string | null;
  selectedTool: string;
  onElementSelect: (elementId: string | null) => void;
  onElementUpdate: (elementId: string, updates: Partial<DocumentElement>) => void;
  onElementDelete: (elementId: string) => void;
}

export const DocumentCanvas: React.FC<DocumentCanvasProps> = ({
  page,
  selectedElement,
  selectedTool,
  onElementSelect,
  onElementUpdate,
  onElementDelete
}) => {
  const canvasRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [isResizing, setIsResizing] = useState(false);

  const handleElementClick = useCallback((e: React.MouseEvent, elementId: string) => {
    e.stopPropagation();
    onElementSelect(elementId);
  }, [onElementSelect]);

  const handleCanvasClick = useCallback((e: React.MouseEvent) => {
    if (e.target === canvasRef.current) {
      onElementSelect(null);
    }
  }, [onElementSelect]);

  const handleMouseDown = useCallback((e: React.MouseEvent, elementId: string) => {
    if (selectedTool !== 'select') return;
    
    setIsDragging(true);
    setDragStart({ x: e.clientX, y: e.clientY });
    onElementSelect(elementId);
  }, [selectedTool, onElementSelect]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDragging || !selectedElement) return;

    const deltaX = e.clientX - dragStart.x;
    const deltaY = e.clientY - dragStart.y;

    const element = page.elements.find(el => el.id === selectedElement);
    if (element) {
      onElementUpdate(selectedElement, {
        position: {
          ...element.position,
          x: element.position.x + deltaX,
          y: element.position.y + deltaY
        }
      });
    }

    setDragStart({ x: e.clientX, y: e.clientY });
  }, [isDragging, selectedElement, dragStart, page.elements, onElementUpdate]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
    setIsResizing(false);
  }, []);

  const handleDoubleClick = useCallback((elementId: string) => {
    const element = page.elements.find(el => el.id === elementId);
    if (element && element.type === 'text') {
      const newText = prompt('Enter text:', element.content.text);
      if (newText !== null) {
        onElementUpdate(elementId, {
          content: { ...element.content, text: newText }
        });
      }
    }
  }, [page.elements, onElementUpdate]);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.key === 'Delete' && selectedElement) {
      onElementDelete(selectedElement);
    }
  }, [selectedElement, onElementDelete]);

  React.useEffect(() => {
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  const renderElement = (element: DocumentElement) => {
    const isSelected = selectedElement === element.id;
    
    return (
      <div
        key={element.id}
        className={`absolute cursor-pointer select-none ${
          isSelected ? 'ring-2 ring-blue-500' : ''
        }`}
        style={{
          left: element.position.x,
          top: element.position.y,
          width: element.position.width,
          height: element.position.height,
          zIndex: element.zIndex
        }}
        onClick={(e) => handleElementClick(e, element.id)}
        onMouseDown={(e) => handleMouseDown(e, element.id)}
        onDoubleClick={() => handleDoubleClick(element.id)}
      >
        {renderElementContent(element)}
        
        {isSelected && (
          <>
            {/* Selection handles */}
            <div className="absolute -top-1 -left-1 w-2 h-2 bg-blue-500 border border-white cursor-nw-resize" />
            <div className="absolute -top-1 right-1/2 w-2 h-2 bg-blue-500 border border-white cursor-n-resize" />
            <div className="absolute -top-1 -right-1 w-2 h-2 bg-blue-500 border border-white cursor-ne-resize" />
            <div className="absolute top-1/2 -right-1 w-2 h-2 bg-blue-500 border border-white cursor-e-resize" />
            <div className="absolute -bottom-1 -right-1 w-2 h-2 bg-blue-500 border border-white cursor-se-resize" />
            <div className="absolute -bottom-1 left-1/2 w-2 h-2 bg-blue-500 border border-white cursor-s-resize" />
            <div className="absolute -bottom-1 -left-1 w-2 h-2 bg-blue-500 border border-white cursor-sw-resize" />
            <div className="absolute top-1/2 -left-1 w-2 h-2 bg-blue-500 border border-white cursor-w-resize" />
          </>
        )}
      </div>
    );
  };

  const renderElementContent = (element: DocumentElement) => {
    switch (element.type) {
      case 'text':
        return (
          <div
            className="w-full h-full flex items-center"
            style={{
              fontSize: element.style.fontSize,
              fontFamily: element.style.fontFamily,
              color: element.style.color,
              textAlign: element.style.textAlign,
              fontWeight: element.style.fontWeight
            }}
          >
            {element.content.text}
          </div>
        );
      
      case 'image':
        return (
          <div className="w-full h-full bg-gray-200 border-2 border-dashed border-gray-400 flex items-center justify-center">
            {element.content.src ? (
              <img src={element.content.src} alt={element.content.alt} className="max-w-full max-h-full object-contain" />
            ) : (
              <span className="text-gray-500">Click to add image</span>
            )}
          </div>
        );
      
      case 'shape':
        return (
          <div
            className="w-full h-full"
            style={{
              backgroundColor: element.style.fill,
              border: `${element.style.strokeWidth}px solid ${element.style.stroke}`,
              borderRadius: element.content.shape === 'circle' ? '50%' : '0'
            }}
          />
        );
      
      case 'table':
        return (
          <div className="w-full h-full border border-gray-300">
            <table className="w-full h-full border-collapse">
              <tbody>
                {Array.from({ length: element.content.rows }).map((_, rowIndex) => (
                  <tr key={rowIndex}>
                    {Array.from({ length: element.content.cols }).map((_, colIndex) => (
                      <td key={colIndex} className="border border-gray-300 p-1 text-xs">
                        Cell {rowIndex + 1},{colIndex + 1}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      
      case 'chart':
        return (
          <div className="w-full h-full bg-gray-100 border border-gray-300 flex items-center justify-center">
            <span className="text-gray-600 text-sm">Chart Placeholder</span>
          </div>
        );
      
      default:
        return <div className="w-full h-full bg-gray-200" />;
    }
  };

  return (
    <div className="flex-1 bg-gray-100 overflow-auto p-8">
      <div
        ref={canvasRef}
        className="relative mx-auto bg-white shadow-lg"
        style={{
          width: page.size.width,
          height: page.size.height,
          backgroundColor: page.background.color
        }}
        onClick={handleCanvasClick}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
      >
        {page.elements.map(renderElement)}
      </div>
    </div>
  );
};
