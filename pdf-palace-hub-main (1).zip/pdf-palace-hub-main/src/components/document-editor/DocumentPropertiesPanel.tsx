
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { DocumentElement } from '@/services/documentEditorService';
import { Trash2, Bold, Italic, Underline, AlignLeft, AlignCenter, AlignRight } from 'lucide-react';

interface DocumentPropertiesPanelProps {
  selectedElement: DocumentElement | null;
  onElementUpdate: (elementId: string, updates: Partial<DocumentElement>) => void;
}

export const DocumentPropertiesPanel: React.FC<DocumentPropertiesPanelProps> = ({
  selectedElement,
  onElementUpdate
}) => {
  if (!selectedElement) {
    return (
      <div className="w-80 bg-white border-l border-gray-200 p-4">
        <div className="text-center text-gray-500">
          <p>Select an element to edit its properties</p>
        </div>
      </div>
    );
  }

  const updateElement = (updates: Partial<DocumentElement>) => {
    onElementUpdate(selectedElement.id, updates);
  };

  const updateStyle = (styleUpdates: any) => {
    updateElement({
      style: { ...selectedElement.style, ...styleUpdates }
    });
  };

  const updateContent = (contentUpdates: any) => {
    updateElement({
      content: { ...selectedElement.content, ...contentUpdates }
    });
  };

  const updatePosition = (positionUpdates: any) => {
    updateElement({
      position: { ...selectedElement.position, ...positionUpdates }
    });
  };

  return (
    <div className="w-80 bg-white border-l border-gray-200 overflow-y-auto">
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-gray-900">Properties</h3>
          <Button
            variant="ghost"
            size="sm"
            className="text-red-600 hover:text-red-700"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>

        {/* Position and Size */}
        <div className="space-y-4">
          <div>
            <Label className="text-sm font-medium">Position & Size</Label>
            <div className="grid grid-cols-2 gap-2 mt-2">
              <div>
                <Label className="text-xs text-gray-500">X</Label>
                <Input
                  type="number"
                  value={selectedElement.position.x}
                  onChange={(e) => updatePosition({ x: Number(e.target.value) })}
                  className="h-8"
                />
              </div>
              <div>
                <Label className="text-xs text-gray-500">Y</Label>
                <Input
                  type="number"
                  value={selectedElement.position.y}
                  onChange={(e) => updatePosition({ y: Number(e.target.value) })}
                  className="h-8"
                />
              </div>
              <div>
                <Label className="text-xs text-gray-500">Width</Label>
                <Input
                  type="number"
                  value={selectedElement.position.width}
                  onChange={(e) => updatePosition({ width: Number(e.target.value) })}
                  className="h-8"
                />
              </div>
              <div>
                <Label className="text-xs text-gray-500">Height</Label>
                <Input
                  type="number"
                  value={selectedElement.position.height}
                  onChange={(e) => updatePosition({ height: Number(e.target.value) })}
                  className="h-8"
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Type-specific properties */}
          {selectedElement.type === 'text' && (
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-medium">Text Content</Label>
                <Input
                  value={selectedElement.content.text}
                  onChange={(e) => updateContent({ text: e.target.value })}
                  className="mt-1"
                />
              </div>

              <div>
                <Label className="text-sm font-medium">Font Family</Label>
                <Select
                  value={selectedElement.style.fontFamily}
                  onValueChange={(value) => updateStyle({ fontFamily: value })}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Arial">Arial</SelectItem>
                    <SelectItem value="Times New Roman">Times New Roman</SelectItem>
                    <SelectItem value="Helvetica">Helvetica</SelectItem>
                    <SelectItem value="Georgia">Georgia</SelectItem>
                    <SelectItem value="Verdana">Verdana</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm font-medium">Font Size</Label>
                <div className="mt-2">
                  <Slider
                    value={[selectedElement.style.fontSize]}
                    onValueChange={([value]) => updateStyle({ fontSize: value })}
                    max={72}
                    min={8}
                    step={1}
                    className="w-full"
                  />
                  <div className="text-xs text-gray-500 mt-1">
                    {selectedElement.style.fontSize}px
                  </div>
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium">Text Color</Label>
                <div className="flex items-center space-x-2 mt-1">
                  <input
                    type="color"
                    value={selectedElement.style.color}
                    onChange={(e) => updateStyle({ color: e.target.value })}
                    className="w-10 h-8 rounded border"
                  />
                  <Input
                    value={selectedElement.style.color}
                    onChange={(e) => updateStyle({ color: e.target.value })}
                    className="flex-1 h-8"
                  />
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium">Text Alignment</Label>
                <div className="flex space-x-1 mt-1">
                  <Button
                    variant={selectedElement.style.textAlign === 'left' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => updateStyle({ textAlign: 'left' })}
                  >
                    <AlignLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={selectedElement.style.textAlign === 'center' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => updateStyle({ textAlign: 'center' })}
                  >
                    <AlignCenter className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={selectedElement.style.textAlign === 'right' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => updateStyle({ textAlign: 'right' })}
                  >
                    <AlignRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium">Text Style</Label>
                <div className="flex space-x-1 mt-1">
                  <Button
                    variant={selectedElement.style.fontWeight === 'bold' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => updateStyle({ 
                      fontWeight: selectedElement.style.fontWeight === 'bold' ? 'normal' : 'bold' 
                    })}
                  >
                    <Bold className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={selectedElement.style.fontStyle === 'italic' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => updateStyle({ 
                      fontStyle: selectedElement.style.fontStyle === 'italic' ? 'normal' : 'italic' 
                    })}
                  >
                    <Italic className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={selectedElement.style.textDecoration === 'underline' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => updateStyle({ 
                      textDecoration: selectedElement.style.textDecoration === 'underline' ? 'none' : 'underline' 
                    })}
                  >
                    <Underline className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          )}

          {selectedElement.type === 'shape' && (
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-medium">Shape Type</Label>
                <Select
                  value={selectedElement.content.shape}
                  onValueChange={(value) => updateContent({ shape: value })}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rectangle">Rectangle</SelectItem>
                    <SelectItem value="circle">Circle</SelectItem>
                    <SelectItem value="triangle">Triangle</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm font-medium">Fill Color</Label>
                <div className="flex items-center space-x-2 mt-1">
                  <input
                    type="color"
                    value={selectedElement.style.fill}
                    onChange={(e) => updateStyle({ fill: e.target.value })}
                    className="w-10 h-8 rounded border"
                  />
                  <Input
                    value={selectedElement.style.fill}
                    onChange={(e) => updateStyle({ fill: e.target.value })}
                    className="flex-1 h-8"
                  />
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium">Border Color</Label>
                <div className="flex items-center space-x-2 mt-1">
                  <input
                    type="color"
                    value={selectedElement.style.stroke}
                    onChange={(e) => updateStyle({ stroke: e.target.value })}
                    className="w-10 h-8 rounded border"
                  />
                  <Input
                    value={selectedElement.style.stroke}
                    onChange={(e) => updateStyle({ stroke: e.target.value })}
                    className="flex-1 h-8"
                  />
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium">Border Width</Label>
                <div className="mt-2">
                  <Slider
                    value={[selectedElement.style.strokeWidth]}
                    onValueChange={([value]) => updateStyle({ strokeWidth: value })}
                    max={10}
                    min={0}
                    step={1}
                    className="w-full"
                  />
                  <div className="text-xs text-gray-500 mt-1">
                    {selectedElement.style.strokeWidth}px
                  </div>
                </div>
              </div>
            </div>
          )}

          {selectedElement.type === 'table' && (
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-medium">Table Size</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <div>
                    <Label className="text-xs text-gray-500">Rows</Label>
                    <Input
                      type="number"
                      value={selectedElement.content.rows}
                      onChange={(e) => updateContent({ rows: Number(e.target.value) })}
                      className="h-8"
                      min="1"
                    />
                  </div>
                  <div>
                    <Label className="text-xs text-gray-500">Columns</Label>
                    <Input
                      type="number"
                      value={selectedElement.content.cols}
                      onChange={(e) => updateContent({ cols: Number(e.target.value) })}
                      className="h-8"
                      min="1"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          <Separator />

          {/* Layer controls */}
          <div>
            <Label className="text-sm font-medium">Layer</Label>
            <div className="flex items-center space-x-2 mt-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => updateElement({ zIndex: selectedElement.zIndex + 1 })}
              >
                Bring Forward
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => updateElement({ zIndex: Math.max(0, selectedElement.zIndex - 1) })}
              >
                Send Back
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
