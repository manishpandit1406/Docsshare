
import React from 'react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Plus, FileText } from 'lucide-react';
import { PageContent } from '@/services/documentEditorService';

interface DocumentSidebarProps {
  pages: PageContent[];
  currentPage: number;
  onPageSelect: (pageIndex: number) => void;
  onAddPage: () => void;
}

export const DocumentSidebar: React.FC<DocumentSidebarProps> = ({
  pages,
  currentPage,
  onPageSelect,
  onAddPage
}) => {
  return (
    <div className="w-64 bg-white border-r border-gray-200 flex flex-col">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-gray-900">Pages</h3>
          <Button
            variant="outline"
            size="sm"
            onClick={onAddPage}
            className="flex items-center space-x-1"
          >
            <Plus className="h-3 w-3" />
            <span>Add</span>
          </Button>
        </div>
      </div>
      
      <ScrollArea className="flex-1">
        <div className="p-2 space-y-2">
          {pages.map((page, index) => (
            <div
              key={page.id}
              className={`relative cursor-pointer rounded-lg border-2 transition-colors ${
                currentPage === index
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => onPageSelect(index)}
            >
              <div className="aspect-[3/4] p-2">
                <div
                  className="w-full h-full bg-white shadow-sm rounded border"
                  style={{ backgroundColor: page.background.color }}
                >
                  {/* Mini preview of page elements */}
                  <div className="relative w-full h-full overflow-hidden">
                    {page.elements.slice(0, 5).map((element) => (
                      <div
                        key={element.id}
                        className="absolute bg-gray-300 opacity-60"
                        style={{
                          left: `${(element.position.x / page.size.width) * 100}%`,
                          top: `${(element.position.y / page.size.height) * 100}%`,
                          width: `${(element.position.width / page.size.width) * 100}%`,
                          height: `${(element.position.height / page.size.height) * 100}%`
                        }}
                      />
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="absolute bottom-1 left-1 bg-white px-1 py-0.5 rounded text-xs font-medium flex items-center space-x-1">
                <FileText className="h-3 w-3" />
                <span>{index + 1}</span>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};
