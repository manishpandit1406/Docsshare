
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { toast } from '@/hooks/use-toast';
import { Palette, Monitor, Sun, Moon, Save, Type, Eye, Globe } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';

const AppearanceSection = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [settings, setSettings] = useState({
    theme: 'system',
    language: 'en',
    font_size: 'medium',
    compact_mode: false,
    high_contrast: false,
    reduce_animations: false,
    custom_accent_color: '#3b82f6',
    sidebar_position: 'left',
    card_style: 'default',
    density: 'comfortable'
  });

  const languages = [
    { value: 'en', label: 'English', flag: '🇺🇸' },
    { value: 'es', label: 'Español', flag: '🇪🇸' },
    { value: 'fr', label: 'Français', flag: '🇫🇷' },
    { value: 'de', label: 'Deutsch', flag: '🇩🇪' },
    { value: 'it', label: 'Italiano', flag: '🇮🇹' },
    { value: 'pt', label: 'Português', flag: '🇵🇹' },
    { value: 'ru', label: 'Русский', flag: '🇷🇺' },
    { value: 'zh', label: '中文', flag: '🇨🇳' },
    { value: 'ja', label: '日本語', flag: '🇯🇵' },
    { value: 'ko', label: '한국어', flag: '🇰🇷' },
    { value: 'ar', label: 'العربية', flag: '🇸🇦' },
    { value: 'hi', label: 'हिन्दी', flag: '🇮🇳' },
    { value: 'th', label: 'ไทย', flag: '🇹🇭' },
    { value: 'vi', label: 'Tiếng Việt', flag: '🇻🇳' },
    { value: 'tr', label: 'Türkçe', flag: '🇹🇷' },
    { value: 'pl', label: 'Polski', flag: '🇵🇱' },
    { value: 'nl', label: 'Nederlands', flag: '🇳🇱' },
    { value: 'sv', label: 'Svenska', flag: '🇸🇪' },
    { value: 'da', label: 'Dansk', flag: '🇩🇰' },
    { value: 'no', label: 'Norsk', flag: '🇳🇴' },
    { value: 'fi', label: 'Suomi', flag: '🇫🇮' },
    { value: 'cs', label: 'Čeština', flag: '🇨🇿' },
    { value: 'hu', label: 'Magyar', flag: '🇭🇺' },
    { value: 'ro', label: 'Română', flag: '🇷🇴' },
    { value: 'bg', label: 'Български', flag: '🇧🇬' },
    { value: 'hr', label: 'Hrvatski', flag: '🇭🇷' },
    { value: 'sk', label: 'Slovenčina', flag: '🇸🇰' },
    { value: 'sl', label: 'Slovenščina', flag: '🇸🇮' },
    { value: 'et', label: 'Eesti', flag: '🇪🇪' },
    { value: 'lv', label: 'Latviešu', flag: '🇱🇻' },
    { value: 'lt', label: 'Lietuvių', flag: '🇱🇹' },
    { value: 'el', label: 'Ελληνικά', flag: '🇬🇷' },
    { value: 'he', label: 'עברית', flag: '🇮🇱' },
    { value: 'fa', label: 'فارسی', flag: '🇮🇷' },
    { value: 'ur', label: 'اردو', flag: '🇵🇰' },
    { value: 'bn', label: 'বাংলা', flag: '🇧🇩' },
    { value: 'ta', label: 'தமிழ்', flag: '🇱🇰' },
    { value: 'te', label: 'తెలుగు', flag: '🇮🇳' },
    { value: 'ml', label: 'മലയാളം', flag: '🇮🇳' },
    { value: 'kn', label: 'ಕನ್ನಡ', flag: '🇮🇳' },
    { value: 'gu', label: 'ગુજરાતી', flag: '🇮🇳' },
    { value: 'mr', label: 'मराठी', flag: '🇮🇳' },
    { value: 'pa', label: 'ਪੰਜਾਬੀ', flag: '🇮🇳' },
    { value: 'or', label: 'ଓଡ଼ିଆ', flag: '🇮🇳' },
    { value: 'as', label: 'অসমীয়া', flag: '🇮🇳' },
    { value: 'my', label: 'မြန်မာ', flag: '🇲🇲' },
    { value: 'km', label: 'ខ្មែរ', flag: '🇰🇭' },
    { value: 'lo', label: 'ລາວ', flag: '🇱🇦' },
    { value: 'si', label: 'සිංහල', flag: '🇱🇰' },
    { value: 'ne', label: 'नेपाली', flag: '🇳🇵' },
    { value: 'dz', label: 'རྫོང་ཁ', flag: '🇧🇹' },
    { value: 'mn', label: 'Монгол', flag: '🇲🇳' }
  ];

  const fontSizes = [
    { value: 'small', label: 'Small (12px)', size: 'text-xs' },
    { value: 'medium', label: 'Medium (14px)', size: 'text-sm' },
    { value: 'large', label: 'Large (16px)', size: 'text-base' },
    { value: 'extra-large', label: 'Extra Large (18px)', size: 'text-lg' },
    { value: 'huge', label: 'Huge (20px)', size: 'text-xl' }
  ];

  useEffect(() => {
    if (user) {
      fetchAppearanceSettings();
    }
  }, [user]);

  const fetchAppearanceSettings = async () => {
    try {
      console.log('Fetching appearance settings for user:', user?.id);
      
      const { data, error } = await supabase
        .from('user_appearance_settings')
        .select('*')
        .eq('user_id', user?.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching appearance settings:', error);
        throw error;
      }

      console.log('Fetched appearance settings:', data);

      if (data) {
        setSettings({
          theme: data.theme || 'system',
          language: data.language || 'en',
          font_size: data.font_size || 'medium',
          compact_mode: data.compact_mode || false,
          high_contrast: data.high_contrast || false,
          reduce_animations: data.reduce_animations || false,
          custom_accent_color: data.custom_accent_color || '#3b82f6',
          sidebar_position: data.sidebar_position || 'left',
          card_style: data.card_style || 'default',
          density: data.density || 'comfortable'
        });
      }
    } catch (error) {
      console.error('Error fetching appearance settings:', error);
      toast({
        title: "Error",
        description: "Failed to load appearance settings",
        variant: "destructive"
      });
    }
  };

  const handleSaveAppearance = async () => {
    if (!user) {
      toast({
        title: "Error",
        description: "User not authenticated",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      console.log('Saving appearance settings:', settings);

      const { error } = await supabase
        .from('user_appearance_settings')
        .upsert({
          user_id: user.id,
          ...settings,
          updated_at: new Date().toISOString()
        });

      if (error) {
        console.error('Error saving appearance settings:', error);
        throw error;
      }

      console.log('Appearance settings saved successfully');

      // Apply theme and font size immediately
      applyTheme(settings.theme);
      applyFontSize(settings.font_size);

      toast({
        title: "Success",
        description: "Appearance settings updated successfully"
      });
    } catch (error) {
      console.error('Error updating appearance settings:', error);
      toast({
        title: "Error",
        description: "Failed to update appearance settings",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const applyTheme = (theme: string) => {
    const root = window.document.documentElement;
    root.classList.remove('light', 'dark');
    
    if (theme === 'dark') {
      root.classList.add('dark');
    } else if (theme === 'light') {
      root.classList.add('light');
    } else {
      // System theme
      const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      root.classList.add(systemTheme);
    }
  };

  const applyFontSize = (fontSize: string) => {
    const root = window.document.documentElement;
    
    // Remove existing font size classes
    root.classList.remove('font-size-small', 'font-size-medium', 'font-size-large', 'font-size-extra-large', 'font-size-huge');
    
    // Add new font size class
    root.classList.add(`font-size-${fontSize}`);
  };

  const updateSettings = (key: string, value: any) => {
    console.log('Updating setting:', key, 'to:', value);
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="space-y-6">
      {/* Theme Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Palette className="w-5 h-5" />
            Color Theme
          </CardTitle>
        </CardHeader>
        <CardContent>
          <RadioGroup value={settings.theme} onValueChange={(value) => updateSettings('theme', value)} className="space-y-3">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="light" id="light" />
              <Label htmlFor="light" className="flex items-center gap-2 cursor-pointer">
                <Sun className="w-4 h-4" />
                Light
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="dark" id="dark" />
              <Label htmlFor="dark" className="flex items-center gap-2 cursor-pointer">
                <Moon className="w-4 h-4" />
                Dark
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="system" id="system" />
              <Label htmlFor="system" className="flex items-center gap-2 cursor-pointer">
                <Monitor className="w-4 h-4" />
                System
              </Label>
            </div>
          </RadioGroup>
        </CardContent>
      </Card>

      {/* Language & Localization */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="w-5 h-5" />
            Language & Region
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Display Language</Label>
            <Select value={settings.language} onValueChange={(value) => updateSettings('language', value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-60">
                {languages.map((lang) => (
                  <SelectItem key={lang.value} value={lang.value}>
                    <div className="flex items-center gap-2">
                      <span>{lang.flag}</span>
                      <span>{lang.label}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Choose your preferred language for the interface
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Typography & Display */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Type className="w-5 h-5" />
            Typography & Display
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>Font Size</Label>
            <Select value={settings.font_size} onValueChange={(value) => updateSettings('font_size', value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {fontSizes.map((size) => (
                  <SelectItem key={size.value} value={size.value}>
                    <div className={`${size.size}`}>
                      {size.label}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Adjust the base font size for better readability
            </p>
          </div>

          <div className="space-y-2">
            <Label>Interface Density</Label>
            <Select value={settings.density} onValueChange={(value) => updateSettings('density', value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="compact">Compact - More content, less spacing</SelectItem>
                <SelectItem value="comfortable">Comfortable - Balanced spacing</SelectItem>
                <SelectItem value="spacious">Spacious - More spacing, easier reading</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Compact Mode</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Reduce spacing for more content density
              </p>
            </div>
            <Switch
              checked={settings.compact_mode}
              onCheckedChange={(checked) => updateSettings('compact_mode', checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Accessibility */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5" />
            Accessibility
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>High Contrast</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Increase contrast for better visibility
              </p>
            </div>
            <Switch
              checked={settings.high_contrast}
              onCheckedChange={(checked) => updateSettings('high_contrast', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Reduce Animations</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Minimize motion for better focus
              </p>
            </div>
            <Switch
              checked={settings.reduce_animations}
              onCheckedChange={(checked) => updateSettings('reduce_animations', checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Layout Customization */}
      <Card>
        <CardHeader>
          <CardTitle>Layout & Interface</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>Sidebar Position</Label>
            <Select value={settings.sidebar_position} onValueChange={(value) => updateSettings('sidebar_position', value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="left">Left</SelectItem>
                <SelectItem value="right">Right</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Card Style</Label>
            <Select value={settings.card_style} onValueChange={(value) => updateSettings('card_style', value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="default">Default</SelectItem>
                <SelectItem value="elevated">Elevated</SelectItem>
                <SelectItem value="outlined">Outlined</SelectItem>
                <SelectItem value="minimal">Minimal</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Accent Color</Label>
            <div className="flex items-center gap-3">
              <input
                type="color"
                value={settings.custom_accent_color}
                onChange={(e) => updateSettings('custom_accent_color', e.target.value)}
                className="w-12 h-8 rounded border border-gray-300 cursor-pointer"
              />
              <span className="text-sm text-gray-600 dark:text-gray-400">
                {settings.custom_accent_color}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSaveAppearance} disabled={loading} className="px-8">
          <Save className="w-4 h-4 mr-2" />
          {loading ? 'Saving...' : 'Save Appearance Settings'}
        </Button>
      </div>
    </div>
  );
};

export default AppearanceSection;
