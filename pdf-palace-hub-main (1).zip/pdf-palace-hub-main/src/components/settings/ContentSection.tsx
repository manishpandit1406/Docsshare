
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Save, Upload, FileText, Eye, Zap, Scan } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

interface ContentSettings {
  auto_tag_pdfs: boolean;
  max_upload_size_mb: number;
  allowed_file_types: string[];
  watermark_enabled: boolean;
  watermark_text: string;
  compression_enabled: boolean;
  ocr_enabled: boolean;
  auto_backup: boolean;
  version_control: boolean;
  thumbnail_quality: 'low' | 'medium' | 'high';
  auto_categorization: boolean;
  duplicate_detection: boolean;
  batch_processing: boolean;
}

const ContentSection = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [settings, setSettings] = useState<ContentSettings>({
    auto_tag_pdfs: true,
    max_upload_size_mb: 50,
    allowed_file_types: ['pdf', 'doc', 'docx'],
    watermark_enabled: false,
    watermark_text: '',
    compression_enabled: true,
    ocr_enabled: false,
    auto_backup: true,
    version_control: false,
    thumbnail_quality: 'medium',
    auto_categorization: true,
    duplicate_detection: true,
    batch_processing: false
  });

  useEffect(() => {
    if (user) {
      fetchSettings();
    }
  }, [user]);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('user_content_settings')
        .select('*')
        .eq('user_id', user?.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setSettings({
          auto_tag_pdfs: data.auto_tag_pdfs ?? true,
          max_upload_size_mb: data.max_upload_size_mb ?? 50,
          allowed_file_types: data.allowed_file_types || ['pdf', 'doc', 'docx'],
          watermark_enabled: data.watermark_enabled ?? false,
          watermark_text: data.watermark_text || '',
          compression_enabled: data.compression_enabled ?? true,
          ocr_enabled: data.ocr_enabled ?? false,
          auto_backup: data.auto_backup ?? true,
          version_control: data.version_control ?? false,
          thumbnail_quality: (data.thumbnail_quality as 'low' | 'medium' | 'high') || 'medium',
          auto_categorization: data.auto_categorization ?? true,
          duplicate_detection: data.duplicate_detection ?? true,
          batch_processing: data.batch_processing ?? false
        });
      }
    } catch (error) {
      console.error('Error fetching content settings:', error);
      toast({
        title: "Error",
        description: "Failed to load content settings",
        variant: "destructive"
      });
    }
  };

  const handleSave = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('user_content_settings')
        .upsert({
          user_id: user.id,
          ...settings,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Content settings updated successfully"
      });
    } catch (error) {
      console.error('Error updating content settings:', error);
      toast({
        title: "Error",
        description: "Failed to update content settings",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const updateSettings = (key: keyof ContentSettings, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const fileTypeOptions = [
    { value: 'pdf', label: 'PDF' },
    { value: 'doc', label: 'DOC' },
    { value: 'docx', label: 'DOCX' },
    { value: 'txt', label: 'TXT' },
    { value: 'rtf', label: 'RTF' },
    { value: 'odt', label: 'ODT' },
    { value: 'pages', label: 'Pages' }
  ];

  return (
    <div className="space-y-6">
      {/* Upload Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5" />
            Upload Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>Maximum Upload Size (MB)</Label>
            <Input
              type="number"
              min="1"
              max="500"
              value={settings.max_upload_size_mb}
              onChange={(e) => updateSettings('max_upload_size_mb', parseInt(e.target.value))}
            />
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Set the maximum file size for uploads (1-500 MB)
            </p>
          </div>

          <div className="space-y-2">
            <Label>Allowed File Types</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {fileTypeOptions.map((type) => (
                <div key={type.value} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id={type.value}
                    checked={settings.allowed_file_types.includes(type.value)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        updateSettings('allowed_file_types', [...settings.allowed_file_types, type.value]);
                      } else {
                        updateSettings('allowed_file_types', settings.allowed_file_types.filter(t => t !== type.value));
                      }
                    }}
                    className="rounded border-gray-300"
                  />
                  <Label htmlFor={type.value} className="text-sm cursor-pointer">
                    {type.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Batch Processing</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Allow multiple file uploads at once
              </p>
            </div>
            <Switch
              checked={settings.batch_processing}
              onCheckedChange={(checked) => updateSettings('batch_processing', checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Processing Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5" />
            Processing Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Auto-tag PDFs</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Automatically extract and assign tags from content
              </p>
            </div>
            <Switch
              checked={settings.auto_tag_pdfs}
              onCheckedChange={(checked) => updateSettings('auto_tag_pdfs', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Auto Categorization</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Automatically categorize uploads based on content
              </p>
            </div>
            <Switch
              checked={settings.auto_categorization}
              onCheckedChange={(checked) => updateSettings('auto_categorization', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Enable Compression</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Compress files to reduce storage usage
              </p>
            </div>
            <Switch
              checked={settings.compression_enabled}
              onCheckedChange={(checked) => updateSettings('compression_enabled', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="flex items-center gap-2">
                <Scan className="w-4 h-4" />
                OCR (Text Recognition)
              </Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Extract text from scanned documents
              </p>
            </div>
            <Switch
              checked={settings.ocr_enabled}
              onCheckedChange={(checked) => updateSettings('ocr_enabled', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Duplicate Detection</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Detect and prevent duplicate uploads
              </p>
            </div>
            <Switch
              checked={settings.duplicate_detection}
              onCheckedChange={(checked) => updateSettings('duplicate_detection', checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Watermark Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5" />
            Watermark Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Enable Watermark</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Add watermark to uploaded documents
              </p>
            </div>
            <Switch
              checked={settings.watermark_enabled}
              onCheckedChange={(checked) => updateSettings('watermark_enabled', checked)}
            />
          </div>

          {settings.watermark_enabled && (
            <div className="space-y-2">
              <Label>Watermark Text</Label>
              <Textarea
                placeholder="Enter watermark text..."
                value={settings.watermark_text}
                onChange={(e) => updateSettings('watermark_text', e.target.value)}
                rows={2}
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Thumbnail & Preview Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Thumbnail & Preview Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>Thumbnail Quality</Label>
            <Select
              value={settings.thumbnail_quality}
              onValueChange={(value: 'low' | 'medium' | 'high') => updateSettings('thumbnail_quality', value)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low (Fast processing)</SelectItem>
                <SelectItem value="medium">Medium (Balanced)</SelectItem>
                <SelectItem value="high">High (Best quality)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Backup & Version Control */}
      <Card>
        <CardHeader>
          <CardTitle>Backup & Version Control</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Auto Backup</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Automatically backup your uploads
              </p>
            </div>
            <Switch
              checked={settings.auto_backup}
              onCheckedChange={(checked) => updateSettings('auto_backup', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Version Control</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Keep track of document versions
              </p>
            </div>
            <Switch
              checked={settings.version_control}
              onCheckedChange={(checked) => updateSettings('version_control', checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={loading} className="px-8">
          <Save className="w-4 h-4 mr-2" />
          {loading ? 'Saving...' : 'Save Content Settings'}
        </Button>
      </div>
    </div>
  );
};

export default ContentSection;
