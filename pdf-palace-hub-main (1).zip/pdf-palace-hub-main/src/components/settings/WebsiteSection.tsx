
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Save } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

interface WebsiteSettings {
  pdf_auto_download: boolean;
  pdf_quality_preference: 'low' | 'medium' | 'high';
  default_view_mode: 'grid' | 'list';
  show_pdf_previews: boolean;
  enable_comments: boolean;
  enable_likes: boolean;
  auto_follow_uploaders: boolean;
  bookmark_sync: boolean;
  reading_progress_tracking: boolean;
}

const WebsiteSection = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [settings, setSettings] = useState<WebsiteSettings>({
    pdf_auto_download: false,
    pdf_quality_preference: 'medium',
    default_view_mode: 'grid',
    show_pdf_previews: true,
    enable_comments: true,
    enable_likes: true,
    auto_follow_uploaders: false,
    bookmark_sync: true,
    reading_progress_tracking: true
  });

  useEffect(() => {
    if (user) {
      fetchSettings();
    }
  }, [user]);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('user_website_settings')
        .select('*')
        .eq('user_id', user?.id)
        .single();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setSettings({
          pdf_auto_download: data.pdf_auto_download,
          pdf_quality_preference: data.pdf_quality_preference as 'low' | 'medium' | 'high',
          default_view_mode: data.default_view_mode as 'grid' | 'list',
          show_pdf_previews: data.show_pdf_previews,
          enable_comments: data.enable_comments,
          enable_likes: data.enable_likes,
          auto_follow_uploaders: data.auto_follow_uploaders,
          bookmark_sync: data.bookmark_sync,
          reading_progress_tracking: data.reading_progress_tracking
        });
      }
    } catch (error) {
      console.error('Error fetching website settings:', error);
      toast({
        title: "Error",
        description: "Failed to load website settings",
        variant: "destructive"
      });
    }
  };

  const handleSave = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('user_website_settings')
        .upsert({
          user_id: user.id,
          ...settings,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Website settings updated successfully"
      });
    } catch (error) {
      console.error('Error updating website settings:', error);
      toast({
        title: "Error",
        description: "Failed to update website settings",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* PDF Viewing Preferences */}
      <Card>
        <CardHeader>
          <CardTitle>PDF Viewing Preferences</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Auto-download PDFs</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Automatically download PDFs when clicked
              </p>
            </div>
            <Switch
              checked={settings.pdf_auto_download}
              onCheckedChange={(checked) => 
                setSettings(prev => ({ ...prev, pdf_auto_download: checked }))
              }
            />
          </div>

          <div className="space-y-2">
            <Label>PDF Quality Preference</Label>
            <Select
              value={settings.pdf_quality_preference}
              onValueChange={(value: 'low' | 'medium' | 'high') =>
                setSettings(prev => ({ ...prev, pdf_quality_preference: value }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Default View Mode</Label>
            <Select
              value={settings.default_view_mode}
              onValueChange={(value: 'grid' | 'list') =>
                setSettings(prev => ({ ...prev, default_view_mode: value }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="grid">Grid</SelectItem>
                <SelectItem value="list">List</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Show PDF Previews</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Display thumbnail previews of PDFs
              </p>
            </div>
            <Switch
              checked={settings.show_pdf_previews}
              onCheckedChange={(checked) => 
                setSettings(prev => ({ ...prev, show_pdf_previews: checked }))
              }
            />
          </div>
        </CardContent>
      </Card>

      {/* Interaction Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Interaction Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Enable Comments</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Allow commenting on PDFs
              </p>
            </div>
            <Switch
              checked={settings.enable_comments}
              onCheckedChange={(checked) => 
                setSettings(prev => ({ ...prev, enable_comments: checked }))
              }
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Enable Likes</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Allow liking PDFs
              </p>
            </div>
            <Switch
              checked={settings.enable_likes}
              onCheckedChange={(checked) => 
                setSettings(prev => ({ ...prev, enable_likes: checked }))
              }
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Auto-follow Uploaders</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Automatically follow users when you like their PDFs
              </p>
            </div>
            <Switch
              checked={settings.auto_follow_uploaders}
              onCheckedChange={(checked) => 
                setSettings(prev => ({ ...prev, auto_follow_uploaders: checked }))
              }
            />
          </div>
        </CardContent>
      </Card>

      {/* Sync & Tracking */}
      <Card>
        <CardHeader>
          <CardTitle>Sync & Tracking</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Bookmark Sync</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Sync bookmarks across devices
              </p>
            </div>
            <Switch
              checked={settings.bookmark_sync}
              onCheckedChange={(checked) => 
                setSettings(prev => ({ ...prev, bookmark_sync: checked }))
              }
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Reading Progress Tracking</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Track your reading progress in PDFs
              </p>
            </div>
            <Switch
              checked={settings.reading_progress_tracking}
              onCheckedChange={(checked) => 
                setSettings(prev => ({ ...prev, reading_progress_tracking: checked }))
              }
            />
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={loading} className="px-8">
          <Save className="w-4 h-4 mr-2" />
          {loading ? 'Saving...' : 'Save Changes'}
        </Button>
      </div>
    </div>
  );
};

export default WebsiteSection;
