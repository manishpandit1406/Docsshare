
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { toast } from '@/hooks/use-toast';
import { Download, Database, HardDrive, FileText } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';

const DataSection = () => {
  const { user } = useAuth();
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [stats, setStats] = useState({
    pdfCount: 0,
    totalViews: 0,
    storageUsed: 0
  });

  useEffect(() => {
    if (user) {
      fetchUserStats();
    }
  }, [user]);

  const fetchUserStats = async () => {
    try {
      // Fetch user's PDFs and calculate stats
      const { data: pdfs, error: pdfsError } = await supabase
        .from('pdfs')
        .select('file_size, views_count')
        .eq('user_id', user?.id);

      if (pdfsError) throw pdfsError;

      const pdfCount = pdfs?.length || 0;
      const totalViews = pdfs?.reduce((sum, pdf) => sum + (pdf.views_count || 0), 0) || 0;
      const storageUsed = pdfs?.reduce((sum, pdf) => sum + (pdf.file_size || 0), 0) || 0;

      setStats({
        pdfCount,
        totalViews,
        storageUsed: Math.round(storageUsed / 1024 / 1024) // Convert to MB
      });
    } catch (error) {
      console.error('Error fetching user stats:', error);
    }
  };

  const handleExportData = async () => {
    if (!user) return;

    setIsExporting(true);
    setExportProgress(0);

    try {
      // Simulate progress
      const progressInterval = setInterval(() => {
        setExportProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 200);

      // Fetch all user data
      const [profileData, pdfsData, notificationSettings, appearanceSettings, privacySettings] = await Promise.all([
        supabase.from('profiles').select('*').eq('id', user.id).maybeSingle(),
        supabase.from('pdfs').select('*').eq('user_id', user.id),
        supabase.from('user_notification_settings').select('*').eq('user_id', user.id).maybeSingle(),
        supabase.from('user_appearance_settings').select('*').eq('user_id', user.id).maybeSingle(),
        supabase.from('user_privacy_settings').select('*').eq('user_id', user.id).maybeSingle()
      ]);

      const exportData = {
        profile: profileData.data,
        pdfs: pdfsData.data,
        settings: {
          notifications: notificationSettings.data,
          appearance: appearanceSettings.data,
          privacy: privacySettings.data
        },
        exportDate: new Date().toISOString()
      };

      // Create and download JSON file
      const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `user_data_export_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      clearInterval(progressInterval);
      setExportProgress(100);

      toast({
        title: "Export Complete",
        description: "Your data has been exported successfully"
      });
    } catch (error) {
      console.error('Error exporting data:', error);
      toast({
        title: "Export Failed",
        description: "Failed to export your data",
        variant: "destructive"
      });
    } finally {
      setTimeout(() => {
        setIsExporting(false);
        setExportProgress(0);
      }, 1000);
    }
  };

  const clearCache = async () => {
    // Clear browser cache
    if ('caches' in window) {
      const cacheNames = await caches.keys();
      await Promise.all(cacheNames.map(name => caches.delete(name)));
    }
    
    toast({
      title: "Cache Cleared",
      description: "Browser cache and temporary files have been cleared"
    });
  };

  const storageLimit = 1000; // MB
  const storagePercentage = (stats.storageUsed / storageLimit) * 100;

  return (
    <div className="space-y-6">
      {/* Storage Usage */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <HardDrive className="w-5 h-5" />
            Storage Usage
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Used</span>
              <span>{stats.storageUsed} MB of {storageLimit} MB</span>
            </div>
            <Progress value={storagePercentage} className="w-full" />
          </div>
          
          <div className="grid grid-cols-2 gap-4 mt-4">
            <div className="text-center p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <FileText className="w-8 h-8 mx-auto mb-2 text-blue-600" />
              <div className="text-2xl font-bold">{stats.pdfCount}</div>
              <div className="text-sm text-gray-500">PDFs Uploaded</div>
            </div>
            <div className="text-center p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <Database className="w-8 h-8 mx-auto mb-2 text-green-600" />
              <div className="text-2xl font-bold">{stats.totalViews}</div>
              <div className="text-sm text-gray-500">Total Views</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Data Export */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="w-5 h-5" />
            Export Your Data
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <AlertDescription>
              Export all your data including profile information, uploaded PDFs, comments, and activity history. 
              This may take a few minutes depending on the amount of data.
            </AlertDescription>
          </Alert>
          
          {isExporting && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Exporting...</span>
                <span>{exportProgress}%</span>
              </div>
              <Progress value={exportProgress} className="w-full" />
            </div>
          )}
          
          <Button 
            onClick={handleExportData} 
            disabled={isExporting}
            className="w-full"
          >
            <Download className="w-4 h-4 mr-2" />
            {isExporting ? 'Exporting...' : 'Export My Data'}
          </Button>
        </CardContent>
      </Card>

      {/* Data Management */}
      <Card>
        <CardHeader>
          <CardTitle>Data Management</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4">
            <Button variant="outline" className="justify-start" onClick={clearCache}>
              <HardDrive className="w-4 h-4 mr-2" />
              Clear Cache & Temporary Files
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Data Retention */}
      <Card>
        <CardHeader>
          <CardTitle>Data Retention</CardTitle>
        </CardHeader>
        <CardContent>
          <Alert>
            <AlertDescription>
              Your data is retained according to our privacy policy. 
              Deleted items are permanently removed after 30 days. 
              You can request immediate deletion by contacting support.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    </div>
  );
};

export default DataSection;
