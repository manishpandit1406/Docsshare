
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Save, Shield, Lock, Key, AlertTriangle, Clock, Globe } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

interface SecuritySettings {
  two_factor_enabled: boolean;
  login_alerts: boolean;
  session_timeout_minutes: number;
  ip_whitelist: string[];
  download_restrictions: boolean;
  password_change_required: boolean;
  suspicious_activity_alerts: boolean;
  device_management: boolean;
  api_access_enabled: boolean;
  audit_logging: boolean;
  failed_login_lockout: boolean;
  max_failed_attempts: number;
  auto_logout_inactive: boolean;
  secure_sharing_only: boolean;
}

const SecuritySection = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [newIpAddress, setNewIpAddress] = useState('');
  const [settings, setSettings] = useState<SecuritySettings>({
    two_factor_enabled: false,
    login_alerts: true,
    session_timeout_minutes: 60,
    ip_whitelist: [],
    download_restrictions: false,
    password_change_required: false,
    suspicious_activity_alerts: true,
    device_management: true,
    api_access_enabled: false,
    audit_logging: true,
    failed_login_lockout: true,
    max_failed_attempts: 5,
    auto_logout_inactive: true,
    secure_sharing_only: false
  });

  useEffect(() => {
    if (user) {
      fetchSettings();
    }
  }, [user]);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('user_security_settings')
        .select('*')
        .eq('user_id', user?.id)
        .single();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setSettings({
          two_factor_enabled: data.two_factor_enabled,
          login_alerts: data.login_alerts,
          session_timeout_minutes: data.session_timeout_minutes,
          ip_whitelist: data.ip_whitelist || [],
          download_restrictions: data.download_restrictions,
          password_change_required: data.password_change_required,
          suspicious_activity_alerts: data.suspicious_activity_alerts ?? true,
          device_management: data.device_management ?? true,
          api_access_enabled: data.api_access_enabled ?? false,
          audit_logging: data.audit_logging ?? true,
          failed_login_lockout: data.failed_login_lockout ?? true,
          max_failed_attempts: data.max_failed_attempts ?? 5,
          auto_logout_inactive: data.auto_logout_inactive ?? true,
          secure_sharing_only: data.secure_sharing_only ?? false
        });
      }
    } catch (error) {
      console.error('Error fetching security settings:', error);
      toast({
        title: "Error",
        description: "Failed to load security settings",
        variant: "destructive"
      });
    }
  };

  const handleSave = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('user_security_settings')
        .upsert({
          user_id: user.id,
          ...settings,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Security settings updated successfully"
      });
    } catch (error) {
      console.error('Error updating security settings:', error);
      toast({
        title: "Error",
        description: "Failed to update security settings",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const updateSettings = (key: keyof SecuritySettings, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const addIpAddress = () => {
    if (newIpAddress && !settings.ip_whitelist.includes(newIpAddress)) {
      const ipRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
      if (ipRegex.test(newIpAddress)) {
        updateSettings('ip_whitelist', [...settings.ip_whitelist, newIpAddress]);
        setNewIpAddress('');
      } else {
        toast({
          title: "Invalid IP Address",
          description: "Please enter a valid IP address",
          variant: "destructive"
        });
      }
    }
  };

  const removeIpAddress = (ip: string) => {
    updateSettings('ip_whitelist', settings.ip_whitelist.filter(address => address !== ip));
  };

  return (
    <div className="space-y-6">
      {/* Authentication Security */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="w-5 h-5" />
            Authentication Security
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Two-Factor Authentication</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Add an extra layer of security to your account
              </p>
            </div>
            <Switch
              checked={settings.two_factor_enabled}
              onCheckedChange={(checked) => updateSettings('two_factor_enabled', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Login Alerts</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Get notified of new login attempts
              </p>
            </div>
            <Switch
              checked={settings.login_alerts}
              onCheckedChange={(checked) => updateSettings('login_alerts', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Password Change Required</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Force password change on next login
              </p>
            </div>
            <Switch
              checked={settings.password_change_required}
              onCheckedChange={(checked) => updateSettings('password_change_required', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Failed Login Lockout</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Lock account after multiple failed login attempts
              </p>
            </div>
            <Switch
              checked={settings.failed_login_lockout}
              onCheckedChange={(checked) => updateSettings('failed_login_lockout', checked)}
            />
          </div>

          {settings.failed_login_lockout && (
            <div className="space-y-2">
              <Label>Maximum Failed Attempts</Label>
              <Input
                type="number"
                min="3"
                max="10"
                value={settings.max_failed_attempts}
                onChange={(e) => updateSettings('max_failed_attempts', parseInt(e.target.value))}
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Session Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Session Management
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>Session Timeout (minutes)</Label>
            <Select
              value={settings.session_timeout_minutes.toString()}
              onValueChange={(value) => updateSettings('session_timeout_minutes', parseInt(value))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="15">15 minutes</SelectItem>
                <SelectItem value="30">30 minutes</SelectItem>
                <SelectItem value="60">1 hour</SelectItem>
                <SelectItem value="120">2 hours</SelectItem>
                <SelectItem value="240">4 hours</SelectItem>
                <SelectItem value="480">8 hours</SelectItem>
                <SelectItem value="1440">24 hours</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Auto Logout When Inactive</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Automatically log out after period of inactivity
              </p>
            </div>
            <Switch
              checked={settings.auto_logout_inactive}
              onCheckedChange={(checked) => updateSettings('auto_logout_inactive', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Device Management</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Track and manage logged-in devices
              </p>
            </div>
            <Switch
              checked={settings.device_management}
              onCheckedChange={(checked) => updateSettings('device_management', checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Access Control */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="w-5 h-5" />
            Access Control
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>IP Address Whitelist</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Restrict access to specific IP addresses
              </p>
              <div className="flex gap-2">
                <Input
                  placeholder="Enter IP address (e.g., 192.168.1.1)"
                  value={newIpAddress}
                  onChange={(e) => setNewIpAddress(e.target.value)}
                />
                <Button onClick={addIpAddress} variant="outline">
                  Add
                </Button>
              </div>
            </div>

            {settings.ip_whitelist.length > 0 && (
              <div className="space-y-2">
                <Label>Whitelisted IP Addresses</Label>
                <div className="space-y-2">
                  {settings.ip_whitelist.map((ip, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-800 rounded">
                      <span className="text-sm font-mono">{ip}</span>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={() => removeIpAddress(ip)}
                        className="text-red-600 hover:text-red-700"
                      >
                        Remove
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Download Restrictions</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Apply restrictions to file downloads
              </p>
            </div>
            <Switch
              checked={settings.download_restrictions}
              onCheckedChange={(checked) => updateSettings('download_restrictions', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Secure Sharing Only</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Require authentication for all shared content
              </p>
            </div>
            <Switch
              checked={settings.secure_sharing_only}
              onCheckedChange={(checked) => updateSettings('secure_sharing_only', checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Security Monitoring */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" />
            Security Monitoring
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Suspicious Activity Alerts</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Get notified of unusual account activity
              </p>
            </div>
            <Switch
              checked={settings.suspicious_activity_alerts}
              onCheckedChange={(checked) => updateSettings('suspicious_activity_alerts', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Audit Logging</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Keep detailed logs of account activities
              </p>
            </div>
            <Switch
              checked={settings.audit_logging}
              onCheckedChange={(checked) => updateSettings('audit_logging', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>API Access</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Enable API access for third-party applications
              </p>
            </div>
            <Switch
              checked={settings.api_access_enabled}
              onCheckedChange={(checked) => updateSettings('api_access_enabled', checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={loading} className="px-8">
          <Save className="w-4 h-4 mr-2" />
          {loading ? 'Saving...' : 'Save Security Settings'}
        </Button>
      </div>
    </div>
  );
};

export default SecuritySection;
