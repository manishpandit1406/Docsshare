
import React from 'react';
import { Button } from '@/components/ui/button';
import { 
  User, 
  Shield, 
  Bell, 
  Palette, 
  Key, 
  Download,
  FileText,
  Upload,
  Lock
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface SettingsSidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
  className?: string;
}

const settingsItems = [
  {
    id: 'profile',
    label: 'Profile',
    icon: User,
    description: 'Manage your profile information'
  },
  {
    id: 'account',
    label: 'Account',
    icon: Shield,
    description: 'Account security and login settings'
  },
  {
    id: 'notifications',
    label: 'Notifications',
    icon: Bell,
    description: 'Email and push notification preferences'
  },
  {
    id: 'appearance',
    label: 'Appearance',
    icon: Palette,
    description: 'Theme and display settings'
  },
  {
    id: 'website',
    label: 'Website Settings',
    icon: FileText,
    description: 'PDF viewing and interaction preferences'
  },
  {
    id: 'content',
    label: 'Content Management',
    icon: Upload,
    description: 'Upload and content management settings'
  },
  {
    id: 'security',
    label: 'Security',
    icon: Lock,
    description: 'Advanced security and access controls'
  },
  {
    id: 'privacy',
    label: 'Privacy',
    icon: Key,
    description: 'Privacy and data settings'
  },
  {
    id: 'data',
    label: 'Data & Storage',
    icon: Download,
    description: 'Export and manage your data'
  }
];

const SettingsSidebar: React.FC<SettingsSidebarProps> = ({ 
  activeSection, 
  onSectionChange,
  className 
}) => {
  return (
    <div className={cn(
      "w-80 h-full bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 p-6 overflow-y-auto",
      className
    )}>
      <div className="mb-6">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
          Settings
        </h2>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
          Manage your account preferences
        </p>
      </div>
      
      <nav className="space-y-2">
        {settingsItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeSection === item.id;
          
          return (
            <Button
              key={item.id}
              variant="ghost"
              className={cn(
                "w-full justify-start p-3 h-auto text-left",
                isActive 
                  ? "bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 border-l-4 border-blue-600" 
                  : "hover:bg-gray-50 dark:hover:bg-gray-700"
              )}
              onClick={() => onSectionChange(item.id)}
            >
              <Icon className={cn(
                "w-5 h-5 mr-3 flex-shrink-0",
                isActive ? "text-blue-600 dark:text-blue-400" : "text-gray-400"
              )} />
              <div className="flex-1 min-w-0">
                <div className="font-medium">{item.label}</div>
                <div className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                  {item.description}
                </div>
              </div>
            </Button>
          );
        })}
      </nav>
    </div>
  );
};

export default SettingsSidebar;
