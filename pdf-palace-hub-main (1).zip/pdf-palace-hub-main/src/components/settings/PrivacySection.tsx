
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { toast } from '@/hooks/use-toast';
import { Shield, Eye, Lock } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';

const PrivacySection = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [profileVisibility, setProfileVisibility] = useState('public');
  const [showEmail, setShowEmail] = useState(false);
  const [allowMessages, setAllowMessages] = useState(true);
  const [indexProfile, setIndexProfile] = useState(true);
  const [analyticsOptOut, setAnalyticsOptOut] = useState(false);

  useEffect(() => {
    if (user) {
      fetchPrivacySettings();
    }
  }, [user]);

  const fetchPrivacySettings = async () => {
    try {
      const { data, error } = await supabase
        .from('user_privacy_settings')
        .select('*')
        .eq('user_id', user?.id)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setProfileVisibility(data.profile_visibility || 'public');
        setShowEmail(data.show_email || false);
        setAllowMessages(data.allow_messages !== false);
        setIndexProfile(data.index_profile !== false);
        setAnalyticsOptOut(data.analytics_opt_out || false);
      }
    } catch (error) {
      console.error('Error fetching privacy settings:', error);
      toast({
        title: "Error",
        description: "Failed to load privacy settings",
        variant: "destructive"
      });
    }
  };

  const handleSavePrivacy = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('user_privacy_settings')
        .upsert({
          user_id: user.id,
          profile_visibility: profileVisibility,
          show_email: showEmail,
          allow_messages: allowMessages,
          index_profile: indexProfile,
          analytics_opt_out: analyticsOptOut,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Privacy settings updated successfully"
      });
    } catch (error) {
      console.error('Error updating privacy settings:', error);
      toast({
        title: "Error",
        description: "Failed to update privacy settings",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Profile Visibility */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5" />
            Profile Visibility
          </CardTitle>
        </CardHeader>
        <CardContent>
          <RadioGroup value={profileVisibility} onValueChange={setProfileVisibility} className="space-y-3">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="public" id="public" />
              <Label htmlFor="public" className="cursor-pointer">
                <div>
                  <div className="font-medium">Public</div>
                  <div className="text-sm text-gray-500">Anyone can see your profile and PDFs</div>
                </div>
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="followers" id="followers" />
              <Label htmlFor="followers" className="cursor-pointer">
                <div>
                  <div className="font-medium">Followers Only</div>
                  <div className="text-sm text-gray-500">Only your followers can see your profile</div>
                </div>
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="private" id="private" />
              <Label htmlFor="private" className="cursor-pointer">
                <div>
                  <div className="font-medium">Private</div>
                  <div className="text-sm text-gray-500">Only you can see your profile</div>
                </div>
              </Label>
            </div>
          </RadioGroup>
        </CardContent>
      </Card>

      {/* Contact Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="w-5 h-5" />
            Contact Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>Show Email Address</Label>
              <p className="text-sm text-gray-500">
                Display your email address on your public profile
              </p>
            </div>
            <Switch
              checked={showEmail}
              onCheckedChange={setShowEmail}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label>Allow Direct Messages</Label>
              <p className="text-sm text-gray-500">
                Let other users send you direct messages
              </p>
            </div>
            <Switch
              checked={allowMessages}
              onCheckedChange={setAllowMessages}
            />
          </div>
        </CardContent>
      </Card>

      {/* Search & Discovery */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Search & Discovery
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>Index Profile in Search</Label>
              <p className="text-sm text-gray-500">
                Allow search engines to index your profile
              </p>
            </div>
            <Switch
              checked={indexProfile}
              onCheckedChange={setIndexProfile}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label>Opt out of Analytics</Label>
              <p className="text-sm text-gray-500">
                Don't include your data in usage analytics
              </p>
            </div>
            <Switch
              checked={analyticsOptOut}
              onCheckedChange={setAnalyticsOptOut}
            />
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSavePrivacy} disabled={loading} className="px-8">
          {loading ? 'Saving...' : 'Save Privacy Settings'}
        </Button>
      </div>
    </div>
  );
};

export default PrivacySection;
