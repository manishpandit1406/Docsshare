
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Camera, Save } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import ImageCropDialog from '@/components/ImageCropDialog';

interface ProfileData {
  username: string;
  full_name: string;
  bio: string;
  website: string;
  avatar_url: string;
  cover_image_url: string;
}

const ProfileSection = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [profile, setProfile] = useState<ProfileData>({
    username: '',
    full_name: '',
    bio: '',
    website: '',
    avatar_url: '',
    cover_image_url: ''
  });
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [showAvatarCrop, setShowAvatarCrop] = useState(false);
  const [showCoverCrop, setShowCoverCrop] = useState(false);

  useEffect(() => {
    if (user) {
      fetchProfile();
    }
  }, [user]);

  const fetchProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user?.id)
        .single();

      if (error) throw error;

      if (data) {
        setProfile({
          username: data.username || '',
          full_name: data.full_name || '',
          bio: data.bio || '',
          website: data.website || '',
          avatar_url: data.avatar_url || '',
          cover_image_url: data.cover_image_url || ''
        });
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
      toast({
        title: "Error",
        description: "Failed to load profile data",
        variant: "destructive"
      });
    }
  };

  const uploadImage = async (file: File, bucket: string, folder: string): Promise<string> => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${user?.id}-${Date.now()}.${fileExt}`;
    const filePath = `${folder}/${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from(bucket)
      .upload(filePath, file);

    if (uploadError) {
      throw uploadError;
    }

    const { data } = supabase.storage
      .from(bucket)
      .getPublicUrl(filePath);

    return data.publicUrl;
  };

  const handleImageSelect = (file: File, type: 'avatar' | 'cover') => {
    if (type === 'avatar') {
      setAvatarFile(file);
      setShowAvatarCrop(true);
    } else {
      setCoverFile(file);
      setShowCoverCrop(true);
    }
  };

  const handleCroppedImage = async (croppedFile: File, type: 'avatar' | 'cover') => {
    try {
      setUploading(true);
      const bucket = 'avatars';
      const folder = type === 'avatar' ? 'avatars' : 'covers';
      const imageUrl = await uploadImage(croppedFile, bucket, folder);
      
      setProfile(prev => ({
        ...prev,
        [type === 'avatar' ? 'avatar_url' : 'cover_image_url']: imageUrl
      }));

      toast({
        title: "Success",
        description: `${type === 'avatar' ? 'Avatar' : 'Cover image'} uploaded successfully`
      });
    } catch (error) {
      console.error(`Error uploading ${type}:`, error);
      toast({
        title: "Error",
        description: `Failed to upload ${type}`,
        variant: "destructive"
      });
    } finally {
      setUploading(false);
      if (type === 'avatar') {
        setShowAvatarCrop(false);
        setAvatarFile(null);
      } else {
        setShowCoverCrop(false);
        setCoverFile(null);
      }
    }
  };

  const handleSave = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .upsert({
          id: user.id,
          username: profile.username,
          full_name: profile.full_name,
          bio: profile.bio,
          website: profile.website,
          avatar_url: profile.avatar_url,
          cover_image_url: profile.cover_image_url,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Profile updated successfully"
      });
    } catch (error) {
      console.error('Error updating profile:', error);
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const triggerFileInput = (inputId: string) => {
    document.getElementById(inputId)?.click();
  };

  return (
    <div className="space-y-6">
      {/* Cover Image Section */}
      <Card>
        <CardHeader>
          <CardTitle>Cover Image</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <div 
              className="w-full h-48 bg-gradient-to-r from-blue-400 to-purple-500 rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
              style={{
                backgroundImage: profile.cover_image_url ? `url(${profile.cover_image_url})` : undefined,
                backgroundSize: 'cover',
                backgroundPosition: 'center'
              }}
              onClick={() => triggerFileInput('cover-upload')}
            >
              <div className="absolute inset-0 bg-black bg-opacity-40 rounded-lg flex items-center justify-center">
                <Camera className="w-8 h-8 text-white" />
              </div>
            </div>
            <input
              id="cover-upload"
              type="file"
              accept="image/*"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleImageSelect(file, 'cover');
              }}
              className="hidden"
            />
          </div>
        </CardContent>
      </Card>

      {/* Avatar and Basic Info */}
      <Card>
        <CardHeader>
          <CardTitle>Profile Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Avatar Section */}
          <div className="flex items-center space-x-6">
            <div className="relative">
              <Avatar className="w-24 h-24">
                <AvatarImage src={profile.avatar_url} />
                <AvatarFallback className="text-2xl">
                  {profile.full_name?.[0] || profile.username?.[0] || 'U'}
                </AvatarFallback>
              </Avatar>
              <button
                onClick={() => triggerFileInput('avatar-upload')}
                className="absolute -bottom-2 -right-2 bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 transition-colors"
                disabled={uploading}
              >
                <Camera className="w-4 h-4" />
              </button>
            </div>
            
            <div className="flex-1">
              <h3 className="text-lg font-semibold">Profile Picture</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Upload a profile picture to help others recognize you
              </p>
            </div>

            <input
              id="avatar-upload"
              type="file"
              accept="image/*"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleImageSelect(file, 'avatar');
              }}
              className="hidden"
            />
          </div>

          {/* Form Fields */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                value={profile.username}
                onChange={(e) => setProfile(prev => ({ ...prev, username: e.target.value }))}
                placeholder="Your username"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="full_name">Full Name</Label>
              <Input
                id="full_name"
                value={profile.full_name}
                onChange={(e) => setProfile(prev => ({ ...prev, full_name: e.target.value }))}
                placeholder="Your full name"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="website">Website</Label>
            <Input
              id="website"
              value={profile.website}
              onChange={(e) => setProfile(prev => ({ ...prev, website: e.target.value }))}
              placeholder="https://yourwebsite.com"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="bio">Bio</Label>
            <Textarea
              id="bio"
              value={profile.bio}
              onChange={(e) => setProfile(prev => ({ ...prev, bio: e.target.value }))}
              placeholder="Tell us about yourself..."
              rows={4}
            />
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={loading} className="px-8">
          <Save className="w-4 h-4 mr-2" />
          {loading ? 'Saving...' : 'Save Changes'}
        </Button>
      </div>

      {/* Image Crop Dialogs */}
      {showAvatarCrop && avatarFile && (
        <ImageCropDialog
          open={showAvatarCrop}
          onOpenChange={setShowAvatarCrop}
          imageSrc={URL.createObjectURL(avatarFile)}
          onCropComplete={(croppedFile) => handleCroppedImage(croppedFile, 'avatar')}
          aspectRatio={1}
          type="avatar"
        />
      )}

      {showCoverCrop && coverFile && (
        <ImageCropDialog
          open={showCoverCrop}
          onOpenChange={setShowCoverCrop}
          imageSrc={URL.createObjectURL(coverFile)}
          onCropComplete={(croppedFile) => handleCroppedImage(croppedFile, 'cover')}
          aspectRatio={16/9}
          type="cover"
        />
      )}
    </div>
  );
};

export default ProfileSection;
