
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';
import { Bell, Mail, Smartphone, Save, Clock, Volume2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';

const NotificationsSection = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [settings, setSettings] = useState({
    email_pdf_likes: true,
    email_pdf_comments: true,
    email_new_followers: true,
    email_weekly_digest: false,
    email_promotions: false,
    push_pdf_likes: false,
    push_pdf_comments: true,
    push_new_followers: true,
    push_mentions: true,
    notification_frequency: 'instant',
    quiet_hours_enabled: false,
    quiet_hours_start: '22:00',
    quiet_hours_end: '08:00',
    sound_enabled: true,
    desktop_notifications: true,
    mobile_notifications: true
  });

  useEffect(() => {
    if (user) {
      fetchNotificationSettings();
    }
  }, [user]);

  const fetchNotificationSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('user_notification_settings')
        .select('*')
        .eq('user_id', user?.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setSettings({
          email_pdf_likes: data.email_pdf_likes ?? true,
          email_pdf_comments: data.email_pdf_comments ?? true,
          email_new_followers: data.email_new_followers ?? true,
          email_weekly_digest: data.email_weekly_digest ?? false,
          email_promotions: data.email_promotions ?? false,
          push_pdf_likes: data.push_pdf_likes ?? false,
          push_pdf_comments: data.push_pdf_comments ?? true,
          push_new_followers: data.push_new_followers ?? true,
          push_mentions: data.push_mentions ?? true,
          notification_frequency: data.notification_frequency || 'instant',
          quiet_hours_enabled: data.quiet_hours_enabled ?? false,
          quiet_hours_start: data.quiet_hours_start || '22:00',
          quiet_hours_end: data.quiet_hours_end || '08:00',
          sound_enabled: data.sound_enabled ?? true,
          desktop_notifications: data.desktop_notifications ?? true,
          mobile_notifications: data.mobile_notifications ?? true
        });
      }
    } catch (error) {
      console.error('Error fetching notification settings:', error);
      toast({
        title: "Error",
        description: "Failed to load notification settings",
        variant: "destructive"
      });
    }
  };

  const handleSave = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('user_notification_settings')
        .upsert({
          user_id: user.id,
          ...settings,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Notification settings updated successfully"
      });
    } catch (error) {
      console.error('Error updating notification settings:', error);
      toast({
        title: "Error",
        description: "Failed to update notification settings",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const updateSettings = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="space-y-6">
      {/* Email Notifications */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5" />
            Email Notifications
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>PDF Likes</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Get notified when someone likes your PDFs
              </p>
            </div>
            <Switch
              checked={settings.email_pdf_likes}
              onCheckedChange={(checked) => updateSettings('email_pdf_likes', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>PDF Comments</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Get notified when someone comments on your PDFs
              </p>
            </div>
            <Switch
              checked={settings.email_pdf_comments}
              onCheckedChange={(checked) => updateSettings('email_pdf_comments', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>New Followers</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Get notified when someone follows you
              </p>
            </div>
            <Switch
              checked={settings.email_new_followers}
              onCheckedChange={(checked) => updateSettings('email_new_followers', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Weekly Digest</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Weekly summary of your activity
              </p>
            </div>
            <Switch
              checked={settings.email_weekly_digest}
              onCheckedChange={(checked) => updateSettings('email_weekly_digest', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Promotions</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Receive promotional emails and updates
              </p>
            </div>
            <Switch
              checked={settings.email_promotions}
              onCheckedChange={(checked) => updateSettings('email_promotions', checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Push Notifications */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smartphone className="w-5 h-5" />
            Push Notifications
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Desktop Notifications</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Show notifications on desktop
              </p>
            </div>
            <Switch
              checked={settings.desktop_notifications}
              onCheckedChange={(checked) => updateSettings('desktop_notifications', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Mobile Notifications</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Show notifications on mobile devices
              </p>
            </div>
            <Switch
              checked={settings.mobile_notifications}
              onCheckedChange={(checked) => updateSettings('mobile_notifications', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>PDF Likes</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Push notifications for PDF likes
              </p>
            </div>
            <Switch
              checked={settings.push_pdf_likes}
              onCheckedChange={(checked) => updateSettings('push_pdf_likes', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>PDF Comments</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Push notifications for PDF comments
              </p>
            </div>
            <Switch
              checked={settings.push_pdf_comments}
              onCheckedChange={(checked) => updateSettings('push_pdf_comments', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>New Followers</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Push notifications for new followers
              </p>
            </div>
            <Switch
              checked={settings.push_new_followers}
              onCheckedChange={(checked) => updateSettings('push_new_followers', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Mentions</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Push notifications when you're mentioned
              </p>
            </div>
            <Switch
              checked={settings.push_mentions}
              onCheckedChange={(checked) => updateSettings('push_mentions', checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Notification Preferences */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Notification Preferences
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>Notification Frequency</Label>
            <Select value={settings.notification_frequency} onValueChange={(value) => updateSettings('notification_frequency', value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="instant">Instant</SelectItem>
                <SelectItem value="hourly">Hourly</SelectItem>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Enable Quiet Hours</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Disable notifications during specified hours
              </p>
            </div>
            <Switch
              checked={settings.quiet_hours_enabled}
              onCheckedChange={(checked) => updateSettings('quiet_hours_enabled', checked)}
            />
          </div>

          {settings.quiet_hours_enabled && (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Start Time</Label>
                <input
                  type="time"
                  value={settings.quiet_hours_start}
                  onChange={(e) => updateSettings('quiet_hours_start', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="space-y-2">
                <Label>End Time</Label>
                <input
                  type="time"
                  value={settings.quiet_hours_end}
                  onChange={(e) => updateSettings('quiet_hours_end', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          )}

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="flex items-center gap-2">
                <Volume2 className="w-4 h-4" />
                Sound Notifications
              </Label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Play sound with notifications
              </p>
            </div>
            <Switch
              checked={settings.sound_enabled}
              onCheckedChange={(checked) => updateSettings('sound_enabled', checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={loading} className="px-8">
          <Save className="w-4 h-4 mr-2" />
          {loading ? 'Saving...' : 'Save Notification Settings'}
        </Button>
      </div>
    </div>
  );
};

export default NotificationsSection;
