
import React, { useState } from 'react';
import { X, Download, Heart, MessageCircle, Bookmark, Share2, MoreHorizontal, Maximize, FileText, File, Image, Bot, Crown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { usePDFInteractions } from '@/hooks/usePDFInteractions';
import { useWishlist } from '@/hooks/useWishlist';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import type { Document } from '@/types/document';
import FullscreenDocumentViewer from './FullscreenDocumentViewer';

interface DocumentViewerProps {
  document: Document | null;
  isOpen: boolean;
  onClose: () => void;
}

const DocumentViewer: React.FC<DocumentViewerProps> = ({ document, isOpen, onClose }) => {
  const [comment, setComment] = useState('');
  const [showFullscreen, setShowFullscreen] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [showAIChat, setShowAIChat] = useState(false);
  const { user } = useAuth();
  const { hasLiked, comments, loading, toggleLike, addComment } = usePDFInteractions(document?.id || '');
  const { isInWishlist, addToWishlist, removeFromWishlist } = useWishlist();

  const handleAddComment = async () => {
    if (!comment.trim()) return;
    await addComment(comment);
    setComment('');
  };

  const handleWishlistToggle = async () => {
    if (!document) return;
    
    if (isInWishlist(document.id)) {
      await removeFromWishlist(document.id);
    } else {
      await addToWishlist(document.id);
    }
  };

  const handleDownload = () => {
    // Check if user has subscription for download
    if (!user) {
      toast({
        title: "Sign in required",
        description: "Please sign in to download documents"
      });
      return;
    }

    // For now, show upgrade prompt for download (since subscription system isn't fully implemented)
    toast({
      title: "Upgrade to Pro",
      description: "Document downloads are available with a Pro subscription",
      action: (
        <Button size="sm" onClick={() => window.open('/upgrade', '_blank')}>
          <Crown className="w-4 h-4 mr-1" />
          Upgrade
        </Button>
      )
    });
  };

  const handleShare = () => {
    if (document) {
      const url = window.location.href;
      navigator.clipboard.writeText(url);
      toast({
        title: "Link copied",
        description: "Document link copied to clipboard"
      });
    }
  };

  const handleCommentsToggle = () => {
    setShowComments(!showComments);
    setShowAIChat(false);
  };

  const handleAIChatToggle = () => {
    setShowAIChat(!showAIChat);
    setShowComments(false);
  };

  const getFileIcon = () => {
    if (!document) return <FileText className="w-6 h-6" />;
    
    const fileType = document.file_type?.toLowerCase();
    
    switch (fileType) {
      case 'pdf':
        return <FileText className="w-6 h-6 text-red-600" />;
      case 'doc':
      case 'docx':
        return <FileText className="w-6 h-6 text-blue-600" />;
      case 'xls':
      case 'xlsx':
        return <File className="w-6 h-6 text-green-600" />;
      case 'ppt':
      case 'pptx':
        return <File className="w-6 h-6 text-orange-600" />;
      case 'txt':
      case 'rtf':
      case 'odt':
        return <File className="w-6 h-6 text-gray-600" />;
      default:
        return <FileText className="w-6 h-6" />;
    }
  };

  const renderDocumentViewer = () => {
    if (!document) return null;

    const fileType = document.file_type?.toLowerCase();

    // For PDF files, use iframe
    if (fileType === 'pdf') {
      return (
        <iframe
          src={`${document.file_url}#toolbar=0&navpanes=0&scrollbar=1`}
          className="w-full h-full"
          title={document.title}
        />
      );
    }

    // For Office documents, try to use Office Online viewer
    if (['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'].includes(fileType || '')) {
      const officeViewerUrl = `https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(document.file_url)}`;
      return (
        <iframe
          src={officeViewerUrl}
          className="w-full h-full"
          title={document.title}
        />
      );
    }

    // For text files, try to display content directly
    if (['txt', 'rtf'].includes(fileType || '')) {
      return (
        <div className="w-full h-full p-4 bg-white overflow-auto">
          <div className="flex flex-col items-center justify-center h-full text-center">
            {getFileIcon()}
            <h3 className="text-lg font-semibold mt-4 mb-2">{document.title}</h3>
            <p className="text-gray-600 mb-4">Text Document</p>
            <Button onClick={handleDownload} className="mb-2">
              <Download className="w-4 h-4 mr-2" />
              Download to View
            </Button>
            <p className="text-sm text-gray-500">
              This document will open in your default text editor
            </p>
          </div>
        </div>
      );
    }

    // For ODT and other formats
    return (
      <div className="w-full h-full p-4 bg-white overflow-auto">
        <div className="flex flex-col items-center justify-center h-full text-center">
          {getFileIcon()}
          <h3 className="text-lg font-semibold mt-4 mb-2">{document.title}</h3>
          <p className="text-gray-600 mb-4">{fileType?.toUpperCase()} Document</p>
          <Button onClick={handleDownload} className="mb-2">
            <Download className="w-4 h-4 mr-2" />
            Download to View
          </Button>
          <p className="text-sm text-gray-500">
            This document will open in your default application
          </p>
        </div>
      </div>
    );
  };

  if (!document) return null;

  return (
    <>
      <Dialog open={isOpen && !showFullscreen} onOpenChange={onClose}>
        <DialogContent className="max-w-6xl h-[90vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {getFileIcon()}
                <div>
                  <h2 className="text-xl font-bold">{document.title}</h2>
                  <p className="text-sm text-gray-600 mt-1">{document.description}</p>
                  <p className="text-xs text-gray-500">
                    {document.file_type?.toUpperCase()} • {document.file_size ? `${(document.file_size / (1024 * 1024)).toFixed(2)} MB` : 'Unknown size'}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {user && (
                  <>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={toggleLike}
                      disabled={loading}
                      className={hasLiked ? "text-red-600" : ""}
                    >
                      <Heart className={`w-4 h-4 ${hasLiked ? "fill-current" : ""}`} />
                      <span className="ml-1">{document.likes_count}</span>
                    </Button>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleWishlistToggle}
                      className={isInWishlist(document.id) ? "text-blue-600" : ""}
                    >
                      <Bookmark className={`w-4 h-4 ${isInWishlist(document.id) ? "fill-current" : ""}`} />
                    </Button>
                  </>
                )}
                
                <Button variant="outline" size="sm" onClick={() => setShowFullscreen(true)}>
                  <Maximize className="w-4 h-4 mr-1" />
                  Fullscreen
                </Button>
                
                <Button variant="outline" size="sm" onClick={handleShare}>
                  <Share2 className="w-4 h-4" />
                </Button>
                
                <Button variant="outline" size="sm" onClick={handleDownload}>
                  <Download className="w-4 h-4" />
                </Button>
              </div>
            </DialogTitle>
          </DialogHeader>

          <div className="flex-1 flex gap-4 overflow-hidden">
            {/* Document Viewer */}
            <div className="flex-1 bg-gray-100 rounded-lg overflow-hidden">
              {renderDocumentViewer()}
            </div>

            {/* Side Panel */}
            <div className="w-80 flex flex-col space-y-4">
              {/* Action Buttons */}
              <div className="flex space-x-2">
                <Button
                  variant={showComments ? "default" : "outline"}
                  size="sm"
                  onClick={handleCommentsToggle}
                  className="flex-1"
                >
                  <MessageCircle className="w-4 h-4 mr-1" />
                  Comments
                </Button>
                <Button
                  variant={showAIChat ? "default" : "outline"}
                  size="sm"
                  onClick={handleAIChatToggle}
                  className="flex-1"
                >
                  <Bot className="w-4 h-4 mr-1" />
                  AI Chat
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleDownload}
                  className="flex-1"
                >
                  <Download className="w-4 h-4 mr-1" />
                  Download
                </Button>
              </div>

              <div className="flex items-center space-x-4 text-sm text-gray-600">
                <span className="flex items-center space-x-1">
                  <MessageCircle className="w-4 h-4" />
                  <span>{document.comments_count} comments</span>
                </span>
                <span>{document.views_count} views</span>
              </div>

              {document.tags && document.tags.length > 0 && (
                <div className="flex flex-wrap gap-1">
                  {document.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}

              {/* Comments Section */}
              {showComments && (
                <div className="flex-1 flex flex-col space-y-3 overflow-hidden">
                  {user && (
                    <div className="space-y-2">
                      <Textarea
                        placeholder="Add a comment..."
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        className="resize-none"
                        rows={3}
                      />
                      <Button onClick={handleAddComment} size="sm" className="w-full">
                        Post Comment
                      </Button>
                    </div>
                  )}

                  <div className="flex-1 overflow-y-auto space-y-3">
                    {comments.map((comment) => (
                      <Card key={comment.id}>
                        <CardContent className="p-3">
                          <div className="flex items-start justify-between mb-2">
                            <span className="font-medium text-sm">
                              {comment.profiles?.full_name || comment.profiles?.username || 'Anonymous'}
                            </span>
                            <span className="text-xs text-gray-500">
                              {new Date(comment.created_at).toLocaleDateString()}
                            </span>
                          </div>
                          <p className="text-sm text-gray-700">{comment.content}</p>
                        </CardContent>
                      </Card>
                    ))}
                    
                    {comments.length === 0 && (
                      <p className="text-center text-gray-500 text-sm">No comments yet</p>
                    )}
                  </div>
                </div>
              )}

              {/* AI Chat Section */}
              {showAIChat && (
                <div className="flex-1 flex flex-col space-y-3 overflow-hidden">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <Bot className="w-5 h-5 text-blue-600" />
                      <span className="font-medium text-blue-900">AI Assistant</span>
                    </div>
                    <p className="text-sm text-blue-800">
                      Ask me anything about this document! I can help you understand the content, summarize key points, or answer specific questions.
                    </p>
                  </div>
                  
                  <div className="flex-1 bg-gray-50 rounded-lg p-4 flex items-center justify-center">
                    <div className="text-center">
                      <Bot className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-600 text-sm">AI Chat coming soon!</p>
                      <p className="text-gray-500 text-xs mt-1">This feature will be available in the next update.</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Default view when no panel is selected */}
              {!showComments && !showAIChat && (
                <div className="flex-1 overflow-y-auto space-y-3">
                  <p className="text-center text-gray-500 text-sm">
                    Select Comments or AI Chat to interact with this document
                  </p>
                </div>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <FullscreenDocumentViewer
        document={document}
        isOpen={showFullscreen}
        onClose={() => setShowFullscreen(false)}
      />
    </>
  );
};

export default DocumentViewer;
