
import React from 'react';
import { User } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

interface UserProfile {
  id: string;
  full_name?: string;
  username?: string;
  avatar_url?: string;
}

interface UserCardProps {
  profile: UserProfile;
  onClick?: () => void;
  compact?: boolean;
}

const UserCard: React.FC<UserCardProps> = ({ profile, onClick, compact = false }) => {
  const handleClick = () => {
    if (onClick) {
      onClick();
    }
  };

  const getDisplayName = () => {
    if (profile.full_name) return profile.full_name;
    if (profile.username) return profile.username;
    return 'Anonymous User';
  };

  const getInitials = () => {
    const displayName = getDisplayName();
    if (displayName === 'Anonymous User') return 'A';
    return displayName.split(' ').map(name => name[0]).join('').slice(0, 2).toUpperCase();
  };

  if (compact) {
    return (
      <Card 
        className="hover:shadow-md transition-shadow cursor-pointer border-l-4 border-l-purple-500"
        onClick={handleClick}
      >
        <CardContent className="p-3">
          <div className="flex items-center space-x-3">
            <Avatar className="w-10 h-10 flex-shrink-0">
              <AvatarImage src={profile.avatar_url} />
              <AvatarFallback className="bg-purple-500 text-white">
                {getInitials()}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1 min-w-0">
              <h3 className="font-medium text-sm text-gray-900 truncate">{getDisplayName()}</h3>
              {profile.username && (
                <p className="text-xs text-gray-500 truncate">@{profile.username}</p>
              )}
            </div>

            <User className="w-4 h-4 text-gray-400 flex-shrink-0" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card 
      className="hover:shadow-lg transition-shadow cursor-pointer group"
      onClick={handleClick}
    >
      <CardContent className="p-4">
        <div className="text-center">
          <Avatar className="w-16 h-16 mx-auto mb-3">
            <AvatarImage src={profile.avatar_url} />
            <AvatarFallback className="bg-purple-500 text-white text-lg">
              {getInitials()}
            </AvatarFallback>
          </Avatar>
          
          <h3 className="font-semibold text-gray-900 group-hover:text-purple-600 transition-colors">
            {getDisplayName()}
          </h3>
          
          {profile.username && (
            <p className="text-sm text-gray-500 mt-1">@{profile.username}</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default UserCard;
