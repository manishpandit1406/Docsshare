
import React, { useState } from 'react';
import { FileText, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import DocumentCard from '@/components/DocumentCard';
import type { PDF } from '@/types/pdf';

interface PDFSectionProps {
  pdfs: PDF[];
  onLike: (pdfId: string) => void;
  onViewPDF: (pdf: PDF) => void;
  onViewProfile: (userId: string) => void;
}

const PDFSection: React.FC<PDFSectionProps> = ({ pdfs, onLike, onViewPDF, onViewProfile }) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [activeFilter, setActiveFilter] = useState<'all' | 'popular' | 'recent' | 'trending'>('all');

  const handleDocumentView = (doc: any) => {
    // All documents now navigate to document viewer
    navigate(`/document/${doc.id}`);
  };

  const getFilteredPDFs = () => {
    switch (activeFilter) {
      case 'popular':
        return [...pdfs].sort((a, b) => (b.views_count + b.likes_count) - (a.views_count + a.likes_count));
      case 'recent':
        return [...pdfs].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
      case 'trending':
        // Calculate trending score based on recent engagement
        return [...pdfs].sort((a, b) => {
          const now = new Date();
          const aAge = now.getTime() - new Date(a.created_at).getTime();
          const bAge = now.getTime() - new Date(b.created_at).getTime();
          const aTrending = (a.views_count + a.likes_count * 2) / Math.max(aAge / (1000 * 60 * 60 * 24), 1);
          const bTrending = (b.views_count + b.likes_count * 2) / Math.max(bAge / (1000 * 60 * 60 * 24), 1);
          return bTrending - aTrending;
        });
      default:
        return pdfs;
    }
  };

  const filteredPDFs = getFilteredPDFs();

  return (
    <section className="py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Filter Tabs */}
        <div className="mb-6">
          <Tabs value={activeFilter} onValueChange={(value) => setActiveFilter(value as typeof activeFilter)} className="w-full">
            <TabsList className="grid w-full grid-cols-4 mb-6 bg-white shadow-sm">
              <TabsTrigger 
                value="all" 
                className="flex items-center space-x-2 data-[state=active]:bg-blue-500 data-[state=active]:text-white"
              >
                <Filter className="w-4 h-4" />
                <span>All</span>
              </TabsTrigger>
              <TabsTrigger 
                value="popular" 
                className="flex items-center space-x-2 data-[state=active]:bg-purple-500 data-[state=active]:text-white"
              >
                <span>Popular</span>
              </TabsTrigger>
              <TabsTrigger 
                value="recent" 
                className="flex items-center space-x-2 data-[state=active]:bg-green-500 data-[state=active]:text-white"
              >
                <span>Recent</span>
              </TabsTrigger>
              <TabsTrigger 
                value="trending" 
                className="flex items-center space-x-2 data-[state=active]:bg-orange-500 data-[state=active]:text-white"
              >
                <span>Trending</span>
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {filteredPDFs.length === 0 ? (
          <Card className="p-12 text-center">
            <CardContent>
              <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h4 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                No Documents yet
              </h4>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                Be the first to share a document with the community!
              </p>
              {user ? (
                <Button onClick={() => navigate('/upload')}>
                  Upload First Document
                </Button>
              ) : (
                <Button onClick={() => navigate('/auth')}>
                  Sign In to Upload
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredPDFs.map((pdf) => (
              <DocumentCard
                key={pdf.id}
                document={{
                  ...pdf,
                  file_type: pdf.file_type || 'pdf',
                  mime_type: pdf.mime_type,
                  comments_count: pdf.comments_count || 0
                }}
                onView={handleDocumentView}
                onLike={onLike}
                onViewProfile={onViewProfile}
                showActions={true}
                showEditDelete={user?.id === pdf.user_id}
                compact={false}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default PDFSection;
