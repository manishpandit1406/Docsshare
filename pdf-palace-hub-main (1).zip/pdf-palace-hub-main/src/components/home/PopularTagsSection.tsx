
import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, Clock, Star } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const PopularTagsSection: React.FC = () => {
  const navigate = useNavigate();

  const popularTags = [
    'Education', 'Technology', 'Science', 'Business', 'Design', 'Programming', 'Research', 'Tutorial'
  ];

  const recentTags = [
    'Machine Learning', 'Web Development', 'Data Science', 'UI/UX', 'Mobile Apps', 'Cloud Computing'
  ];

  const trendingTags = [
    'AI', 'React', 'Python', 'JavaScript', 'Node.js', 'Docker', 'Kubernetes', 'DevOps'
  ];

  const handleTagClick = (tag: string) => {
    navigate(`/search?q=${encodeURIComponent(tag)}`);
  };

  return (
    <section className="py-8 bg-white/50 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">
            Discover Content
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Explore popular topics and trending content across our platform
          </p>
        </div>

        <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
          <CardContent className="p-6">
            <Tabs defaultValue="popular" className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-6 bg-gray-100">
                <TabsTrigger 
                  value="popular" 
                  className="flex items-center space-x-2 data-[state=active]:bg-blue-500 data-[state=active]:text-white"
                >
                  <Star className="w-4 h-4" />
                  <span>Popular</span>
                </TabsTrigger>
                <TabsTrigger 
                  value="recent" 
                  className="flex items-center space-x-2 data-[state=active]:bg-green-500 data-[state=active]:text-white"
                >
                  <Clock className="w-4 h-4" />
                  <span>Recent</span>
                </TabsTrigger>
                <TabsTrigger 
                  value="trending" 
                  className="flex items-center space-x-2 data-[state=active]:bg-orange-500 data-[state=active]:text-white"
                >
                  <TrendingUp className="w-4 h-4" />
                  <span>Trending</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="popular" className="space-y-4">
                <div className="flex flex-wrap gap-3">
                  {popularTags.map((tag) => (
                    <Badge
                      key={tag}
                      variant="outline"
                      className="cursor-pointer hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700 transition-all duration-200 text-base px-4 py-2 bg-white shadow-sm"
                      onClick={() => handleTagClick(tag)}
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="recent" className="space-y-4">
                <div className="flex flex-wrap gap-3">
                  {recentTags.map((tag) => (
                    <Badge
                      key={tag}
                      variant="outline"
                      className="cursor-pointer hover:bg-green-50 hover:border-green-300 hover:text-green-700 transition-all duration-200 text-base px-4 py-2 bg-white shadow-sm"
                      onClick={() => handleTagClick(tag)}
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="trending" className="space-y-4">
                <div className="flex flex-wrap gap-3">
                  {trendingTags.map((tag) => (
                    <Badge
                      key={tag}
                      variant="outline"
                      className="cursor-pointer hover:bg-orange-50 hover:border-orange-300 hover:text-orange-700 transition-all duration-200 text-base px-4 py-2 bg-white shadow-sm"
                      onClick={() => handleTagClick(tag)}
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

export default PopularTagsSection;
