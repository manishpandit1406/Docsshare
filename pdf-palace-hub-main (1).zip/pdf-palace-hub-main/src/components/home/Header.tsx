
import React, { useCallback } from 'react';
import { FileText, User, LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import SearchBar from '@/components/SearchBar';

interface HeaderProps {
  onSearch: (query: string) => void;
}

const Header: React.FC<HeaderProps> = ({ onSearch }) => {
  const navigate = useNavigate();
  const { user } = useAuth();

  // Memoize navigation handlers
  const handleExploreClick = useCallback(() => {
    navigate('/explore');
  }, [navigate]);

  const handleUploadClick = useCallback(() => {
    navigate('/upload');
  }, [navigate]);

  const handleDashboardClick = useCallback(() => {
    navigate('/dashboard');
  }, [navigate]);

  const handleAuthClick = useCallback(() => {
    navigate('/auth');
  }, [navigate]);

  return (
    <header className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-b border-gray-200 dark:border-gray-700 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <FileText className="w-8 h-8 text-blue-600" />
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              PDFShare
            </h1>
          </div>

          {/* Compact Search Bar */}
          <div className="flex-1 max-w-sm mx-8">
            <SearchBar 
              onSearch={onSearch} 
              placeholder="Search PDFs or users..." 
              showSuggestions={true} 
              showUserCards={true}
              variant="compact"
            />
          </div>
          
          <nav className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              onClick={handleExploreClick}
              className="text-gray-700 dark:text-gray-200 hover:text-blue-600"
            >
              Explore
            </Button>
            {user ? (
              <>
                <Button 
                  variant="ghost" 
                  onClick={handleUploadClick}
                  className="text-gray-700 dark:text-gray-200 hover:text-blue-600"
                >
                  Upload
                </Button>
                <Button 
                  variant="ghost" 
                  onClick={handleDashboardClick}
                  className="text-gray-700 dark:text-gray-200 hover:text-blue-600"
                >
                  <User className="w-4 h-4 mr-2" />
                  Dashboard
                </Button>
              </>
            ) : (
              <Button 
                onClick={handleAuthClick}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <LogIn className="w-4 h-4 mr-2" />
                Sign In
              </Button>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
