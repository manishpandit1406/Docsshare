
import React from 'react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const CTASection: React.FC = () => {
  const navigate = useNavigate();

  return (
    <section className="py-20 bg-white/50 dark:bg-gray-800/50">
      <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
        <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
          Ready to Share Your Knowledge?
        </h3>
        <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
          Join our community and start sharing your PDF documents today.
        </p>
        <Button 
          size="lg" 
          onClick={() => navigate('/auth')}
          className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3"
        >
          Get Started Now
        </Button>
      </div>
    </section>
  );
};

export default CTASection;
