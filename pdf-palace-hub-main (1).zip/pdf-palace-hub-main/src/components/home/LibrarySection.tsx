
import React from 'react';
import { BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import LibraryCard from '@/components/LibraryCard';
import type { PDFBundle } from '@/hooks/usePDFBundles';

interface LibrarySectionProps {
  libraries: PDFBundle[];
  onViewLibrary: (libraryId: string) => void;
}

const LibrarySection: React.FC<LibrarySectionProps> = ({ libraries, onViewLibrary }) => {
  const navigate = useNavigate();
  const { user } = useAuth();

  const handleLibraryClick = (library: PDFBundle) => {
    navigate(`/library/${library.id}`);
  };

  return (
    <section className="py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
            Libraries
          </h3>
          {user && (
            <Button 
              onClick={() => navigate('/create-library')}
              className="bg-green-600 hover:bg-green-700"
            >
              Create Library
            </Button>
          )}
        </div>

        {libraries.length === 0 ? (
          <Card className="p-12 text-center">
            <CardContent>
              <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h4 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                No Libraries yet
              </h4>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                Create the first library to organize documents!
              </p>
              {user ? (
                <Button onClick={() => navigate('/create-library')}>
                  Create First Library
                </Button>
              ) : (
                <Button onClick={() => navigate('/auth')}>
                  Sign In to Create
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {libraries.map((library) => (
              <LibraryCard
                key={library.id}
                library={library}
                onClick={() => handleLibraryClick(library)}
                showActions={true}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default LibrarySection;
