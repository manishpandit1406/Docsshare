
import React from 'react';
import { Plus, BookOpen, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { formatDistanceToNow } from 'date-fns';
import { BundleItem } from '@/hooks/usePDFBundles';

interface LibraryPDFListProps {
  items: BundleItem[];
  onAddPDFs: () => void;
  onPDFClick: (pdfId: string) => void;
  onRemovePDF: (pdfId: string) => void;
}

const LibraryPDFList: React.FC<LibraryPDFListProps> = ({
  items,
  onAddPDFs,
  onPDFClick,
  onRemovePDF
}) => {
  if (items.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>PDFs in Library</span>
            <span className="text-sm font-normal text-gray-500">0 PDFs</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No PDFs in this library</h3>
            <p className="text-gray-500 mb-4">Add some PDFs to get started!</p>
            <Button onClick={onAddPDFs}>
              <Plus className="w-4 h-4 mr-2" />
              Add PDFs
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>PDFs in Library</span>
          <span className="text-sm font-normal text-gray-500">{items.length} PDFs</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y">
          {items.map((item, index) => (
            <div 
              key={item.id}
              className="p-4 hover:bg-gray-50 cursor-pointer transition-colors group"
              onClick={() => onPDFClick(item.pdf_id)}
            >
              <div className="flex items-start space-x-4">
                {/* Index Number */}
                <div className="flex-shrink-0 w-8 text-center">
                  <span className="text-gray-500">{index + 1}</span>
                </div>
                
                {/* PDF Thumbnail */}
                <div className="flex-shrink-0">
                  <div className="w-24 h-16 bg-gray-100 rounded overflow-hidden">
                    {item.pdf?.thumbnail_url ? (
                      <img 
                        src={item.pdf.thumbnail_url} 
                        alt={item.pdf.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <BookOpen className="w-6 h-6 text-gray-400" />
                      </div>
                    )}
                  </div>
                </div>
                
                {/* PDF Info */}
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-gray-900 line-clamp-2 group-hover:text-blue-600">
                    {item.pdf?.title || 'Untitled PDF'}
                  </h4>
                  {item.pdf?.description && (
                    <p className="text-sm text-gray-600 line-clamp-1 mt-1">
                      {item.pdf.description}
                    </p>
                  )}
                  <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                    <span className="flex items-center space-x-1">
                      <Clock className="w-3 h-3" />
                      <span>Added {formatDistanceToNow(new Date(item.added_at), { addSuffix: true })}</span>
                    </span>
                  </div>
                </div>
                
                {/* Remove Button */}
                <div className="flex-shrink-0">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="opacity-0 group-hover:opacity-100 transition-opacity text-red-600 hover:text-red-800"
                    onClick={(e) => {
                      e.stopPropagation();
                      onRemovePDF(item.pdf_id);
                    }}
                  >
                    Remove
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default LibraryPDFList;
