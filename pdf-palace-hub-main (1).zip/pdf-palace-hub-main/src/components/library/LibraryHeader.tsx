
import React from 'react';
import { BookOpen, Share2, MoreVertical, Edit, ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { formatDistanceToNow } from 'date-fns';
import { PDFBundle } from '@/hooks/usePDFBundles';

interface LibraryHeaderProps {
  library: PDFBundle;
  itemCount: number;
  onAddPDFs: () => void;
  onShare: () => void;
  onEditLibrary: () => void;
  onUpdateImage: () => void;
}

const LibraryHeader: React.FC<LibraryHeaderProps> = ({
  library,
  itemCount,
  onAddPDFs,
  onShare,
  onEditLibrary,
  onUpdateImage
}) => {
  return (
    <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg p-8">
      <div className="flex items-start space-x-6">
        {/* Library Thumbnail */}
        <div className="flex-shrink-0">
          <div className="w-48 h-32 bg-white/20 rounded-lg flex items-center justify-center relative group cursor-pointer" onClick={onUpdateImage}>
            <BookOpen className="w-16 h-16 text-white/80" />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
              <ImageIcon className="w-8 h-8 text-white" />
            </div>
          </div>
        </div>
        
        {/* Library Info */}
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
              Library
            </Badge>
            {library.is_public && (
              <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                Public
              </Badge>
            )}
          </div>
          
          <h1 className="text-4xl font-bold mb-2">{library.name}</h1>
          
          {library.description && (
            <p className="text-white/90 mb-4 text-lg">{library.description}</p>
          )}
          
          <div className="flex items-center space-x-4 text-white/80">
            <span>{itemCount} PDFs</span>
            <span>•</span>
            <span>Created {formatDistanceToNow(new Date(library.created_at), { addSuffix: true })}</span>
          </div>
        </div>
      </div>
      
      {/* Action Buttons */}
      <div className="flex items-center space-x-4 mt-6">
        <Button 
          onClick={onAddPDFs}
          className="bg-white text-gray-900 hover:bg-gray-100"
        >
          <BookOpen className="w-4 h-4 mr-2" />
          Add PDFs
        </Button>
        
        <Button 
          onClick={onShare}
          variant="outline" 
          className="border-white/30 text-white hover:bg-white/10"
        >
          <Share2 className="w-4 h-4 mr-2" />
          Share
        </Button>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="border-white/30 text-white hover:bg-white/10">
              <MoreVertical className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={onEditLibrary}>
              <Edit className="w-4 h-4 mr-2" />
              Edit Library
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onUpdateImage}>
              <ImageIcon className="w-4 h-4 mr-2" />
              Update Image
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
};

export default LibraryHeader;
