
import React from 'react';
import { Bookmark, BookmarkCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useWishlist } from '@/hooks/useWishlist';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

interface WishlistButtonProps {
  pdfId: string;
  size?: "sm" | "default" | "lg";
}

const WishlistButton: React.FC<WishlistButtonProps> = ({
  pdfId,
  size = "sm"
}) => {
  const { user } = useAuth();
  const { isInWishlist, addToWishlist, removeFromWishlist, loading } = useWishlist();

  const handleToggle = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to add PDFs to your wishlist",
        variant: "destructive"
      });
      return;
    }

    if (isInWishlist(pdfId)) {
      await removeFromWishlist(pdfId);
    } else {
      await addToWishlist(pdfId);
    }
  };

  const inWishlist = isInWishlist(pdfId);

  return (
    <Button
      variant="outline"
      size={size}
      onClick={handleToggle}
      disabled={loading}
      className={`flex items-center space-x-1 ${inWishlist ? 'text-blue-600 border-blue-600' : ''}`}
    >
      {inWishlist ? (
        <BookmarkCheck className="w-4 h-4" />
      ) : (
        <Bookmark className="w-4 h-4" />
      )}
      <span className="text-xs">
        {inWishlist ? 'Saved' : 'Save'}
      </span>
    </Button>
  );
};

export default WishlistButton;
