
import React, { useState } from 'react';
import { Library, Plus, Search, BookOpen, ArrowLeft } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { usePDFBundles } from '@/hooks/usePDFBundles';
import PDFBundleDialog from '@/components/PDFBundleDialog';
import LibraryCard from '@/components/LibraryCard';
import { useNavigate } from 'react-router-dom';

interface LibrariesModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  isOwnProfile: boolean;
}

const LibrariesModal: React.FC<LibrariesModalProps> = ({ 
  isOpen, 
  onClose, 
  userId, 
  isOwnProfile 
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const { bundles, isLoading, deleteBundle } = usePDFBundles();
  const navigate = useNavigate();

  // Only show libraries for the profile owner
  const userBundles = isOwnProfile ? bundles : [];

  const filteredBundles = userBundles.filter(bundle => 
    bundle.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (bundle.description?.toLowerCase().includes(searchQuery.toLowerCase()) ?? false)
  );

  const handleDeleteBundle = (bundleId: string, bundleName: string) => {
    if (window.confirm(`Are you sure you want to delete "${bundleName}"?`)) {
      deleteBundle(bundleId);
    }
  };

  const handleLibraryClick = (bundleId: string) => {
    onClose();
    navigate(`/library/${bundleId}`);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Library className="w-5 h-5" />
            <span>
              {isOwnProfile ? 'My Libraries' : 'User Libraries'}
            </span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Only show for own profile */}
          {isOwnProfile && (
            <>
              {/* Search and Create */}
              <div className="flex items-center space-x-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                  <Input
                    placeholder="Search libraries by name or description..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <PDFBundleDialog 
                  trigger={
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Create Library
                    </Button>
                  }
                />
              </div>

              {/* Libraries Grid */}
              <div className="max-h-[60vh] overflow-y-auto">
                {isLoading ? (
                  <div className="flex items-center justify-center py-12">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
                  </div>
                ) : filteredBundles.length === 0 ? (
                  <div className="text-center py-12">
                    <Library className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      {searchQuery ? 'No libraries found' : 'No libraries yet'}
                    </h3>
                    <p className="text-gray-500">
                      {searchQuery 
                        ? 'Try adjusting your search terms' 
                        : 'Create your first library to organize your PDFs'
                      }
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {filteredBundles.map((bundle) => (
                      <LibraryCard 
                        key={bundle.id}
                        library={bundle}
                        onClick={() => handleLibraryClick(bundle.id)}
                        showActions={true}
                        onDelete={() => handleDeleteBundle(bundle.id, bundle.name)}
                      />
                    ))}
                  </div>
                )}
              </div>
            </>
          )}

          {/* Message for non-owners */}
          {!isOwnProfile && (
            <div className="text-center py-12">
              <Library className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Libraries are private
              </h3>
              <p className="text-gray-500">
                Only the user can view their own libraries
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default LibrariesModal;
