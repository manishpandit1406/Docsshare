
import React from 'react';
import { User, MapPin, Link as LinkIcon } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';

interface UserProfile {
  id: string;
  full_name?: string;
  username?: string;
  avatar_url?: string;
  bio?: string;
  website?: string;
  subscribers_count?: number;
}

interface UserStripeCardProps {
  profile: UserProfile;
  onClick: () => void;
  compact?: boolean;
}

const UserStripeCard: React.FC<UserStripeCardProps> = ({ 
  profile, 
  onClick, 
  compact = false 
}) => {
  const getUserDisplayName = () => {
    if (profile.full_name) return profile.full_name;
    if (profile.username) return profile.username;
    return 'Anonymous User';
  };

  const getUserInitials = () => {
    const displayName = getUserDisplayName();
    if (displayName === 'Anonymous User') return 'A';
    return displayName.split(' ').map(name => name[0]).join('').slice(0, 2).toUpperCase();
  };

  if (compact) {
    return (
      <Card 
        className="hover:shadow-md transition-shadow cursor-pointer border-l-4 border-l-green-500"
        onClick={onClick}
      >
        <CardContent className="p-3">
          <div className="flex items-center space-x-3">
            <Avatar className="w-10 h-10 flex-shrink-0">
              <AvatarImage src={profile.avatar_url} />
              <AvatarFallback className="bg-green-500 text-white text-sm">
                {getUserInitials()}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1 min-w-0">
              <h3 className="font-medium text-sm text-gray-900 truncate">
                {getUserDisplayName()}
              </h3>
              {profile.username && profile.username !== getUserDisplayName() && (
                <p className="text-xs text-gray-500 truncate">@{profile.username}</p>
              )}
              {profile.bio && (
                <p className="text-xs text-gray-600 line-clamp-1 mt-1">{profile.bio}</p>
              )}
              <div className="flex items-center space-x-2 mt-1">
                <Badge variant="outline" className="text-xs">
                  <User className="w-3 h-3 mr-1" />
                  {profile.subscribers_count || 0} followers
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card 
      className="hover:shadow-lg transition-shadow cursor-pointer group"
      onClick={onClick}
    >
      <CardContent className="p-6">
        <div className="text-center">
          <Avatar className="w-20 h-20 mx-auto mb-4">
            <AvatarImage src={profile.avatar_url} />
            <AvatarFallback className="bg-green-500 text-white text-xl">
              {getUserInitials()}
            </AvatarFallback>
          </Avatar>
          
          <h3 className="font-semibold text-lg text-gray-900 mb-1 group-hover:text-green-600 transition-colors">
            {getUserDisplayName()}
          </h3>
          
          {profile.username && profile.username !== getUserDisplayName() && (
            <p className="text-sm text-gray-500 mb-2">@{profile.username}</p>
          )}
          
          {profile.bio && (
            <p className="text-sm text-gray-600 line-clamp-3 mb-4">{profile.bio}</p>
          )}
          
          <div className="flex items-center justify-center space-x-4 text-sm text-gray-500 mb-4">
            <div className="flex items-center">
              <User className="w-4 h-4 mr-1" />
              <span>{profile.subscribers_count || 0}</span>
            </div>
            {profile.website && (
              <div className="flex items-center">
                <LinkIcon className="w-4 h-4 mr-1" />
                <span>Website</span>
              </div>
            )}
          </div>
          
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            User Profile
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
};

export default UserStripeCard;
