
import React, { useState } from 'react';
import { X, Download, RotateCw, ZoomIn, ZoomOut, Maximize2, Minimize2, FileText, File } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { Document } from '@/types/document';

interface FullscreenDocumentViewerProps {
  document: Document;
  isOpen: boolean;
  onClose: () => void;
}

const FullscreenDocumentViewer: React.FC<FullscreenDocumentViewerProps> = ({
  document,
  isOpen,
  onClose
}) => {
  const [zoom, setZoom] = useState(100);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);

  const handleZoomIn = () => {
    setZoom(prev => Math.min(200, prev + 25));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(50, prev - 25));
  };

  const handleDownload = () => {
    const link = window.document.createElement('a');
    link.href = document.file_url;
    link.download = document.file_name || document.title;
    window.document.body.appendChild(link);
    link.click();
    window.document.body.removeChild(link);
  };

  const toggleFullscreen = () => {
    if (!window.document.fullscreenElement) {
      window.document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      window.document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const getFileIcon = () => {
    const fileType = document.file_type?.toLowerCase();
    
    switch (fileType) {
      case 'pdf':
        return <FileText className="w-8 h-8 text-red-600" />;
      case 'doc':
      case 'docx':
        return <FileText className="w-8 h-8 text-blue-600" />;
      case 'xls':
      case 'xlsx':
        return <File className="w-8 h-8 text-green-600" />;
      case 'ppt':
      case 'pptx':
        return <File className="w-8 h-8 text-orange-600" />;
      case 'txt':
      case 'rtf':
      case 'odt':
        return <File className="w-8 h-8 text-gray-600" />;
      default:
        return <FileText className="w-8 h-8" />;
    }
  };

  const renderDocumentViewer = () => {
    const fileType = document.file_type?.toLowerCase();

    // For PDF files
    if (fileType === 'pdf') {
      return (
        <iframe
          src={`${document.file_url}#toolbar=0&navpanes=0&scrollbar=1&zoom=${zoom}`}
          className="w-full h-full"
          title={document.title}
          style={{ transform: `scale(${zoom / 100})`, transformOrigin: 'top left' }}
        />
      );
    }

    // For Office documents
    if (['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'].includes(fileType || '')) {
      const officeViewerUrl = `https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(document.file_url)}`;
      return (
        <iframe
          src={officeViewerUrl}
          className="w-full h-full"
          title={document.title}
          style={{ transform: `scale(${zoom / 100})`, transformOrigin: 'top left' }}
        />
      );
    }

    // For other document types
    return (
      <div className="w-full h-full flex items-center justify-center bg-gray-900 text-white">
        <div className="text-center">
          {getFileIcon()}
          <h3 className="text-2xl font-semibold mt-4 mb-2">{document.title}</h3>
          <p className="text-gray-300 mb-6">{fileType?.toUpperCase()} Document</p>
          <Button onClick={handleDownload} variant="outline" className="bg-white text-black">
            <Download className="w-4 h-4 mr-2" />
            Download to View
          </Button>
        </div>
      </div>
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black">
      {/* Header Controls */}
      {showControls && (
        <div className="absolute top-0 left-0 right-0 z-10 bg-black/60 backdrop-blur-sm p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              {getFileIcon()}
              <div className="text-white">
                <h2 className="text-lg font-semibold">{document.title}</h2>
                <p className="text-sm text-gray-300">
                  {document.file_type?.toUpperCase()} • {zoom}% zoom
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              {document.file_type?.toLowerCase() === 'pdf' && (
                <>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleZoomOut}
                    className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
                  >
                    <ZoomOut className="w-4 h-4" />
                  </Button>

                  <span className="text-white text-sm min-w-[60px] text-center">
                    {zoom}%
                  </span>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleZoomIn}
                    className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
                  >
                    <ZoomIn className="w-4 h-4" />
                  </Button>
                </>
              )}

              <Button
                variant="outline"
                size="sm"
                onClick={toggleFullscreen}
                className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
              >
                {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={handleDownload}
                className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
              >
                <Download className="w-4 h-4" />
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={onClose}
                className="bg-red-500/20 backdrop-blur-sm border-red-400/30 text-white hover:bg-red-500/30"
              >
                <X className="w-4 h-4 mr-1" />
                Close
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Document Content */}
      <div className="w-full h-full pt-20">
        {renderDocumentViewer()}
      </div>

      {/* Toggle Controls Button */}
      {!showControls && (
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowControls(true)}
          className="absolute top-4 right-4 bg-black/60 backdrop-blur-sm border-white/20 text-white hover:bg-black/80"
        >
          Show Controls
        </Button>
      )}

      {/* Hide Controls Button */}
      {showControls && (
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setShowControls(false)}
          className="absolute top-4 right-4 text-white/60 hover:text-white hover:bg-white/10"
        >
          Hide
        </Button>
      )}
    </div>
  );
};

export default FullscreenDocumentViewer;
