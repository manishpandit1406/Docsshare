
import React from 'react';
import { FileText, Library, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

export type ProfileTabType = 'pdfs' | 'libraries' | 'about';

interface ProfileTabsProps {
  activeTab: ProfileTabType;
  onTabChange: (tab: ProfileTabType) => void;
  className?: string;
}

const ProfileTabs: React.FC<ProfileTabsProps> = ({ 
  activeTab, 
  onTabChange, 
  className 
}) => {
  const tabs = [
    {
      id: 'pdfs' as ProfileTabType,
      label: 'PDFs'
    },
    {
      id: 'libraries' as ProfileTabType,
      label: 'Libraries'
    },
    {
      id: 'about' as ProfileTabType,
      label: 'About'
    }
  ];

  return (
    <div className={cn("mb-6", className)}>
      <div className="flex rounded-lg bg-gray-100 p-1 max-w-md">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          
          return (
            <Button
              key={tab.id}
              variant="ghost"
              className={cn(
                "flex-1 rounded-md h-10 text-sm font-medium transition-all duration-200",
                isActive 
                  ? "bg-blue-500 text-white shadow-sm hover:bg-blue-600" 
                  : "text-gray-600 hover:text-gray-900 hover:bg-gray-200"
              )}
              onClick={() => onTabChange(tab.id)}
            >
              {tab.label}
            </Button>
          );
        })}
      </div>
    </div>
  );
};

export default ProfileTabs;
