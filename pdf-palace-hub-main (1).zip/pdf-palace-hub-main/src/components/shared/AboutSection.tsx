
import React from 'react';
import { Calendar, Globe, User } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';

interface Profile {
  id: string;
  full_name?: string;
  username?: string;
  bio?: string;
  avatar_url?: string;
  cover_image_url?: string;
  created_at: string;
  website?: string;
  phone?: string;
  role?: string;
  status?: string;
  subscribers_count?: number;
  email_verified?: boolean;
  last_login?: string;
  login_attempts?: number;
  locked_until?: string;
  updated_at?: string;
}

interface AboutSectionProps {
  profile: Profile;
  isOwnProfile?: boolean;
  totalPDFs?: number;
  totalViews?: number;
  totalLikes?: number;
  subscribersCount?: number;
}

const AboutSection: React.FC<AboutSectionProps> = ({
  profile,
  isOwnProfile = false,
  totalPDFs = 0,
  totalViews = 0,
  totalLikes = 0,
  subscribersCount = 0
}) => {
  const joinDate = new Date(profile.created_at).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const stats = [
    { label: 'PDFs Published', value: totalPDFs, color: 'text-blue-600' },
    { label: 'Total Views', value: totalViews, color: 'text-green-600' },
    { label: 'Total Likes', value: totalLikes, color: 'text-red-600' },
    { label: 'Subscribers', value: subscribersCount, color: 'text-purple-600' }
  ];

  return (
    <div className="space-y-6">
      {/* Bio Section */}
      {(profile.bio || isOwnProfile) && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <User className="h-5 w-5" />
              <span>About</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {profile.bio ? (
              <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">
                {profile.bio}
              </p>
            ) : isOwnProfile ? (
              <p className="text-muted-foreground italic">
                Add a bio to tell others about yourself...
              </p>
            ) : (
              <p className="text-muted-foreground italic">
                This user hasn't added a bio yet.
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Statistics */}
      <Card>
        <CardHeader>
          <CardTitle>Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className={`text-2xl font-bold ${stat.color}`}>
                  {stat.value.toLocaleString()}
                </div>
                <div className="text-sm text-muted-foreground">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Basic Information */}
      <Card>
        <CardHeader>
          <CardTitle>Basic Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex items-center space-x-3">
              <User className="h-4 w-4 text-muted-foreground flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-foreground">
                  Full Name
                </div>
                <div className="text-sm text-muted-foreground">
                  {profile.full_name || 'Not provided'}
                </div>
              </div>
            </div>
            <Separator className="mt-4" />
          </div>

          <div>
            <div className="flex items-center space-x-3">
              <User className="h-4 w-4 text-muted-foreground flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-foreground">
                  Username
                </div>
                <div className="text-sm text-muted-foreground">
                  {profile.username ? `@${profile.username}` : 'Not set'}
                </div>
              </div>
            </div>
            <Separator className="mt-4" />
          </div>

          <div>
            <div className="flex items-center space-x-3">
              <Calendar className="h-4 w-4 text-muted-foreground flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-foreground">
                  Joined
                </div>
                <div className="text-sm text-muted-foreground">
                  {joinDate}
                </div>
              </div>
            </div>
            {profile.website && (
              <>
                <Separator className="mt-4" />
                <div className="flex items-center space-x-3 mt-4">
                  <Globe className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-foreground">
                      Website
                    </div>
                    <div className="text-sm text-muted-foreground">
                      <a 
                        href={profile.website.startsWith('http') ? profile.website : `https://${profile.website}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:underline"
                      >
                        {profile.website}
                      </a>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AboutSection;
