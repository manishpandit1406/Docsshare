
import React from 'react';
import { MoreHorizontal, Lock, Globe, BookOpen, Share2, Edit, Trash2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import type { PDFBundle } from '@/hooks/usePDFBundles';

interface LibraryCardProps {
  library: PDFBundle;
  onClick?: () => void;
  onEdit?: () => void;
  onDelete?: () => void;
  onShare?: () => void;
  showActions?: boolean;
}

const LibraryCard: React.FC<LibraryCardProps> = ({
  library,
  onClick,
  onEdit,
  onDelete,
  onShare,
  showActions = true
}) => {
  const { user } = useAuth();
  const isOwner = user?.id === library.user_id;
  const canView = library.is_public || isOwner;

  const handleCardClick = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button, [role="button"]')) {
      return;
    }
    
    if (!canView) {
      toast({
        title: "Access Denied",
        description: "This library is private",
        variant: "destructive"
      });
      return;
    }
    
    if (onClick) {
      onClick();
    }
  };

  const handleShare = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onShare) {
      onShare();
    } else {
      const shareUrl = `${window.location.origin}/library/${library.id}`;
      try {
        await navigator.clipboard.writeText(shareUrl);
        toast({
          title: "Link copied",
          description: "Library link has been copied to clipboard"
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to copy link",
          variant: "destructive"
        });
      }
    }
  };

  const handleEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onEdit) {
      onEdit();
    }
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onDelete && window.confirm('Are you sure you want to delete this library?')) {
      onDelete();
    }
  };

  return (
    <Card 
      className={`hover:shadow-md transition-shadow cursor-pointer border-l-4 ${
        library.is_public ? 'border-l-green-500' : 'border-l-orange-500'
      } ${!canView ? 'opacity-60' : ''}`}
      onClick={handleCardClick}
    >
      <CardContent className="p-3">
        <div className="flex items-center space-x-3">
          {/* Library Thumbnail */}
          <div className="w-16 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden">
            {library.cover_image_url ? (
              <img 
                src={library.cover_image_url} 
                alt={library.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <BookOpen className="w-6 h-6 text-blue-600" />
            )}
          </div>
          
          {/* Library Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-2 mb-1">
              <h3 className="font-medium text-sm text-gray-900 truncate">{library.name}</h3>
              {library.is_public ? (
                <Globe className="w-3 h-3 text-green-500 flex-shrink-0" />
              ) : (
                <Lock className="w-3 h-3 text-orange-500 flex-shrink-0" />
              )}
            </div>
            
            {library.description && (
              <p className="text-xs text-gray-500 truncate mb-1">{library.description}</p>
            )}
            
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="text-xs">
                {library.pdf_count || 0} documents
              </Badge>
              <span className="text-xs text-gray-400">
                {new Date(library.created_at).toLocaleDateString()}
              </span>
            </div>
          </div>

          {/* Actions */}
          {showActions && canView && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                  <MoreHorizontal className="w-3 h-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={handleShare}>
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </DropdownMenuItem>
                {isOwner && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleEdit}>
                      <Edit className="w-4 h-4 mr-2" />
                      Edit
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={handleDelete} className="text-red-600">
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default LibraryCard;
