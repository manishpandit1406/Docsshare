
import React, { useState, useEffect } from 'react';
import { X, User } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { toast } from '@/hooks/use-toast';
import { useSubscriptions } from '@/hooks/useSubscriptions';

interface SubscriptionsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const SubscriptionsModal: React.FC<SubscriptionsModalProps> = ({ isOpen, onClose }) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { subscriptions, subscribers, loading, unsubscribe, refetch } = useSubscriptions();

  useEffect(() => {
    if (isOpen && user) {
      refetch();
    }
  }, [isOpen, user, refetch]);

  const handleViewProfile = (userId: string) => {
    navigate(`/profile/${userId}`);
    onClose();
  };

  const handleUnsubscribe = async (userId: string, userName: string) => {
    try {
      const success = await unsubscribe(userId);
      if (success) {
        toast({
          title: "Unsubscribed",
          description: `You unsubscribed from ${userName}`,
        });
      }
    } catch (error) {
      console.error('Error unsubscribing:', error);
      toast({
        title: "Error",
        description: "Failed to unsubscribe. Please try again.",
        variant: "destructive"
      });
    }
  };

  const getUserDisplayName = (user: any) => {
    if (user.full_name) return user.full_name;
    if (user.username) return user.username;
    return 'Anonymous User';
  };

  const getUserInitials = (user: any) => {
    const displayName = getUserDisplayName(user);
    if (displayName === 'Anonymous User') return 'A';
    return displayName.split(' ').map(name => name[0]).join('').slice(0, 2).toUpperCase();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <User className="w-5 h-5" />
            <span>Your Subscriptions ({subscriptions.length})</span>
          </DialogTitle>
        </DialogHeader>

        <div className="mt-4">
          {loading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Skeleton className="w-12 h-12 rounded-full" />
                      <div className="flex-1">
                        <Skeleton className="h-4 w-32 mb-2" />
                        <Skeleton className="h-3 w-20" />
                      </div>
                      <Skeleton className="h-8 w-16" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : subscriptions.length === 0 ? (
            <div className="text-center py-12">
              <User className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No subscriptions yet</h3>
              <p className="text-gray-600 mb-4">
                Start following users to see their latest PDFs and updates!
              </p>
              <Button onClick={() => { navigate('/explore'); onClose(); }}>
                Explore Users
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {subscriptions.map((subscribedUser) => (
                <Card key={subscribedUser.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={subscribedUser.avatar_url || undefined} />
                          <AvatarFallback className="bg-blue-500 text-white">
                            {getUserInitials(subscribedUser)}
                          </AvatarFallback>
                        </Avatar>
                        
                        <div>
                          <h4 className="font-semibold">
                            {getUserDisplayName(subscribedUser)}
                          </h4>
                          
                          {subscribedUser.username && subscribedUser.full_name && (
                            <p className="text-sm text-gray-500">@{subscribedUser.username}</p>
                          )}
                          
                          {subscribedUser.pdf_count !== undefined && (
                            <p className="text-xs text-gray-400">{subscribedUser.pdf_count} PDFs</p>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleViewProfile(subscribedUser.id)}
                        >
                          View Profile
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleUnsubscribe(subscribedUser.id, getUserDisplayName(subscribedUser))}
                          className="text-red-600 hover:text-red-700"
                        >
                          Unsubscribe
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default SubscriptionsModal;
