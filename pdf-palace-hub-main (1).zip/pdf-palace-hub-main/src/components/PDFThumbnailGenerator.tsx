
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Image, Upload } from 'lucide-react';

interface PDFThumbnailGeneratorProps {
  file: File;
  onThumbnailGenerated: (thumbnail: string) => void;
  onCustomThumbnail: (file: File) => void;
}

const PDFThumbnailGenerator: React.FC<PDFThumbnailGeneratorProps> = ({
  file,
  onThumbnailGenerated,
  onCustomThumbnail
}) => {
  const [generatedThumbnail, setGeneratedThumbnail] = useState<string | null>(null);
  const [customThumbnail, setCustomThumbnail] = useState<File | null>(null);

  useEffect(() => {
    generateThumbnailFromPDF();
  }, [file]);

  const generateThumbnailFromPDF = async () => {
    try {
      // Simple PDF thumbnail generation using canvas
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = 200;
      canvas.height = 280;
      
      if (ctx) {
        ctx.fillStyle = '#f3f4f6';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#374151';
        ctx.font = '16px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('PDF', canvas.width / 2, canvas.height / 2);
        ctx.fillText('Preview', canvas.width / 2, canvas.height / 2 + 20);
        
        const thumbnail = canvas.toDataURL('image/jpeg', 0.8);
        setGeneratedThumbnail(thumbnail);
        onThumbnailGenerated(thumbnail);
      }
    } catch (error) {
      console.error('Error generating thumbnail:', error);
    }
  };

  const handleCustomThumbnailUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      setCustomThumbnail(file);
      onCustomThumbnail(file);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-4">
        {generatedThumbnail && (
          <div className="flex-1">
            <label className="block text-sm font-medium mb-2">Generated Thumbnail</label>
            <img 
              src={generatedThumbnail} 
              alt="Generated thumbnail" 
              className="w-24 h-32 object-cover rounded border"
            />
          </div>
        )}
        
        <div className="flex-1">
          <label className="block text-sm font-medium mb-2">Custom Thumbnail (Optional)</label>
          <input
            type="file"
            accept="image/*"
            onChange={handleCustomThumbnailUpload}
            className="hidden"
            id="custom-thumbnail"
          />
          <Button
            type="button"
            variant="outline"
            onClick={() => document.getElementById('custom-thumbnail')?.click()}
            className="w-full"
          >
            <Upload className="w-4 h-4 mr-2" />
            Upload Custom
          </Button>
          {customThumbnail && (
            <p className="text-sm text-green-600 mt-1">{customThumbnail.name}</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default PDFThumbnailGenerator;
