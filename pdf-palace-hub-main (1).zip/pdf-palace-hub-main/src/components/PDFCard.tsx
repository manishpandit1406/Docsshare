import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Heart, Eye, MessageSquare, Edit3 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { PDF } from '@/types/pdf';
import { cn } from '@/lib/utils';

interface PDFCardProps {
  pdf: PDF;
  onView?: (pdf: PDF) => void;
  showWishlistButton?: boolean;
}

const PDFCard: React.FC<PDFCardProps> = ({ pdf, onView, showWishlistButton = true }) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const [isLiked, setIsLiked] = useState(false);

  const handleView = () => {
    if (onView) {
      onView(pdf);
    } else {
      navigate(`/pdf/${pdf.id}`);
    }
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsLiked(!isLiked);
    toast({
      title: "Wishlist Updated",
      description: isLiked ? "Removed from wishlist." : "Added to wishlist.",
    })
  };

  const handleEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigate(`/document-editor/${pdf.id}`);
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
      {pdf.thumbnail_url ? (
        <img
          src={pdf.thumbnail_url}
          alt={pdf.title}
          className="w-full h-48 object-cover cursor-pointer"
          onClick={handleView}
        />
      ) : (
        <div className="w-full h-48 bg-gray-100 flex items-center justify-center cursor-pointer" onClick={handleView}>
          <span className="text-gray-500">No Thumbnail</span>
        </div>
      )}
      
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-900 mb-2 cursor-pointer hover:text-blue-600 transition-colors duration-200" onClick={handleView}>
          {pdf.title}
        </h3>
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{pdf.description}</p>
        
        {pdf.profiles && (
          <div className="flex items-center space-x-2 mb-2">
            <img
              src={pdf.profiles.avatar_url || '/default-profile.png'}
              alt={pdf.profiles.full_name || 'User'}
              className="w-8 h-8 rounded-full object-cover"
            />
            <div className="text-sm text-gray-700">
              {pdf.profiles.full_name || pdf.profiles.username || 'Unknown User'}
            </div>
          </div>
        )}
        
        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <div className="flex items-center space-x-4 text-sm text-gray-600">
            <div className="flex items-center space-x-1">
              <Eye className="h-4 w-4" />
              <span>{pdf.views_count || 0}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Heart className={cn("h-4 w-4", isLiked ? "text-red-500" : "")} />
              <span>{pdf.likes_count || 0}</span>
            </div>
            <div className="flex items-center space-x-1">
              <MessageSquare className="h-4 w-4" />
              <span>{pdf.comments_count || 0}</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            {user && user.id === pdf.user_id && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleEdit}
                className="flex items-center space-x-1"
              >
                <Edit3 className="h-3 w-3" />
                <span>Edit</span>
              </Button>
            )}
            
            {showWishlistButton && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleWishlist}
                className="px-3 py-2"
              >
                <Heart className={cn("h-4 w-4", isLiked ? "text-red-500" : "")} />
              </Button>
            )}
            <Button size="sm" onClick={handleView}>View</Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PDFCard;
