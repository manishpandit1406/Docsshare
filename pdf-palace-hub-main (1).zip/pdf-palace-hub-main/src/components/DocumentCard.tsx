import React from 'react';
import { useNavigate } from 'react-router-dom';
import { MoreHorizontal, Heart, MessageCircle, Eye, Download, Trash2, User, Edit, FileText, File, FileSpreadsheet, FileImage, Archive } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface DocumentFile {
  id: string;
  title: string;
  description?: string;
  file_type: string;
  mime_type?: string;
  file_url: string;
  thumbnail_url?: string;
  user_id: string;
  views_count: number;
  likes_count: number;
  comments_count: number;
  tags?: string[];
  created_at: string;
  profiles?: {
    full_name?: string;
    username?: string;
    avatar_url?: string;
  };
}

interface DocumentCardProps {
  document: DocumentFile;
  onDelete?: (id: string) => void;
  onViewProfile?: (userId: string) => void;
  onView?: (doc: DocumentFile) => void;
  onEdit?: (doc: DocumentFile) => void;
  onLike?: (docId: string) => void;
  showActions?: boolean;
  showEditDelete?: boolean;
  compact?: boolean;
}

const DocumentCard: React.FC<DocumentCardProps> = ({ 
  document: doc, 
  onDelete, 
  onViewProfile,
  onView,
  onEdit,
  onLike,
  showActions = true,
  showEditDelete = false,
  compact = false 
}) => {
  const navigate = useNavigate();

  const getFileIcon = () => {
    const type = doc.file_type?.toLowerCase();
    switch (type) {
      case 'pdf':
        return <FileText className="w-6 h-6 text-red-500" />;
      case 'doc':
      case 'docx':
        return <FileText className="w-6 h-6 text-blue-500" />;
      case 'xls':
      case 'xlsx':
        return <FileSpreadsheet className="w-6 h-6 text-green-500" />;
      case 'ppt':
      case 'pptx':
        return <FileImage className="w-6 h-6 text-orange-500" />;
      case 'txt':
      case 'rtf':
        return <FileText className="w-6 h-6 text-gray-500" />;
      case 'odt':
        return <FileText className="w-6 h-6 text-purple-500" />;
      default:
        return <File className="w-6 h-6 text-gray-500" />;
    }
  };

  const getFileTypeColor = () => {
    const type = doc.file_type?.toLowerCase();
    switch (type) {
      case 'pdf':
        return 'from-red-50 to-red-100';
      case 'doc':
      case 'docx':
        return 'from-blue-50 to-blue-100';
      case 'xls':
      case 'xlsx':
        return 'from-green-50 to-green-100';
      case 'ppt':
      case 'pptx':
        return 'from-orange-50 to-orange-100';
      case 'txt':
      case 'rtf':
        return 'from-gray-50 to-gray-100';
      case 'odt':
        return 'from-purple-50 to-purple-100';
      default:
        return 'from-gray-50 to-gray-100';
    }
  };

  const handleCardClick = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button, [role="button"]')) {
      return;
    }
    
    if (onView) {
      onView(doc);
    } else {
      // All files now navigate to document viewer
      navigate(`/document/${doc.id}`, { 
        state: { from: window.location.pathname } 
      });
    }
  };

  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    const link = window.document.createElement('a');
    link.href = doc.file_url;
    link.download = doc.title;
    window.document.body.appendChild(link);
    link.click();
    window.document.body.removeChild(link);
  };

  const handleUserClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onViewProfile && doc.user_id) {
      onViewProfile(doc.user_id);
    } else {
      navigate(`/profile/${doc.user_id}`);
    }
  };

  const getUserDisplayName = () => {
    if (doc.profiles?.full_name) return doc.profiles.full_name;
    if (doc.profiles?.username) return doc.profiles.username;
    return 'Anonymous User';
  };

  const getUserInitials = () => {
    const displayName = getUserDisplayName();
    if (displayName === 'Anonymous User') return 'A';
    return displayName.split(' ').map(name => name[0]).join('').slice(0, 2).toUpperCase();
  };

  if (compact) {
    return (
      <Card 
        className="hover:shadow-lg transition-all duration-200 cursor-pointer group border-0 bg-white shadow-sm hover:scale-105"
        onClick={handleCardClick}
      >
        <CardContent className="p-3">
          {/* Document Preview */}
          <div className={`aspect-[3/4] bg-gradient-to-br ${getFileTypeColor()} rounded-lg mb-3 flex items-center justify-center relative overflow-hidden`}>
            {doc.thumbnail_url ? (
              <img 
                src={doc.thumbnail_url} 
                alt={doc.title}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="text-center">
                <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center mx-auto mb-2 shadow-sm">
                  {getFileIcon()}
                </div>
                <Badge variant="outline" className="bg-white/80 text-xs">
                  {doc.file_type?.toUpperCase()}
                </Badge>
              </div>
            )}
            
            {showActions && (
              <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="secondary" size="sm" className="h-6 w-6 p-0 bg-white/90 hover:bg-white">
                      <MoreHorizontal className="w-3 h-3" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={handleDownload}>
                      <Download className="w-4 h-4 mr-2" />
                      Download
                    </DropdownMenuItem>
                    {showEditDelete && onEdit && (
                      <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onEdit(doc); }}>
                        <Edit className="w-4 h-4 mr-2" />
                        Edit
                      </DropdownMenuItem>
                    )}
                    {showEditDelete && onDelete && (
                      <DropdownMenuItem 
                        onClick={(e) => { 
                          e.stopPropagation(); 
                          if (window.confirm('Are you sure you want to delete this document?')) {
                            onDelete(doc.id);
                          }
                        }} 
                        className="text-red-600"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            )}
          </div>

          {/* Document Info */}
          <div className="space-y-2">
            <h3 className="font-medium text-sm text-gray-900 line-clamp-2 group-hover:text-blue-600 transition-colors leading-tight">
              {doc.title}
            </h3>

            {/* User Info - Simplified */}
            <div 
              className="flex items-center space-x-2 cursor-pointer hover:bg-gray-50 rounded-lg p-1 -m-1"
              onClick={handleUserClick}
            >
              <Avatar className="w-5 h-5">
                <AvatarImage src={doc.profiles?.avatar_url} />
                <AvatarFallback className="bg-gray-500 text-white text-xs">
                  {getUserInitials()}
                </AvatarFallback>
              </Avatar>
              <span className="text-xs text-gray-600 truncate hover:text-blue-600 transition-colors">
                {getUserDisplayName()}
              </span>
            </div>

            {/* Stats - Minimal */}
            <div className="flex items-center justify-between text-xs text-gray-500">
              <div className="flex items-center space-x-2">
                <span className="flex items-center">
                  <Eye className="w-3 h-3 mr-1" />
                  {doc.views_count}
                </span>
                <span className="flex items-center">
                  <Heart className="w-3 h-3 mr-1" />
                  {doc.likes_count}
                </span>
              </div>
              <Badge variant="outline" className="text-xs px-1 py-0">
                {doc.file_type?.toUpperCase()}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card 
      className="hover:shadow-lg transition-shadow cursor-pointer group"
      onClick={handleCardClick}
    >
      <CardContent className="p-4">
        <div className={`aspect-[3/4] bg-gradient-to-br ${getFileTypeColor()} rounded-lg mb-3 flex items-center justify-center relative overflow-hidden`}>
          {doc.thumbnail_url ? (
            <img 
              src={doc.thumbnail_url} 
              alt={doc.title}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="text-center">
              <div className="w-16 h-16 bg-white rounded-lg flex items-center justify-center mx-auto mb-2 shadow-sm">
                {getFileIcon()}
              </div>
              <Badge variant="outline" className="bg-white/80">
                {doc.file_type?.toUpperCase()}
              </Badge>
            </div>
          )}
          
          {showActions && (
            <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="secondary" size="sm" className="h-8 w-8 p-0 bg-white/90 hover:bg-white">
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={handleDownload}>
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </DropdownMenuItem>
                  {showEditDelete && onEdit && (
                    <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onEdit(doc); }}>
                      <Edit className="w-4 h-4 mr-2" />
                      Edit
                    </DropdownMenuItem>
                  )}
                  {showEditDelete && onDelete && (
                    <DropdownMenuItem 
                      onClick={(e) => { 
                        e.stopPropagation(); 
                        if (window.confirm('Are you sure you want to delete this document?')) {
                          onDelete(doc.id);
                        }
                      }} 
                      className="text-red-600"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete
                    </DropdownMenuItem>
                  )}
                  {onLike && (
                    <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onLike(doc.id); }}>
                      <Heart className="w-4 h-4 mr-2" />
                      Like
                    </DropdownMenuItem>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          )}
        </div>

        <div className="space-y-2">
          <h3 className="font-semibold text-gray-900 line-clamp-2 group-hover:text-blue-600 transition-colors">
            {doc.title}
          </h3>
          

          <div className="flex items-center justify-between pt-2">
            <div 
              className="flex items-center space-x-2 cursor-pointer hover:bg-gray-50 rounded-lg p-1 -m-1"
              onClick={handleUserClick}
            >
              <Avatar className="w-6 h-6">
                <AvatarImage src={doc.profiles?.avatar_url} />
                <AvatarFallback className="bg-gray-500 text-white text-xs">
                  {getUserInitials()}
                </AvatarFallback>
              </Avatar>
              <span className="text-sm text-gray-700 font-medium hover:text-blue-600 transition-colors">
                {getUserDisplayName()}
              </span>
            </div>

            <div className="flex items-center space-x-3 text-sm text-gray-500">
              <span className="flex items-center">
                <Eye className="w-4 h-4 mr-1" />
                {doc.views_count}
              </span>
              <span className="flex items-center">
                <Heart className="w-4 h-4 mr-1" />
                {doc.likes_count}
              </span>
              <span className="flex items-center">
                <MessageCircle className="w-4 h-4 mr-1" />
                {doc.comments_count}
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default DocumentCard;
