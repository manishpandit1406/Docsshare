
import React, { useState, useEffect } from 'react';
import { Search, X, TrendingUp } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useDocuments } from '@/hooks/useDocuments';
import { usePDFBundles } from '@/hooks/usePDFBundles';
import { useTrendingSearches } from '@/hooks/useTrendingSearches';
import { useNavigate } from 'react-router-dom';
import PDFCard from './PDFCard';
import LibraryCard from './LibraryCard';
import UserCard from './UserCard';
import { supabase } from '@/integrations/supabase/client';

interface SearchBarProps {
  onSearch?: (query: string) => void;
  placeholder?: string;
  showSuggestions?: boolean;
  showUserCards?: boolean;
  variant?: 'default' | 'compact';
  showResults?: boolean;
  showTrending?: boolean;
}

interface UserProfile {
  id: string;
  full_name?: string;
  username?: string;
  avatar_url?: string;
}

const SearchBar: React.FC<SearchBarProps> = ({ 
  onSearch, 
  placeholder = "Search documents, libraries, or users...",
  showSuggestions = true,
  showUserCards = true,
  variant = 'default',
  showResults = true,
  showTrending = false
}) => {
  const [query, setQuery] = useState('');
  const [showResultsPanel, setShowResultsPanel] = useState(false);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const { documents, searchDocuments } = useDocuments();
  const { bundles } = usePDFBundles();
  const { trendingSearches } = useTrendingSearches();
  const navigate = useNavigate();

  const isCompact = variant === 'compact';

  const filteredDocuments = documents.filter(doc => 
    doc.title.toLowerCase().includes(query.toLowerCase()) ||
    doc.description?.toLowerCase().includes(query.toLowerCase())
  );

  const filteredLibraries = bundles.filter(bundle =>
    bundle.name.toLowerCase().includes(query.toLowerCase()) ||
    bundle.description?.toLowerCase().includes(query.toLowerCase())
  );

  useEffect(() => {
    const searchUsers = async () => {
      if (query.trim() && showUserCards) {
        try {
          const { data, error } = await supabase
            .from('profiles')
            .select('id, full_name, username, avatar_url')
            .or(`full_name.ilike.%${query}%, username.ilike.%${query}%`)
            .limit(5);

          if (error) throw error;
          setUsers(data || []);
        } catch (error) {
          console.error('Error searching users:', error);
          setUsers([]);
        }
      } else {
        setUsers([]);
      }
    };

    const timeoutId = setTimeout(searchUsers, 300);
    return () => clearTimeout(timeoutId);
  }, [query, showUserCards]);

  const handleSearch = (searchQuery: string) => {
    setQuery(searchQuery);
    if (onSearch) {
      onSearch(searchQuery);
    } else {
      searchDocuments(searchQuery);
    }
    if (searchQuery.trim() && showResults) {
      setShowResultsPanel(true);
    }
  };

  const handleTrendingClick = (trendingQuery: string) => {
    setQuery(trendingQuery);
    handleSearch(trendingQuery);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && query.trim()) {
      // Navigate to search page with query
      navigate(`/search?q=${encodeURIComponent(query)}`);
      setShowResultsPanel(false);
    }
  };

  const handleResultClick = () => {
    setShowResultsPanel(false);
    setQuery('');
  };

  const clearSearch = () => {
    setQuery('');
    setShowResultsPanel(false);
    if (onSearch) onSearch('');
  };

  const hasResults = filteredDocuments.length > 0 || filteredLibraries.length > 0 || users.length > 0;
  const shouldShowTrending = showTrending && trendingSearches.length > 0 && !query.trim();

  return (
    <div className={`relative ${isCompact ? 'w-full max-w-sm' : 'w-full max-w-md'}`}>
      <div className="relative">
        <Search className={`absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 ${isCompact ? 'w-3 h-3' : 'w-4 h-4'}`} />
        <Input
          type="text"
          placeholder={placeholder}
          value={query}
          onChange={(e) => handleSearch(e.target.value)}
          onKeyPress={handleKeyPress}
          onFocus={() => {
            if (query.trim() && showResults) {
              setShowResultsPanel(true);
            } else if (shouldShowTrending) {
              setShowResultsPanel(true);
            }
          }}
          className={`pl-10 pr-10 ${isCompact ? 'h-8 text-sm' : ''}`}
        />
        {query && (
          <Button
            variant="ghost"
            size="sm"
            onClick={clearSearch}
            className={`absolute right-1 top-1/2 transform -translate-y-1/2 p-0 ${isCompact ? 'h-6 w-6' : 'h-8 w-8'}`}
          >
            <X className={isCompact ? 'w-3 h-3' : 'w-4 h-4'} />
          </Button>
        )}
      </div>

      {showResultsPanel && showSuggestions && (
        <Card className="absolute top-full mt-2 w-full z-50 max-h-96 overflow-y-auto">
          <CardContent className="p-4 space-y-4">
            {/* Trending Searches */}
            {shouldShowTrending && (
              <div>
                <h4 className="font-medium text-sm text-gray-500 mb-2 flex items-center">
                  <TrendingUp className="w-4 h-4 mr-1" />
                  Trending Searches
                </h4>
                <div className="flex flex-wrap gap-2">
                  {trendingSearches.slice(0, 5).map((trending) => (
                    <Badge
                      key={trending.id}
                      variant="outline"
                      className="cursor-pointer hover:bg-gray-100 text-xs"
                      onClick={() => handleTrendingClick(trending.query)}
                    >
                      {trending.query} ({trending.search_count})
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Users Strip */}
            {users.length > 0 && showUserCards && (
              <div>
                <h4 className="font-medium text-sm text-gray-500 mb-2">Users</h4>
                <div className="grid grid-cols-1 gap-2">
                  {users.slice(0, 3).map((user) => (
                    <div key={user.id} onClick={handleResultClick}>
                      <UserCard 
                        profile={user}
                        onClick={() => navigate(`/profile/${user.id}`)}
                        compact={true}
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Documents Strip */}
            {filteredDocuments.length > 0 && (
              <div>
                <h4 className="font-medium text-sm text-gray-500 mb-2">Documents</h4>
                <div className="grid grid-cols-1 gap-2">
                  {filteredDocuments.slice(0, 3).map((doc) => (
                    <div key={doc.id} onClick={handleResultClick}>
                      <PDFCard 
                        pdf={doc} 
                        onDelete={() => {}}
                        onViewProfile={() => {}}
                        showActions={false}
                        compact={true}
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Libraries Strip */}
            {filteredLibraries.length > 0 && (
              <div>
                <h4 className="font-medium text-sm text-gray-500 mb-2">Libraries</h4>
                <div className="grid grid-cols-1 gap-2">
                  {filteredLibraries.slice(0, 3).map((library) => (
                    <div key={library.id} onClick={handleResultClick}>
                       <LibraryCard 
                         library={library}
                         onClick={() => navigate(`/library/${library.id}`)}
                         showActions={false}
                       />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Show more results link */}
            {query.trim() && (
              <div className="pt-2 border-t">
                <Button 
                  variant="ghost" 
                  className="w-full text-left justify-start"
                  onClick={() => {
                    navigate(`/search?q=${encodeURIComponent(query)}`);
                    handleResultClick();
                  }}
                >
                  <Search className="w-4 h-4 mr-2" />
                  See all results for "{query}"
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default SearchBar;
