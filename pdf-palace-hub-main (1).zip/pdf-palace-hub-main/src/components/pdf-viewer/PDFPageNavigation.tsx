
import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';

interface PDFPageNavigationProps {
  currentPage: number;
  totalPages: number;
  pageInput: string;
  loading: boolean;
  error: string | null;
  showControls: boolean;
  onPreviousPage: () => void;
  onNextPage: () => void;
  onPageInputChange: (value: string) => void;
  onPageInputSubmit: () => void;
}

const PDFPageNavigation: React.FC<PDFPageNavigationProps> = ({
  currentPage,
  totalPages,
  pageInput,
  loading,
  error,
  showControls,
  onPreviousPage,
  onNextPage,
  onPageInputChange,
  onPageInputSubmit
}) => {
  if (!showControls || loading || error) return null;

  return (
    <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2">
      <Card className="bg-black/80 backdrop-blur-sm border-white/20 p-4 shadow-2xl">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={onPreviousPage}
            disabled={currentPage <= 1}
            className="text-white hover:bg-white/20 disabled:opacity-50"
            title="Previous page"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          
          <div className="flex items-center space-x-3">
            <span className="text-white text-sm font-medium">Page</span>
            <Input
              type="number"
              min="1"
              max={totalPages}
              value={pageInput}
              onChange={(e) => onPageInputChange(e.target.value)}
              onBlur={onPageInputSubmit}
              onKeyPress={(e) => e.key === 'Enter' && onPageInputSubmit()}
              className="w-16 h-8 px-2 text-sm bg-white/10 border-white/20 text-white text-center [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:bg-white/20 focus:border-white/40"
            />
            <span className="text-white text-sm">of</span>
            <span className="text-white text-sm font-medium min-w-[2rem] text-center">{totalPages}</span>
          </div>

          <Button
            variant="ghost"
            size="sm"
            onClick={onNextPage}
            disabled={currentPage >= totalPages}
            className="text-white hover:bg-white/20 disabled:opacity-50"
            title="Next page"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </Card>
    </div>
  );
};

export default PDFPageNavigation;
