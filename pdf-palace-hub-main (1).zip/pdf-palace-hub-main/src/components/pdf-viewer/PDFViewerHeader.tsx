
import React from 'react';
import { Badge } from '@/components/ui/badge';
import type { PDF } from '@/types/pdf';
import PDFViewerControls from './PDFViewerControls';
import PDFViewerActions from './PDFViewerActions';

interface PDFViewerHeaderProps {
  pdf: PDF;
  currentPage: number;
  totalPages: number;
  zoom: number;
  rotation: number;
  loading: boolean;
  showControls: boolean;
  isFullscreen: boolean;
  onClose: () => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onRotate: () => void;
  onDownload: () => void;
  onPreviousPage: () => void;
  onNextPage: () => void;
  onFirstPage: () => void;
  onLastPage: () => void;
  onToggleFullscreen: () => void;
  onZoomChange: (value: number[]) => void;
}

const PDFViewerHeader: React.FC<PDFViewerHeaderProps> = ({
  pdf,
  currentPage,
  totalPages,
  zoom,
  loading,
  showControls,
  isFullscreen,
  onClose,
  onZoomIn,
  onZoomOut,
  onRotate,
  onDownload,
  onPreviousPage,
  onNextPage,
  onFirstPage,
  onLastPage,
  onToggleFullscreen,
  onZoomChange
}) => {
  if (!showControls) return null;

  return (
    <div className="absolute top-0 left-0 right-0 z-10 bg-gradient-to-b from-black/95 to-black/60 backdrop-blur-sm border-b border-white/10">
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3">
            <h2 className="text-white font-semibold truncate max-w-md text-lg">{pdf.title}</h2>
            <Badge variant="secondary" className="bg-white/20 text-white border-white/30 text-xs">
              PDF
            </Badge>
          </div>
          <div className="text-white/90 text-sm bg-white/15 px-3 py-1.5 rounded-full border border-white/20">
            <span className="font-medium">Page {currentPage}</span>
            <span className="text-white/70 mx-1">of</span>
            <span className="font-medium">{totalPages}</span>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <PDFViewerControls
            currentPage={currentPage}
            totalPages={totalPages}
            zoom={zoom}
            loading={loading}
            onPreviousPage={onPreviousPage}
            onNextPage={onNextPage}
            onFirstPage={onFirstPage}
            onLastPage={onLastPage}
            onZoomIn={onZoomIn}
            onZoomOut={onZoomOut}
            onZoomChange={onZoomChange}
          />

          <PDFViewerActions
            isFullscreen={isFullscreen}
            onRotate={onRotate}
            onDownload={onDownload}
            onToggleFullscreen={onToggleFullscreen}
            onClose={onClose}
          />
        </div>
      </div>
    </div>
  );
};

export default PDFViewerHeader;
