
import React from 'react';
import { ChevronLeft, ChevronRight, SkipBack, SkipForward, ZoomIn, ZoomOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';

interface PDFViewerControlsProps {
  currentPage: number;
  totalPages: number;
  zoom: number;
  loading: boolean;
  onPreviousPage: () => void;
  onNextPage: () => void;
  onFirstPage: () => void;
  onLastPage: () => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onZoomChange: (value: number[]) => void;
}

const PDFViewerControls: React.FC<PDFViewerControlsProps> = ({
  currentPage,
  totalPages,
  zoom,
  loading,
  onPreviousPage,
  onNextPage,
  onFirstPage,
  onLastPage,
  onZoomIn,
  onZoomOut,
  onZoomChange
}) => {
  return (
    <div className="flex items-center space-x-2">
      {/* Navigation controls */}
      <Button
        variant="outline"
        size="sm"
        onClick={onFirstPage}
        disabled={currentPage <= 1 || loading}
        className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 disabled:opacity-50 disabled:cursor-not-allowed"
        title="First page"
      >
        <SkipBack className="w-4 h-4" />
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={onPreviousPage}
        disabled={currentPage <= 1 || loading}
        className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 disabled:opacity-50 disabled:cursor-not-allowed"
        title="Previous page"
      >
        <ChevronLeft className="w-4 h-4" />
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={onNextPage}
        disabled={currentPage >= totalPages || loading}
        className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 disabled:opacity-50 disabled:cursor-not-allowed"
        title="Next page"
      >
        <ChevronRight className="w-4 h-4" />
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={onLastPage}
        disabled={currentPage >= totalPages || loading}
        className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 disabled:opacity-50 disabled:cursor-not-allowed"
        title="Last page"
      >
        <SkipForward className="w-4 h-4" />
      </Button>

      {/* Zoom controls */}
      <div className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-md px-3 py-1.5">
        <Button
          variant="ghost"
          size="sm"
          onClick={onZoomOut}
          disabled={zoom <= 0.5}
          className="text-white hover:bg-white/20 h-6 w-6 p-0 disabled:opacity-50"
          title="Zoom out"
        >
          <ZoomOut className="w-3 h-3" />
        </Button>

        <div className="w-20">
          <Slider
            value={[zoom]}
            onValueChange={onZoomChange}
            min={0.5}
            max={3}
            step={0.25}
            className="w-full"
          />
        </div>

        <Button
          variant="ghost"
          size="sm"
          onClick={onZoomIn}
          disabled={zoom >= 3}
          className="text-white hover:bg-white/20 h-6 w-6 p-0 disabled:opacity-50"
          title="Zoom in"
        >
          <ZoomIn className="w-3 h-3" />
        </Button>

        <span className="text-white text-xs min-w-[3rem] text-center font-medium">
          {Math.round(zoom * 100)}%
        </span>
      </div>
    </div>
  );
};

export default PDFViewerControls;
