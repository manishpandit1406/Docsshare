
import React from 'react';
import { Button } from '@/components/ui/button';
import type { PDF } from '@/types/pdf';

interface PDFViewerContentProps {
  pdf: PDF;
  currentPage: number;
  zoom: number;
  rotation: number;
  pageImages: { [key: number]: string };
  loading: boolean;
  error: string | null;
  renderingPage: number | null;
  showControls: boolean;
  onRetryRender: () => void;
}

const PDFViewerContent: React.FC<PDFViewerContentProps> = ({
  pdf,
  currentPage,
  zoom,
  rotation,
  pageImages,
  loading,
  error,
  renderingPage,
  showControls,
  onRetryRender
}) => {
  const containerHeight = showControls ? 'calc(100vh - 5rem)' : 'calc(100vh - 1rem)';
  const marginTop = showControls ? 'mt-20' : 'mt-4';

  return (
    <div className={`${marginTop} overflow-auto bg-gradient-to-br from-gray-900 to-black flex justify-center items-center transition-all duration-300`} style={{ height: containerHeight }}>
      {loading ? (
        <div className="text-white text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-lg font-medium">Loading PDF...</p>
          <p className="text-sm text-white/70 mt-2">Preparing document for viewing</p>
          <p className="text-xs text-white/50 mt-2">URL: {pdf.file_url}</p>
        </div>
      ) : error ? (
        <div className="text-white text-center max-w-md">
          <div className="text-red-400 text-6xl mb-4">⚠️</div>
          <p className="text-lg font-medium mb-2">Error Loading PDF</p>
          <p className="text-sm text-white/70 mb-4">{error}</p>
          <Button 
            onClick={onRetryRender}
            className="bg-white/20 text-white hover:bg-white/30"
          >
            Retry Loading
          </Button>
          <p className="text-xs text-white/40 mt-4">PDF URL: {pdf.file_url}</p>
        </div>
      ) : pageImages[currentPage] ? (
        <div className="flex flex-col items-center w-full p-4">
          <div 
            style={{ 
              transform: `scale(${zoom}) rotate(${rotation}deg)`,
              transformOrigin: 'center'
            }}
            className="transition-transform duration-200 shadow-2xl rounded-lg overflow-hidden bg-white"
          >
            <img
              src={pageImages[currentPage]}
              alt={`Page ${currentPage} of ${pdf.title}`}
              className="max-w-full max-h-full"
              style={{ 
                maxHeight: showControls ? 'calc(100vh - 240px)' : 'calc(100vh - 120px)',
                maxWidth: '100%'
              }}
            />
          </div>
        </div>
      ) : renderingPage === currentPage ? (
        <div className="text-white text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-lg">Rendering page {currentPage}...</p>
        </div>
      ) : (
        <div className="text-white text-center">
          <p className="text-lg mb-2">Page {currentPage} failed to load</p>
          <Button 
            onClick={onRetryRender}
            className="bg-white/20 text-white hover:bg-white/30"
          >
            Retry
          </Button>
        </div>
      )}
    </div>
  );
};

export default PDFViewerContent;
