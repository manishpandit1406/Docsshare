
import React from 'react';
import { X, RotateCw, Download, Maximize2, Minimize2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface PDFViewerActionsProps {
  isFullscreen: boolean;
  onRotate: () => void;
  onDownload: () => void;
  onToggleFullscreen: () => void;
  onClose: () => void;
}

const PDFViewerActions: React.FC<PDFViewerActionsProps> = ({
  isFullscreen,
  onRotate,
  onDownload,
  onToggleFullscreen,
  onClose
}) => {
  return (
    <div className="flex items-center space-x-2">
      <Button
        variant="outline"
        size="sm"
        onClick={onRotate}
        className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
        title="Rotate page"
      >
        <RotateCw className="w-4 h-4" />
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={onToggleFullscreen}
        className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
        title="Toggle fullscreen"
      >
        {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={onDownload}
        className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
        title="Download PDF"
      >
        <Download className="w-4 h-4" />
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={onClose}
        className="bg-red-500/20 backdrop-blur-sm border-red-400/30 text-white hover:bg-red-500/30"
        title="Close viewer"
      >
        <X className="w-4 h-4 mr-1" />
        Close
      </Button>
    </div>
  );
};

export default PDFViewerActions;
