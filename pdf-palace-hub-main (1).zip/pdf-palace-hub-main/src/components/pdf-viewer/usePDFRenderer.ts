
import { useState, useEffect } from 'react';
import type { PDF } from '@/types/pdf';

interface UsePDFRendererProps {
  pdf: PDF;
  isOpen: boolean;
}

export const usePDFRenderer = ({ pdf, isOpen }: UsePDFRendererProps) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [pdfDoc, setPdfDoc] = useState<any>(null);
  const [pageImages, setPageImages] = useState<{ [key: number]: string }>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pageInput, setPageInput] = useState('1');
  const [renderingPage, setRenderingPage] = useState<number | null>(null);

  useEffect(() => {
    if (isOpen && pdf) {
      console.log('Starting PDF load for:', pdf.title);
      loadPDF();
    }
    return () => {
      if (pdfDoc) {
        try {
          pdfDoc.destroy?.();
        } catch (error) {
          console.log('Error destroying PDF doc:', error);
        }
      }
    };
  }, [isOpen, pdf]);

  useEffect(() => {
    setPageInput(currentPage.toString());
  }, [currentPage]);

  const loadPDF = async () => {
    try {
      setLoading(true);
      setError(null);
      setPdfDoc(null);
      setPageImages({});
      setCurrentPage(1);
      setPageInput('1');
      setTotalPages(1);

      console.log('Loading PDF from URL:', pdf.file_url);

      const pdfjsLib = await import('pdfjs-dist');
      
      pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
        'pdfjs-dist/build/pdf.worker.min.js',
        import.meta.url
      ).toString();

      console.log('PDF.js worker configured');

      const response = await fetch(pdf.file_url, { method: 'HEAD' });
      if (!response.ok) {
        throw new Error(`PDF file not accessible: ${response.status} ${response.statusText}`);
      }

      console.log('PDF URL is accessible, loading document...');

      const loadingTask = pdfjsLib.getDocument({
        url: pdf.file_url,
        verbosity: 0,
      });

      loadingTask.onProgress = (progress: any) => {
        console.log('Loading progress:', Math.round((progress.loaded / progress.total) * 100) + '%');
      };

      const pdfDocument = await loadingTask.promise;
      
      console.log('PDF loaded successfully. Total pages:', pdfDocument.numPages);
      
      setPdfDoc(pdfDocument);
      setTotalPages(pdfDocument.numPages);

      await renderPage(pdfDocument, 1);

      setLoading(false);
    } catch (error: any) {
      console.error('Error loading PDF:', error);
      setError(error.message || 'Failed to load PDF');
      setLoading(false);
      setTotalPages(1);
    }
  };

  const renderPage = async (pdfDocument: any, pageNumber: number) => {
    if (pageImages[pageNumber] || !pdfDocument || pageNumber < 1 || pageNumber > pdfDocument.numPages) {
      console.log(`Skipping render for page ${pageNumber} - already rendered or invalid`);
      return;
    }

    try {
      setRenderingPage(pageNumber);
      console.log(`Starting render for page ${pageNumber}...`);

      const page = await pdfDocument.getPage(pageNumber);
      console.log(`Got page object for page ${pageNumber}`);

      const viewport = page.getViewport({ scale: 2 });
      console.log(`Viewport created for page ${pageNumber}:`, viewport.width, 'x', viewport.height);

      const canvas = document.createElement('canvas');
      const context = canvas.getContext('2d');
      
      if (!context) {
        throw new Error('Could not get canvas 2D context');
      }

      canvas.height = viewport.height;
      canvas.width = viewport.width;

      const renderContext = {
        canvasContext: context,
        viewport: viewport
      };

      console.log(`Starting render task for page ${pageNumber}...`);
      await page.render(renderContext).promise;
      console.log(`Render completed for page ${pageNumber}`);

      const imageDataUrl = canvas.toDataURL('image/png', 0.9);
      console.log(`Image data URL created for page ${pageNumber}, size:`, imageDataUrl.length);

      setPageImages(prev => ({
        ...prev,
        [pageNumber]: imageDataUrl
      }));

      console.log(`Page ${pageNumber} rendered and stored successfully`);
    } catch (error: any) {
      console.error(`Error rendering page ${pageNumber}:`, error);
      setError(`Failed to render page ${pageNumber}: ${error.message}`);
    } finally {
      setRenderingPage(null);
    }
  };

  useEffect(() => {
    if (!pdfDoc || !totalPages || currentPage < 1 || currentPage > totalPages) return;
    
    console.log(`Effect triggered for page ${currentPage}, total pages: ${totalPages}`);
    
    if (!pageImages[currentPage]) {
      console.log(`Current page ${currentPage} not rendered, rendering now...`);
      renderPage(pdfDoc, currentPage);
    }
    
    if (currentPage > 1 && !pageImages[currentPage - 1]) {
      setTimeout(() => {
        console.log(`Pre-rendering previous page: ${currentPage - 1}`);
        renderPage(pdfDoc, currentPage - 1);
      }, 100);
    }
    if (currentPage < totalPages && !pageImages[currentPage + 1]) {
      setTimeout(() => {
        console.log(`Pre-rendering next page: ${currentPage + 1}`);
        renderPage(pdfDoc, currentPage + 1);
      }, 150);
    }
  }, [currentPage, pdfDoc, totalPages, pageImages]);

  const retryRender = () => {
    console.log('Retrying render for current page:', currentPage);
    setError(null);
    if (pdfDoc) {
      renderPage(pdfDoc, currentPage);
    } else {
      loadPDF();
    }
  };

  return {
    currentPage,
    setCurrentPage,
    totalPages,
    zoom,
    setZoom,
    rotation,
    setRotation,
    pageImages,
    loading,
    error,
    pageInput,
    setPageInput,
    renderingPage,
    retryRender
  };
};
