
import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

interface PDFErrorDisplayProps {
  error?: string;
  onRetry?: () => void;
  type?: 'load' | 'upload' | 'general';
}

const PDFErrorDisplay: React.FC<PDFErrorDisplayProps> = ({ 
  error, 
  onRetry, 
  type = 'general' 
}) => {
  const getErrorMessage = () => {
    switch (type) {
      case 'load':
        return '⚠ PDF failed to load. The file might be corrupted or temporarily unavailable.';
      case 'upload':
        return '⚠ Upload failed. Please check your file and try again.';
      default:
        return error || '⚠ Something went wrong. Please try again.';
    }
  };

  return (
    <Card className="border-red-200 bg-red-50">
      <CardContent className="p-6 text-center">
        <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-red-800 mb-2">
          {type === 'load' ? 'PDF Load Error' : 'Error'}
        </h3>
        <p className="text-red-700 mb-4">
          {getErrorMessage()}
        </p>
        {onRetry && (
          <Button 
            onClick={onRetry}
            variant="outline"
            className="border-red-300 text-red-700 hover:bg-red-100"
          >
            <RefreshCw size={16} className="mr-2" />
            Try Again
          </Button>
        )}
      </CardContent>
    </Card>
  );
};

export default PDFErrorDisplay;
