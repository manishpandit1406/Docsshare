import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import type { PDF } from '@/types/pdf';

export class PDFService {
  static async fetchPDFs(): Promise<PDF[]> {
    console.log('Starting PDF fetch...');

    // First fetch PDFs with fresh counts using aggregate functions
    const { data: pdfData, error: pdfError } = await supabase
      .from('pdfs')
      .select(`
        *
      `)
      .order('created_at', { ascending: false });

    console.log('PDF fetch result:', { pdfData, pdfError });

    if (pdfError) {
      console.error('Error fetching PDFs:', pdfError);
      throw pdfError;
    }

    if (!pdfData || pdfData.length === 0) {
      console.log('No PDFs found');
      return [];
    }

    // Get fresh counts for each PDF
    const pdfsWithCounts = await Promise.all(
      pdfData.map(async (pdf) => {
        try {
          // Get actual likes count
          const { count: likesCount } = await supabase
            .from('pdf_likes')
            .select('*', { count: 'exact', head: true })
            .eq('pdf_id', pdf.id);

          // Get actual comments count
          const { count: commentsCount } = await supabase
            .from('pdf_comments')
            .select('*', { count: 'exact', head: true })
            .eq('pdf_id', pdf.id);

          return {
            ...pdf,
            likes_count: likesCount || 0,
            comments_count: commentsCount || 0
          };
        } catch (error) {
          console.error('Error fetching counts for PDF:', pdf.id, error);
          return pdf; // Return original data if count fetch fails
        }
      })
    );

    // Get unique user IDs
    const userIds = [...new Set(pdfsWithCounts.map(pdf => pdf.user_id))];
    console.log('Fetching profiles for user IDs:', userIds);

    // Fetch profiles for these users
    const { data: profileData, error: profileError } = await supabase
      .from('profiles')
      .select('id, full_name, username, avatar_url')
      .in('id', userIds);

    console.log('Profile fetch result:', { profileData, profileError });

    if (profileError) {
      console.error('Error fetching profiles:', profileError);
      // Continue without profiles data instead of failing
    }

    // Combine PDF data with profile data
    const pdfsWithProfiles = pdfsWithCounts.map(pdf => ({
      ...pdf,
      profiles: profileData?.find(profile => profile.id === pdf.user_id) || undefined
    }));

    console.log('Final PDFs with profiles:', pdfsWithProfiles.length, 'items');
    return pdfsWithProfiles;
  }

  static async searchPDFs(query: string): Promise<PDF[]> {
    console.log('Searching PDFs with query:', query);

    if (!query.trim()) {
      return this.fetchPDFs();
    }

    // First fetch PDFs with search
    const { data: pdfData, error: pdfError } = await supabase
      .from('pdfs')
      .select(`*`)
      .or(`title.ilike.%${query}%, description.ilike.%${query}%, tags.cs.{${query}}`)
      .order('created_at', { ascending: false });

    if (pdfError) throw pdfError;

    if (!pdfData || pdfData.length === 0) {
      return [];
    }

    // Get fresh counts for each PDF
    const pdfsWithCounts = await Promise.all(
      pdfData.map(async (pdf) => {
        try {
          // Get actual likes count
          const { count: likesCount } = await supabase
            .from('pdf_likes')
            .select('*', { count: 'exact', head: true })
            .eq('pdf_id', pdf.id);

          // Get actual comments count
          const { count: commentsCount } = await supabase
            .from('pdf_comments')
            .select('*', { count: 'exact', head: true })
            .eq('pdf_id', pdf.id);

          return {
            ...pdf,
            likes_count: likesCount || 0,
            comments_count: commentsCount || 0
          };
        } catch (error) {
          console.error('Error fetching counts for PDF:', pdf.id, error);
          return pdf; // Return original data if count fetch fails
        }
      })
    );

    // Get unique user IDs
    const userIds = [...new Set(pdfsWithCounts.map(pdf => pdf.user_id))];

    // Fetch profiles for these users
    const { data: profileData, error: profileError } = await supabase
      .from('profiles')
      .select('id, full_name, username, avatar_url')
      .in('id', userIds);

    if (profileError) {
      console.error('Error fetching profiles:', profileError);
      // Continue without profiles data
    }

    // Combine PDF data with profile data
    const pdfsWithProfiles = pdfsWithCounts.map(pdf => ({
      ...pdf,
      profiles: profileData?.find(profile => profile.id === pdf.user_id) || undefined
    }));

    return pdfsWithProfiles;
  }

  static async uploadPDF(
    file: File,
    title: string,
    description: string,
    tags: string[],
    thumbnailFile?: File
  ): Promise<any> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    // Upload the PDF file
    const fileExt = file.name.split('.').pop();
    const fileName = `${Math.random()}.${fileExt}`;
    const filePath = `${user.id}/${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from('pdfs')
      .upload(filePath, file);

    if (uploadError) throw uploadError;

    // Get the public URL
    const { data: { publicUrl } } = supabase.storage
      .from('pdfs')
      .getPublicUrl(filePath);

    let thumbnailUrl = null;
    if (thumbnailFile) {
      const thumbExt = thumbnailFile.name.split('.').pop();
      const thumbFileName = `thumb_${Math.random()}.${thumbExt}`;
      const thumbPath = `${user.id}/thumbnails/${thumbFileName}`;

      const { error: thumbUploadError } = await supabase.storage
        .from('pdfs')
        .upload(thumbPath, thumbnailFile);

      if (!thumbUploadError) {
        const { data: { publicUrl: thumbPublicUrl } } = supabase.storage
          .from('pdfs')
          .getPublicUrl(thumbPath);
        thumbnailUrl = thumbPublicUrl;
      }
    }

    // Insert PDF record
    const { data, error: insertError } = await supabase
      .from('pdfs')
      .insert({
        title,
        description,
        file_url: publicUrl,
        file_name: file.name,
        file_size: file.size,
        thumbnail_url: thumbnailUrl,
        tags,
        user_id: user.id
      })
      .select()
      .single();

    if (insertError) throw insertError;

    return data;
  }

  static async deletePDF(pdfId: string): Promise<void> {
    const { error } = await supabase
      .from('pdfs')
      .delete()
      .eq('id', pdfId);

    if (error) throw error;
  }
}
