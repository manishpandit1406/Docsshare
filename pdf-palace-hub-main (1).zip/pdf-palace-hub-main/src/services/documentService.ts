
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import type { Document } from '@/types/document';

export class DocumentService {
  static async fetchDocuments(): Promise<Document[]> {
    console.log('Starting document fetch...');

    // First fetch documents with fresh counts using aggregate functions
    const { data: documentData, error: documentError } = await supabase
      .from('pdfs')
      .select(`
        *
      `)
      .order('created_at', { ascending: false });

    console.log('Document fetch result:', { documentData, documentError });

    if (documentError) {
      console.error('Error fetching documents:', documentError);
      throw documentError;
    }

    if (!documentData || documentData.length === 0) {
      console.log('No documents found');
      return [];
    }

    // Get fresh counts for each document
    const documentsWithCounts = await Promise.all(
      documentData.map(async (doc) => {
        try {
          // Get actual likes count
          const { count: likesCount } = await supabase
            .from('pdf_likes')
            .select('*', { count: 'exact', head: true })
            .eq('pdf_id', doc.id);

          // Get actual comments count
          const { count: commentsCount } = await supabase
            .from('pdf_comments')
            .select('*', { count: 'exact', head: true })
            .eq('pdf_id', doc.id);

          return {
            ...doc,
            likes_count: likesCount || 0,
            comments_count: commentsCount || 0
          };
        } catch (error) {
          console.error('Error fetching counts for document:', doc.id, error);
          return doc; // Return original data if count fetch fails
        }
      })
    );

    // Get unique user IDs
    const userIds = [...new Set(documentsWithCounts.map(doc => doc.user_id))];
    console.log('Fetching profiles for user IDs:', userIds);

    // Fetch profiles for these users
    const { data: profileData, error: profileError } = await supabase
      .from('profiles')
      .select('id, full_name, username, avatar_url')
      .in('id', userIds);

    console.log('Profile fetch result:', { profileData, profileError });

    if (profileError) {
      console.error('Error fetching profiles:', profileError);
      // Continue without profiles data instead of failing
    }

    // Combine document data with profile data
    const documentsWithProfiles = documentsWithCounts.map(doc => ({
      ...doc,
      profiles: profileData?.find(profile => profile.id === doc.user_id) || undefined
    }));

    console.log('Final documents with profiles:', documentsWithProfiles.length, 'items');
    return documentsWithProfiles;
  }

  static async searchDocuments(query: string): Promise<Document[]> {
    console.log('Searching documents with query:', query);

    if (!query.trim()) {
      return this.fetchDocuments();
    }

    // First fetch documents with search
    const { data: documentData, error: documentError } = await supabase
      .from('pdfs')
      .select(`*`)
      .or(`title.ilike.%${query}%, description.ilike.%${query}%, tags.cs.{${query}}`)
      .order('created_at', { ascending: false });

    if (documentError) throw documentError;

    if (!documentData || documentData.length === 0) {
      return [];
    }

    // Get fresh counts for each document
    const documentsWithCounts = await Promise.all(
      documentData.map(async (doc) => {
        try {
          // Get actual likes count
          const { count: likesCount } = await supabase
            .from('pdf_likes')
            .select('*', { count: 'exact', head: true })
            .eq('pdf_id', doc.id);

          // Get actual comments count
          const { count: commentsCount } = await supabase
            .from('pdf_comments')
            .select('*', { count: 'exact', head: true })
            .eq('pdf_id', doc.id);

          return {
            ...doc,
            likes_count: likesCount || 0,
            comments_count: commentsCount || 0
          };
        } catch (error) {
          console.error('Error fetching counts for document:', doc.id, error);
          return doc; // Return original data if count fetch fails
        }
      })
    );

    // Get unique user IDs
    const userIds = [...new Set(documentsWithCounts.map(doc => doc.user_id))];

    // Fetch profiles for these users
    const { data: profileData, error: profileError } = await supabase
      .from('profiles')
      .select('id, full_name, username, avatar_url')
      .in('id', userIds);

    if (profileError) {
      console.error('Error fetching profiles:', profileError);
      // Continue without profiles data
    }

    // Combine document data with profile data
    const documentsWithProfiles = documentsWithCounts.map(doc => ({
      ...doc,
      profiles: profileData?.find(profile => profile.id === doc.user_id) || undefined
    }));

    return documentsWithProfiles;
  }

  static async uploadDocument(
    file: File,
    title: string,
    description: string,
    tags: string[],
    thumbnailFile?: File
  ): Promise<any> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    // Determine file type and MIME type
    const fileExtension = file.name.split('.').pop()?.toLowerCase() || '';
    const mimeType = file.type;
    
    // Map file extensions to our supported types
    const fileTypeMap: Record<string, string> = {
      'pdf': 'pdf',
      'doc': 'doc',
      'docx': 'docx',
      'xls': 'xls',
      'xlsx': 'xlsx',
      'ppt': 'ppt',
      'pptx': 'pptx',
      'txt': 'txt',
      'rtf': 'rtf',
      'odt': 'odt'
    };

    const fileType = fileTypeMap[fileExtension] || 'pdf';

    // Upload the document file
    const fileName = `${Math.random()}.${fileExtension}`;
    const filePath = `${user.id}/${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from('pdfs')
      .upload(filePath, file);

    if (uploadError) throw uploadError;

    // Get the public URL
    const { data: { publicUrl } } = supabase.storage
      .from('pdfs')
      .getPublicUrl(filePath);

    let thumbnailUrl = null;
    if (thumbnailFile) {
      const thumbExt = thumbnailFile.name.split('.').pop();
      const thumbFileName = `thumb_${Math.random()}.${thumbExt}`;
      const thumbPath = `${user.id}/thumbnails/${thumbFileName}`;

      const { error: thumbUploadError } = await supabase.storage
        .from('pdfs')
        .upload(thumbPath, thumbnailFile);

      if (!thumbUploadError) {
        const { data: { publicUrl: thumbPublicUrl } } = supabase.storage
          .from('pdfs')
          .getPublicUrl(thumbPath);
        thumbnailUrl = thumbPublicUrl;
      }
    }

    // Insert document record
    const { data, error: insertError } = await supabase
      .from('pdfs')
      .insert({
        title,
        description,
        file_url: publicUrl,
        file_name: file.name,
        file_size: file.size,
        file_type: fileType,
        mime_type: mimeType,
        thumbnail_url: thumbnailUrl,
        tags,
        user_id: user.id
      })
      .select()
      .single();

    if (insertError) throw insertError;

    return data;
  }

  static async deleteDocument(documentId: string): Promise<void> {
    const { error } = await supabase
      .from('pdfs')
      .delete()
      .eq('id', documentId);

    if (error) throw error;
  }
}

// Export for backward compatibility
export const PDFService = DocumentService;
