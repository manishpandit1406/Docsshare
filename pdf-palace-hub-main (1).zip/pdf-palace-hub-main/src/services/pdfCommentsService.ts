
import { supabase } from '@/integrations/supabase/client';

export interface Comment {
  id: string;
  content: string;
  created_at: string;
  user_id: string;
  replies_count?: number;
  profiles?: {
    full_name?: string;
    username?: string;
    avatar_url?: string;
  };
}

export const fetchPDFComments = async (pdfId: string): Promise<Comment[]> => {
  try {
    // First, try to fetch comments with profiles
    const { data: commentsData, error: commentsError } = await supabase
      .from('pdf_comments')
      .select('id, content, created_at, user_id, replies_count')
      .eq('pdf_id', pdfId)
      .order('created_at', { ascending: false });

    if (commentsError) throw commentsError;

    // Then fetch profiles separately for each comment
    const commentsWithProfiles = await Promise.all(
      (commentsData || []).map(async (comment) => {
        try {
          const { data: profileData } = await supabase
            .from('profiles')
            .select('full_name, username, avatar_url')
            .eq('id', comment.user_id)
            .maybeSingle();

          return {
            ...comment,
            profiles: profileData || undefined
          };
        } catch (error) {
          console.error('Error fetching profile for comment:', error);
          return {
            ...comment,
            profiles: undefined
          };
        }
      })
    );

    return commentsWithProfiles;
  } catch (error) {
    console.error('Error fetching comments:', error);
    // Fallback: just set comments without profiles
    try {
      const { data: commentsData, error: commentsError } = await supabase
        .from('pdf_comments')
        .select('id, content, created_at, user_id, replies_count')
        .eq('pdf_id', pdfId)
        .order('created_at', { ascending: false });

      if (commentsError) throw commentsError;
      return commentsData?.map(comment => ({ ...comment, profiles: undefined })) || [];
    } catch (fallbackError) {
      console.error('Error in fallback comment fetch:', fallbackError);
      return [];
    }
  }
};

export const addPDFComment = async (userId: string, pdfId: string, content: string): Promise<Comment> => {
  try {
    const { data, error } = await supabase
      .from('pdf_comments')
      .insert({
        user_id: userId,
        pdf_id: pdfId,
        content
      })
      .select('id, content, created_at, user_id, replies_count')
      .single();

    if (error) throw error;
    
    if (data) {
      return { ...data, profiles: undefined };
    }
    
    throw new Error('No data returned from comment insert');
  } catch (error) {
    console.error('Error adding comment:', error);
    throw error;
  }
};

export const deletePDFComment = async (commentId: string): Promise<void> => {
  try {
    const { error } = await supabase
      .from('pdf_comments')
      .delete()
      .eq('id', commentId);

    if (error) throw error;
  } catch (error) {
    console.error('Error deleting comment:', error);
    throw error;
  }
};
