
import { supabase } from '@/integrations/supabase/client';

export interface CommentReply {
  id: string;
  comment_id: string;
  content: string;
  created_at: string;
  user_id: string;
  profiles?: {
    full_name?: string;
    username?: string;
    avatar_url?: string;
  };
}

export const fetchCommentReplies = async (commentId: string): Promise<CommentReply[]> => {
  try {
    const { data: repliesData, error: repliesError } = await supabase
      .from('pdf_comment_replies')
      .select('id, comment_id, content, created_at, user_id')
      .eq('comment_id', commentId)
      .order('created_at', { ascending: true });

    if (repliesError) throw repliesError;

    const repliesWithProfiles = await Promise.all(
      (repliesData || []).map(async (reply) => {
        try {
          const { data: profileData } = await supabase
            .from('profiles')
            .select('full_name, username, avatar_url')
            .eq('id', reply.user_id)
            .maybeSingle();

          return {
            ...reply,
            profiles: profileData || undefined
          };
        } catch (error) {
          console.error('Error fetching profile for reply:', error);
          return {
            ...reply,
            profiles: undefined
          };
        }
      })
    );

    return repliesWithProfiles;
  } catch (error) {
    console.error('Error fetching comment replies:', error);
    return [];
  }
};

export const addCommentReply = async (userId: string, commentId: string, content: string): Promise<CommentReply> => {
  try {
    const { data, error } = await supabase
      .from('pdf_comment_replies')
      .insert({
        user_id: userId,
        comment_id: commentId,
        content
      })
      .select('id, comment_id, content, created_at, user_id')
      .single();

    if (error) throw error;
    
    if (data) {
      return { ...data, profiles: undefined };
    }
    
    throw new Error('No data returned from reply insert');
  } catch (error) {
    console.error('Error adding comment reply:', error);
    throw error;
  }
};
