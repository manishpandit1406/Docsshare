
import { supabase } from '@/integrations/supabase/client';

export const incrementPDFViews = async (pdfId: string, userId?: string): Promise<boolean> => {
  try {
    // Use the database function to safely increment view count
    const { data, error } = await supabase.rpc('increment_pdf_view_count', {
      pdf_uuid: pdfId,
      viewer_user_id: userId || null,
      viewer_ip_address: null // We'll use user ID primarily, IP as fallback for anonymous users
    });

    if (error) {
      console.error('Error incrementing PDF views:', error);
      return false;
    }

    console.log('View tracking result:', data ? 'New view recorded' : 'Already viewed');
    return data || false; // Returns true if new view was recorded, false if already viewed
  } catch (error) {
    console.error('Error incrementing PDF views:', error);
    return false;
  }
};
