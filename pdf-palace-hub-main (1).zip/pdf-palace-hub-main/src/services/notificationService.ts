
import { supabase } from '@/integrations/supabase/client';

export interface NotificationData {
  pdf_id?: string;
  comment_id?: string;
  user_id?: string;
  [key: string]: any;
}

export const createNotification = async (
  targetUserId: string,
  title: string,
  message: string,
  type: 'info' | 'success' | 'warning' | 'error' | 'follow' | 'like' | 'comment' | 'mention' = 'info',
  data: NotificationData = {}
) => {
  try {
    const { data: result, error } = await supabase.rpc('create_notification', {
      target_user_id: targetUserId,
      notification_title: title,
      notification_message: message,
      notification_type: type,
      notification_data: data
    });

    if (error) {
      console.error('Error creating notification:', error);
      throw error;
    }

    return result;
  } catch (error) {
    console.error('Failed to create notification:', error);
    throw error;
  }
};

export const notifyPDFLike = async (pdfId: string, pdfTitle: string, pdfOwnerId: string, likerName: string) => {
  if (!pdfOwnerId) return;
  
  return createNotification(
    pdfOwnerId,
    'PDF Liked',
    `${likerName} liked your PDF "${pdfTitle}"`,
    'like',
    { pdf_id: pdfId }
  );
};

export const notifyPDFComment = async (pdfId: string, pdfTitle: string, pdfOwnerId: string, commenterName: string, commentContent: string) => {
  if (!pdfOwnerId) return;
  
  return createNotification(
    pdfOwnerId,
    'New Comment',
    `${commenterName} commented on your PDF "${pdfTitle}": "${commentContent.substring(0, 50)}${commentContent.length > 50 ? '...' : ''}"`,
    'comment',
    { pdf_id: pdfId }
  );
};

export const notifyNewFollower = async (targetUserId: string, followerName: string, followerId: string) => {
  return createNotification(
    targetUserId,
    'New Follower',
    `${followerName} started following you`,
    'follow',
    { user_id: followerId }
  );
};

export const notifyMention = async (targetUserId: string, mentionerName: string, context: string, contextId: string) => {
  return createNotification(
    targetUserId,
    'You were mentioned',
    `${mentionerName} mentioned you in ${context}`,
    'mention',
    { context_id: contextId }
  );
};

export const notifyWelcome = async (userId: string, userName: string) => {
  return createNotification(
    userId,
    'Welcome to PDFShare!',
    `Welcome ${userName}! Start by uploading your first PDF or exploring what others have shared.`,
    'success',
    {}
  );
};

export const notifyUploadSuccess = async (userId: string, pdfTitle: string) => {
  return createNotification(
    userId,
    'PDF Uploaded Successfully',
    `Your PDF "${pdfTitle}" has been uploaded and is now available for others to view.`,
    'success',
    {}
  );
};
