
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

export interface DocumentContent {
  pages: PageContent[];
  metadata: {
    title: string;
    author: string;
    createdAt: string;
    modifiedAt: string;
  };
}

export interface PageContent {
  id: string;
  elements: DocumentElement[];
  background: {
    color: string;
    image?: string;
  };
  size: {
    width: number;
    height: number;
  };
}

export interface DocumentElement {
  id: string;
  type: 'text' | 'image' | 'shape' | 'table' | 'chart';
  position: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  content: any;
  style: any;
  zIndex: number;
}

export class DocumentEditorService {
  static async startEditingSession(documentId: string) {
    try {
      const { data, error } = await supabase
        .from('document_edit_sessions')
        .insert({
          document_id: documentId,
          user_id: (await supabase.auth.getUser()).data.user?.id,
          session_data: {},
          is_active: true
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error starting editing session:', error);
      throw error;
    }
  }

  static async saveDocumentContent(documentId: string, content: DocumentContent, changesSummary?: string) {
    try {
      const { data, error } = await supabase.rpc('create_document_version', {
        p_document_id: documentId,
        p_content: content,
        p_changes_summary: changesSummary || 'Document updated'
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error saving document content:', error);
      throw error;
    }
  }

  static async publishDocument(documentId: string, versionId: string) {
    try {
      const { error } = await supabase
        .from('document_versions')
        .update({ is_published: true })
        .eq('id', versionId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Document published successfully!",
      });
    } catch (error) {
      console.error('Error publishing document:', error);
      toast({
        title: "Error",
        description: "Failed to publish document",
        variant: "destructive"
      });
    }
  }

  static async getDocumentVersions(documentId: string) {
    try {
      const { data, error } = await supabase
        .from('document_versions')
        .select('*')
        .eq('document_id', documentId)
        .order('version_number', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching document versions:', error);
      return [];
    }
  }

  static async endEditingSession(sessionId: string) {
    try {
      const { error } = await supabase
        .from('document_edit_sessions')
        .update({ is_active: false })
        .eq('id', sessionId);

      if (error) throw error;
    } catch (error) {
      console.error('Error ending editing session:', error);
    }
  }
}
