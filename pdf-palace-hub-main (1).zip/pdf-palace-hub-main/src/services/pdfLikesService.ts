
import { supabase } from '@/integrations/supabase/client';

export const fetchLikeStatus = async (userId: string, pdfId: string): Promise<boolean> => {
  try {
    const { data, error } = await supabase
      .from('pdf_likes')
      .select('id')
      .eq('user_id', userId)
      .eq('pdf_id', pdfId)
      .maybeSingle();

    if (error) throw error;
    return !!data;
  } catch (error) {
    console.error('Error fetching like status:', error);
    return false;
  }
};

export const togglePDFLike = async (userId: string, pdfId: string, hasLiked: boolean): Promise<boolean> => {
  try {
    if (hasLiked) {
      const { error } = await supabase
        .from('pdf_likes')
        .delete()
        .eq('user_id', userId)
        .eq('pdf_id', pdfId);

      if (error) throw error;
      console.log('Successfully removed like');
      return false;
    } else {
      const { error } = await supabase
        .from('pdf_likes')
        .insert({
          user_id: userId,
          pdf_id: pdfId
        });

      if (error) throw error;
      console.log('Successfully added like');
      return true;
    }
  } catch (error) {
    console.error('Error toggling like:', error);
    throw error;
  }
};
