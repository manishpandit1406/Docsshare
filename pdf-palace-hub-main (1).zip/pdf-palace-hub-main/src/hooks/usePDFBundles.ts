import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

export interface PDFBundle {
  id: string;
  name: string;
  description?: string;
  is_public: boolean;
  user_id: string;
  created_at: string;
  updated_at: string;
  pdf_count?: number;
  cover_image_url?: string;
  thumbnail_url?: string;
}

export interface BundleItem {
  id: string;
  bundle_id: string;
  pdf_id: string;
  added_at: string;
  sort_order: number;
  pdf?: {
    id: string;
    title: string;
    description?: string;
    thumbnail_url?: string;
    file_url: string;
  };
}

export const usePDFBundles = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Fetch only user's own bundles (not public ones from others)
  const { data: bundles = [], isLoading } = useQuery({
    queryKey: ['pdf-bundles', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('pdf_library_bundles')
        .select(`
          *,
          pdf_count:pdf_bundle_items(count)
        `)
        .eq('user_id', user?.id) // Only fetch user's own bundles
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      // Transform the count data
      return data.map(bundle => ({
        ...bundle,
        pdf_count: Array.isArray(bundle.pdf_count) ? bundle.pdf_count.length : bundle.pdf_count
      })) as PDFBundle[];
    },
    enabled: !!user?.id,
  });

  // Create new bundle
  const createBundle = useMutation({
    mutationFn: async ({ 
      name, 
      description, 
      isPublic, 
      coverImageUrl, 
      thumbnailUrl,
      pdfIds = []
    }: { 
      name: string; 
      description?: string; 
      isPublic: boolean;
      coverImageUrl?: string;
      thumbnailUrl?: string;
      pdfIds?: string[];
    }) => {
      if (!user?.id) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('pdf_library_bundles')
        .insert({
          user_id: user.id,
          name,
          description,
          is_public: isPublic,
          cover_image_url: coverImageUrl,
          thumbnail_url: thumbnailUrl
        })
        .select()
        .single();

      if (error) throw error;

      // Add PDFs to bundle if provided
      if (pdfIds.length > 0) {
        const bundleItems = pdfIds.map((pdfId, index) => ({
          bundle_id: data.id,
          pdf_id: pdfId,
          sort_order: index
        }));

        const { error: itemsError } = await supabase
          .from('pdf_bundle_items')
          .insert(bundleItems);

        if (itemsError) throw itemsError;
      }

      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pdf-bundles', user?.id] });
      toast({
        title: "Bundle created",
        description: "Your PDF bundle has been created successfully"
      });
    },
    onError: (error) => {
      console.error('Error creating bundle:', error);
      toast({
        title: "Error",
        description: "Failed to create bundle",
        variant: "destructive"
      });
    }
  });

  // Update bundle
  const updateBundle = useMutation({
    mutationFn: async ({ 
      bundleId, 
      name, 
      description, 
      isPublic, 
      coverImageUrl, 
      thumbnailUrl 
    }: { 
      bundleId: string; 
      name: string; 
      description?: string; 
      isPublic: boolean;
      coverImageUrl?: string;
      thumbnailUrl?: string;
    }) => {
      const { data, error } = await supabase
        .from('pdf_library_bundles')
        .update({
          name,
          description,
          is_public: isPublic,
          cover_image_url: coverImageUrl,
          thumbnail_url: thumbnailUrl,
          updated_at: new Date().toISOString()
        })
        .eq('id', bundleId)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pdf-bundles', user?.id] });
      toast({
        title: "Bundle updated",
        description: "Your PDF bundle has been updated successfully"
      });
    },
    onError: (error) => {
      console.error('Error updating bundle:', error);
      toast({
        title: "Error",
        description: "Failed to update bundle",
        variant: "destructive"
      });
    }
  });

  // Add PDF to bundle
  const addPDFToBundle = useMutation({
    mutationFn: async ({ bundleId, pdfId }: { bundleId: string; pdfId: string }) => {
      const { error } = await supabase
        .from('pdf_bundle_items')
        .insert({
          bundle_id: bundleId,
          pdf_id: pdfId
        });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bundle-items'] });
      toast({
        title: "PDF added",
        description: "PDF has been added to the bundle"
      });
    },
    onError: (error) => {
      console.error('Error adding PDF to bundle:', error);
      toast({
        title: "Error",
        description: "Failed to add PDF to bundle",
        variant: "destructive"
      });
    }
  });

  // Remove PDF from bundle
  const removePDFFromBundle = useMutation({
    mutationFn: async ({ bundleId, pdfId }: { bundleId: string; pdfId: string }) => {
      const { error } = await supabase
        .from('pdf_bundle_items')
        .delete()
        .eq('bundle_id', bundleId)
        .eq('pdf_id', pdfId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bundle-items'] });
      toast({
        title: "PDF removed",
        description: "PDF has been removed from the bundle"
      });
    }
  });

  // Delete bundle
  const deleteBundle = useMutation({
    mutationFn: async (bundleId: string) => {
      const { error } = await supabase
        .from('pdf_library_bundles')
        .delete()
        .eq('id', bundleId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pdf-bundles', user?.id] });
      toast({
        title: "Bundle deleted",
        description: "Bundle has been deleted successfully"
      });
    }
  });

  return {
    bundles,
    isLoading,
    createBundle: createBundle.mutate,
    updateBundle: updateBundle.mutate,
    addPDFToBundle: addPDFToBundle.mutate,
    removePDFFromBundle: removePDFFromBundle.mutate,
    deleteBundle: deleteBundle.mutate,
    isCreating: createBundle.isPending,
    isUpdating: updateBundle.isPending,
    isAdding: addPDFToBundle.isPending,
    isRemoving: removePDFFromBundle.isPending,
    isDeleting: deleteBundle.isPending
  };
};

// Hook for fetching bundle items
export const useBundleItems = (bundleId: string) => {
  return useQuery({
    queryKey: ['bundle-items', bundleId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('pdf_bundle_items')
        .select(`
          *,
          pdf:pdfs (
            id,
            title,
            description,
            thumbnail_url,
            file_url
          )
        `)
        .eq('bundle_id', bundleId)
        .order('sort_order', { ascending: true });

      if (error) throw error;
      return data as BundleItem[];
    },
    enabled: !!bundleId,
  });
};
