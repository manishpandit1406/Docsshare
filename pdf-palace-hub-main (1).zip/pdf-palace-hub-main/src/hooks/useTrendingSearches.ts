
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface TrendingSearch {
  id: string;
  query: string;
  search_count: number;
  last_searched: string;
}

export const useTrendingSearches = () => {
  const [trendingSearches, setTrendingSearches] = useState<TrendingSearch[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchTrendingSearches = async () => {
    setLoading(true);
    try {
      // Use the edge function to get trending searches
      const { data, error } = await supabase.functions.invoke('get-trending-searches');

      if (error) {
        console.error('Error fetching trending searches:', error);
        setTrendingSearches([]);
      } else {
        setTrendingSearches(data || []);
      }
    } catch (error) {
      console.error('Error fetching trending searches:', error);
      setTrendingSearches([]);
    } finally {
      setLoading(false);
    }
  };

  const saveSearch = async (query: string) => {
    if (!query.trim()) return;

    try {
      // First, try to get existing search using the type assertion for now
      const { data: existing } = await (supabase as any)
        .from('trending_searches')
        .select('*')
        .eq('query', query.toLowerCase())
        .maybeSingle();

      if (existing) {
        // Update existing search
        await (supabase as any)
          .from('trending_searches')
          .update({
            search_count: existing.search_count + 1,
            last_searched: new Date().toISOString()
          })
          .eq('id', existing.id);
      } else {
        // Insert new search
        await (supabase as any)
          .from('trending_searches')
          .insert({
            query: query.toLowerCase(),
            search_count: 1
          });
      }

      // Refresh the trending searches after saving
      fetchTrendingSearches();
    } catch (error) {
      console.error('Error saving search:', error);
    }
  };

  useEffect(() => {
    fetchTrendingSearches();
  }, []);

  return {
    trendingSearches,
    loading,
    saveSearch,
    refetch: fetchTrendingSearches
  };
};
