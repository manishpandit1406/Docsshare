
import { useState, useEffect, useCallback, useRef } from 'react';
import { toast } from '@/hooks/use-toast';
import { DocumentService } from '@/services/documentService';
import { useTrendingSearches } from './useTrendingSearches';
import type { Document } from '@/types/document';

export const useDocuments = () => {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true); // Start with true for initial load
  const [error, setError] = useState<string | null>(null);
  const [initialized, setInitialized] = useState(false);
  const loadingRef = useRef(false);
  const mountedRef = useRef(true);
  const lastQueryRef = useRef<string>('');
  const { saveSearch } = useTrendingSearches();

  // Stable fetch function that doesn't depend on state
  const fetchDocuments = useCallback(async () => {
    if (loadingRef.current || !mountedRef.current) return;
    
    try {
      loadingRef.current = true;
      
      const data = await DocumentService.fetchDocuments();
      if (mountedRef.current) {
        setDocuments(data);
        setError(null);
      }
    } catch (error) {
      console.error('Error in fetchDocuments:', error);
      if (mountedRef.current) {
        setError(error instanceof Error ? error.message : 'Failed to fetch documents');
        toast({
          title: "Error",
          description: "Failed to load documents. Please try again.",
          variant: "destructive"
        });
      }
    } finally {
      loadingRef.current = false;
      if (mountedRef.current) {
        setLoading(false);
      }
    }
  }, []);

  // Stable search function with debouncing
  const searchDocuments = useCallback(async (query: string) => {
    // Prevent duplicate searches
    if (lastQueryRef.current === query) return;
    lastQueryRef.current = query;
    
    if (loadingRef.current || !mountedRef.current) return;
    
    try {
      loadingRef.current = true;
      if (mountedRef.current) setLoading(true);
      if (mountedRef.current) setError(null);

      const data = query.trim() 
        ? await DocumentService.searchDocuments(query)
        : await DocumentService.fetchDocuments();
        
      if (mountedRef.current) {
        setDocuments(data);
        // Save the search query for trending searches
        if (query.trim()) {
          saveSearch(query);
        }
      }
    } catch (error) {
      console.error('Error searching documents:', error);
      if (mountedRef.current) {
        setError(error instanceof Error ? error.message : 'Failed to search documents');
        toast({
          title: "Error",
          description: "Failed to search documents. Please try again.",
          variant: "destructive"
        });
      }
    } finally {
      loadingRef.current = false;
      if (mountedRef.current) setLoading(false);
    }
  }, [saveSearch]);

  const uploadDocument = useCallback(async (
    file: File,
    title: string,
    description: string,
    tags: string[],
    thumbnailFile?: File
  ) => {
    try {
      const data = await DocumentService.uploadDocument(file, title, description, tags, thumbnailFile);
      
      // Refresh the documents list after successful upload
      if (mountedRef.current) {
        await fetchDocuments();
      }
      
      toast({
        title: "Success",
        description: "Document uploaded successfully!"
      });

      return data;
    } catch (error) {
      console.error('Error uploading document:', error);
      toast({
        title: "Error",
        description: "Failed to upload document. Please try again.",
        variant: "destructive"
      });
      throw error;
    }
  }, [fetchDocuments]);

  const deleteDocument = useCallback(async (documentId: string) => {
    try {
      await DocumentService.deleteDocument(documentId);
      if (mountedRef.current) {
        setDocuments(prev => prev.filter(doc => doc.id !== documentId));
      }
      
      toast({
        title: "Success",
        description: "Document deleted successfully"
      });
    } catch (error) {
      console.error('Error deleting document:', error);
      toast({
        title: "Error",
        description: "Failed to delete document",
        variant: "destructive"
      });
    }
  }, []);

  // Initialize documents only once on mount
  useEffect(() => {
    if (!initialized) {
      console.log('Initializing documents...');
      setInitialized(true);
      fetchDocuments();
    }
  }, [initialized, fetchDocuments]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      mountedRef.current = false;
    };
  }, []);

  return {
    documents,
    loading,
    error,
    searchDocuments,
    deleteDocument,
    uploadDocument,
    refetch: fetchDocuments
  };
};

// Export backward compatibility hooks
export const usePDFs = useDocuments;

// Export types for backward compatibility
export type { Document as PDF };
