
import { useState, useEffect, useCallback, useRef } from 'react';
import { toast } from '@/hooks/use-toast';
import { PDFService } from '@/services/pdfService';
import type { PDF } from '@/types/pdf';

export const usePDFs = () => {
  const [pdfs, setPdfs] = useState<PDF[]>([]);
  const [loading, setLoading] = useState(true); // Start with true for initial load
  const [error, setError] = useState<string | null>(null);
  const [initialized, setInitialized] = useState(false);
  const loadingRef = useRef(false);
  const mountedRef = useRef(true);
  const lastQueryRef = useRef<string>('');

  // Stable fetch function that doesn't depend on state
  const fetchPDFs = useCallback(async () => {
    if (loadingRef.current || !mountedRef.current) return;
    
    try {
      loadingRef.current = true;
      
      const data = await PDFService.fetchPDFs();
      if (mountedRef.current) {
        setPdfs(data);
        setError(null);
      }
    } catch (error) {
      console.error('Error in fetchPDFs:', error);
      if (mountedRef.current) {
        setError(error instanceof Error ? error.message : 'Failed to fetch PDFs');
        toast({
          title: "Error",
          description: "Failed to load PDFs. Please try again.",
          variant: "destructive"
        });
      }
    } finally {
      loadingRef.current = false;
      if (mountedRef.current) {
        setLoading(false);
      }
    }
  }, []);

  // Stable search function with debouncing
  const searchPDFs = useCallback(async (query: string) => {
    // Prevent duplicate searches
    if (lastQueryRef.current === query) return;
    lastQueryRef.current = query;
    
    if (loadingRef.current || !mountedRef.current) return;
    
    try {
      loadingRef.current = true;
      if (mountedRef.current) setLoading(true);
      if (mountedRef.current) setError(null);

      const data = query.trim() 
        ? await PDFService.searchPDFs(query)
        : await PDFService.fetchPDFs();
        
      if (mountedRef.current) {
        setPdfs(data);
      }
    } catch (error) {
      console.error('Error searching PDFs:', error);
      if (mountedRef.current) {
        setError(error instanceof Error ? error.message : 'Failed to search PDFs');
        toast({
          title: "Error",
          description: "Failed to search PDFs. Please try again.",
          variant: "destructive"
        });
      }
    } finally {
      loadingRef.current = false;
      if (mountedRef.current) setLoading(false);
    }
  }, []);

  const uploadPDF = useCallback(async (
    file: File,
    title: string,
    description: string,
    tags: string[],
    thumbnailFile?: File
  ) => {
    try {
      const data = await PDFService.uploadPDF(file, title, description, tags, thumbnailFile);
      
      // Refresh the PDFs list after successful upload
      if (mountedRef.current) {
        await fetchPDFs();
      }
      
      toast({
        title: "Success",
        description: "PDF uploaded successfully!"
      });

      return data;
    } catch (error) {
      console.error('Error uploading PDF:', error);
      toast({
        title: "Error",
        description: "Failed to upload PDF. Please try again.",
        variant: "destructive"
      });
      throw error;
    }
  }, [fetchPDFs]);

  const deletePDF = useCallback(async (pdfId: string) => {
    try {
      await PDFService.deletePDF(pdfId);
      if (mountedRef.current) {
        setPdfs(prev => prev.filter(pdf => pdf.id !== pdfId));
      }
      
      toast({
        title: "Success",
        description: "PDF deleted successfully"
      });
    } catch (error) {
      console.error('Error deleting PDF:', error);
      toast({
        title: "Error",
        description: "Failed to delete PDF",
        variant: "destructive"
      });
    }
  }, []);

  // Initialize PDFs only once on mount
  useEffect(() => {
    if (!initialized) {
      console.log('Initializing PDFs...');
      setInitialized(true);
      fetchPDFs();
    }
  }, [initialized, fetchPDFs]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      mountedRef.current = false;
    };
  }, []);

  return {
    pdfs,
    loading,
    error,
    searchPDFs,
    deletePDF,
    uploadPDF,
    refetch: fetchPDFs
  };
};

// Export the PDF type for backward compatibility
export type { PDF };
