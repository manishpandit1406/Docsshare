
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { fetchLikeStatus, togglePDFLike } from '@/services/pdfLikesService';
import { fetchPDFComments, addPDFComment, deletePDFComment, type Comment } from '@/services/pdfCommentsService';
import { incrementPDFViews } from '@/services/pdfViewsService';

export const usePDFInteractions = (pdfId: string) => {
  const [hasLiked, setHasLiked] = useState(false);
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasViewed, setHasViewed] = useState(false);
  const { user } = useAuth();

  const loadLikeStatus = async () => {
    if (!user || !pdfId) return;
    
    const liked = await fetchLikeStatus(user.id, pdfId);
    setHasLiked(liked);
  };

  const loadComments = async () => {
    if (!pdfId) return;
    
    const commentsData = await fetchPDFComments(pdfId);
    setComments(commentsData);
  };

  const toggleLike = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to like PDFs",
        variant: "destructive"
      });
      return;
    }

    if (!pdfId) {
      console.error('No PDF ID provided for like toggle');
      return;
    }

    setLoading(true);
    try {
      const newLikeStatus = await togglePDFLike(user.id, pdfId, hasLiked);
      setHasLiked(newLikeStatus);
    } catch (error) {
      console.error('Error toggling like:', error);
      toast({
        title: "Error",
        description: "Failed to update like status",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const addComment = async (content: string) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to comment",
        variant: "destructive"
      });
      return;
    }

    try {
      const newComment = await addPDFComment(user.id, pdfId, content);
      // Refresh comments to get updated count and ensure proper ordering
      await loadComments();
      toast({
        title: "Comment added",
        description: "Your comment has been posted"
      });
    } catch (error) {
      console.error('Error adding comment:', error);
      toast({
        title: "Error",
        description: "Failed to add comment",
        variant: "destructive"
      });
    }
  };

  const deleteComment = async (commentId: string) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to delete comments",
        variant: "destructive"
      });
      return;
    }

    try {
      await deletePDFComment(commentId);
      // Refresh comments to update the list
      await loadComments();
      toast({
        title: "Comment deleted",
        description: "Your comment has been removed"
      });
    } catch (error) {
      console.error('Error deleting comment:', error);
      toast({
        title: "Error",
        description: "Failed to delete comment",
        variant: "destructive"
      });
    }
  };

  const handleViewIncrement = async () => {
    if (!pdfId || hasViewed) return;
    
    try {
      const wasNewView = await incrementPDFViews(pdfId, user?.id);
      setHasViewed(true);
      
      if (wasNewView) {
        console.log('Successfully recorded new view for PDF:', pdfId);
      } else {
        console.log('User has already viewed this PDF:', pdfId);
      }
    } catch (error) {
      console.error('Error tracking PDF view:', error);
    }
  };

  useEffect(() => {
    if (pdfId) {
      loadLikeStatus();
      loadComments();
      // Only increment views once per session per PDF
      if (!hasViewed) {
        handleViewIncrement();
      }
    }
  }, [pdfId, user, hasViewed]);

  return {
    hasLiked,
    comments,
    loading,
    toggleLike,
    addComment,
    deleteComment,
    refreshComments: loadComments
  };
};
