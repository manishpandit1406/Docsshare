
import { useState, useEffect, useMemo } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { usePDFs } from '@/hooks/usePDFs';
import { useWishlist } from '@/hooks/useWishlist';
import { useSubscriptions } from '@/hooks/useSubscriptions';
import { supabase } from '@/integrations/supabase/client';

interface UserProfile {
  id: string;
  full_name?: string;
  username?: string;
  avatar_url?: string;
  created_at: string;
}

export const useDashboardData = () => {
  const { user } = useAuth();
  const { pdfs, loading, error, deletePDF } = usePDFs();
  const { wishlistItems } = useWishlist();
  const { subscriptions, subscribers, loading: subscriptionsLoading } = useSubscriptions();
  
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [profileLoading, setProfileLoading] = useState(true);
  const [userStats, setUserStats] = useState({
    totalViews: 0,
    totalLikes: 0,
    totalComments: 0
  });

  // Fetch user profile data
  useEffect(() => {
    const fetchUserProfile = async () => {
      if (!user) {
        setProfileLoading(false);
        return;
      }

      try {
        const { data: profile, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (error) {
          console.error('Error fetching profile:', error);
        } else {
          setUserProfile({
            ...profile,
            created_at: user.created_at
          });
        }
      } catch (error) {
        console.error('Error fetching user profile:', error);
      } finally {
        setProfileLoading(false);
      }
    };

    fetchUserProfile();
  }, [user]);

  // Optimize userPDFs memo
  const userPDFs = useMemo(() => {
    if (!user) return [];
    return pdfs.filter(pdf => pdf.user_id === user.id);
  }, [user, pdfs]);

  // Calculate stats only when userPDFs changes
  useEffect(() => {
    if (userPDFs.length > 0) {
      const totalViews = userPDFs.reduce((sum, pdf) => sum + (pdf.views_count || 0), 0);
      const totalLikes = userPDFs.reduce((sum, pdf) => sum + (pdf.likes_count || 0), 0);
      const totalComments = userPDFs.reduce((sum, pdf) => sum + (pdf.comments_count || 0), 0);

      setUserStats({
        totalViews,
        totalLikes,
        totalComments
      });
    }
  }, [userPDFs]);

  // Create a combined user object with profile data
  const userWithProfile = useMemo(() => {
    if (!user || !userProfile) return user;
    
    return {
      ...user,
      profiles: userProfile
    };
  }, [user, userProfile]);

  return {
    user: userWithProfile,
    userPDFs,
    loading: loading || profileLoading,
    error,
    deletePDF,
    wishlistItems,
    subscriptions,
    subscribers,
    subscriptionsLoading,
    userStats,
    subscriptionsCount: subscriptions.length,
    subscribersCount: subscribers.length
  };
};
