
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

export const useWishlist = () => {
  const [wishlistItems, setWishlistItems] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();

  const fetchWishlist = async () => {
    if (!user) {
      setWishlistItems([]);
      return;
    }
    
    try {
      // Use type assertion to work around TypeScript limitations
      const { data, error } = await (supabase as any)
        .from('pdf_wishlist')
        .select('pdf_id')
        .eq('user_id', user.id);

      if (error) {
        console.error('Error fetching wishlist:', error);
        setWishlistItems([]);
        return;
      }
      
      setWishlistItems(data?.map((item: any) => item.pdf_id) || []);
    } catch (error) {
      console.error('Error fetching wishlist:', error);
      setWishlistItems([]);
    }
  };

  const addToWishlist = async (pdfId: string) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to add PDFs to your wishlist",
        variant: "destructive"
      });
      return false;
    }

    setLoading(true);
    try {
      const { error } = await (supabase as any)
        .from('pdf_wishlist')
        .insert({
          user_id: user.id,
          pdf_id: pdfId
        });

      if (error) {
        // Handle duplicate entries gracefully
        if (error.code === '23505') {
          toast({
            title: "Already in wishlist",
            description: "This PDF is already in your wishlist"
          });
          return true;
        }
        throw error;
      }
      
      setWishlistItems(prev => [...prev, pdfId]);
      toast({
        title: "Added to wishlist",
        description: "PDF has been added to your wishlist"
      });
      return true;
    } catch (error) {
      console.error('Error adding to wishlist:', error);
      toast({
        title: "Error",
        description: "Failed to add to wishlist",
        variant: "destructive"
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const removeFromWishlist = async (pdfId: string) => {
    if (!user) return false;

    setLoading(true);
    try {
      const { error } = await (supabase as any)
        .from('pdf_wishlist')
        .delete()
        .eq('user_id', user.id)
        .eq('pdf_id', pdfId);

      if (error) throw error;
      
      setWishlistItems(prev => prev.filter(id => id !== pdfId));
      toast({
        title: "Removed from wishlist",
        description: "PDF has been removed from your wishlist"
      });
      return true;
    } catch (error) {
      console.error('Error removing from wishlist:', error);
      toast({
        title: "Error",
        description: "Failed to remove from wishlist",
        variant: "destructive"
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const isInWishlist = (pdfId: string) => wishlistItems.includes(pdfId);

  useEffect(() => {
    fetchWishlist();
  }, [user]);

  return {
    wishlistItems,
    loading,
    addToWishlist,
    removeFromWishlist,
    isInWishlist,
    fetchWishlist
  };
};
