import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

interface SubscribedUser {
  id: string;
  full_name?: string;
  username?: string;
  avatar_url?: string;
  pdf_count?: number;
}

interface Subscriber {
  id: string;
  full_name?: string;
  username?: string;
  avatar_url?: string;
  pdf_count?: number;
}

export const useSubscriptions = () => {
  const { user } = useAuth();
  const [subscriptions, setSubscriptions] = useState<SubscribedUser[]>([]);
  const [subscribers, setSubscribers] = useState<Subscriber[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchSubscriptions();
      fetchSubscribers();
    }
  }, [user]);

  const fetchSubscriptions = async () => {
    if (!user) return;

    try {
      // First get the subscription relationships
      const { data: subscriptionData, error: subError } = await supabase
        .from('user_subscriptions')
        .select('subscribed_to_id')
        .eq('subscriber_id', user.id);

      if (subError) throw subError;

      if (!subscriptionData || subscriptionData.length === 0) {
        setSubscriptions([]);
        return;
      }

      // Get user IDs that current user is subscribed to
      const subscribedToIds = subscriptionData.map(sub => sub.subscribed_to_id);

      // Fetch profiles for those users
      const { data: profilesData, error: profilesError } = await supabase
        .from('profiles')
        .select('id, full_name, username, avatar_url')
        .in('id', subscribedToIds);

      if (profilesError) throw profilesError;

      // Get PDF counts for subscribed users
      const { data: pdfData } = await supabase
        .from('pdfs')
        .select('user_id')
        .in('user_id', subscribedToIds);

      // Count PDFs per user
      const pdfCounts: Record<string, number> = {};
      pdfData?.forEach(pdf => {
        pdfCounts[pdf.user_id] = (pdfCounts[pdf.user_id] || 0) + 1;
      });

      const subscriptionsData = (profilesData || []).map(profile => ({
        id: profile.id,
        full_name: profile.full_name,
        username: profile.username,
        avatar_url: profile.avatar_url,
        pdf_count: pdfCounts[profile.id] || 0
      }));

      setSubscriptions(subscriptionsData);
    } catch (error) {
      console.error('Error fetching subscriptions:', error);
      setSubscriptions([]);
    }
  };

  const fetchSubscribers = async () => {
    if (!user) return;

    try {
      // First get the subscriber relationships
      const { data: subscriberData, error: subError } = await supabase
        .from('user_subscriptions')
        .select('subscriber_id')
        .eq('subscribed_to_id', user.id);

      if (subError) throw subError;

      if (!subscriberData || subscriberData.length === 0) {
        setSubscribers([]);
        setLoading(false);
        return;
      }

      // Get user IDs that are subscribed to current user
      const subscriberIds = subscriberData.map(sub => sub.subscriber_id);

      // Fetch profiles for those users
      const { data: profilesData, error: profilesError } = await supabase
        .from('profiles')
        .select('id, full_name, username, avatar_url')
        .in('id', subscriberIds);

      if (profilesError) throw profilesError;

      // Get PDF counts for subscribers
      const { data: pdfData } = await supabase
        .from('pdfs')
        .select('user_id')
        .in('user_id', subscriberIds);

      // Count PDFs per user
      const pdfCounts: Record<string, number> = {};
      pdfData?.forEach(pdf => {
        pdfCounts[pdf.user_id] = (pdfCounts[pdf.user_id] || 0) + 1;
      });

      const subscribersData = (profilesData || []).map(profile => ({
        id: profile.id,
        full_name: profile.full_name,
        username: profile.username,
        avatar_url: profile.avatar_url,
        pdf_count: pdfCounts[profile.id] || 0
      }));

      setSubscribers(subscribersData);
    } catch (error) {
      console.error('Error fetching subscribers:', error);
      setSubscribers([]);
    } finally {
      setLoading(false);
    }
  };

  const subscribe = async (targetUserId: string) => {
    if (!user) return false;

    try {
      const { error } = await supabase
        .from('user_subscriptions')
        .insert({
          subscriber_id: user.id,
          subscribed_to_id: targetUserId
        });

      if (error) throw error;

      await fetchSubscriptions();
      await fetchSubscribers();
      return true;
    } catch (error) {
      console.error('Error subscribing:', error);
      toast({
        title: "Error",
        description: "Failed to subscribe. Please try again.",
        variant: "destructive"
      });
      return false;
    }
  };

  const unsubscribe = async (targetUserId: string) => {
    if (!user) return false;

    try {
      const { error } = await supabase
        .from('user_subscriptions')
        .delete()
        .eq('subscriber_id', user.id)
        .eq('subscribed_to_id', targetUserId);

      if (error) throw error;

      await fetchSubscriptions();
      await fetchSubscribers();
      return true;
    } catch (error) {
      console.error('Error unsubscribing:', error);
      toast({
        title: "Error",
        description: "Failed to unsubscribe. Please try again.",
        variant: "destructive"
      });
      return false;
    }
  };

  const checkSubscriptionStatus = async (targetUserId: string): Promise<boolean> => {
    if (!user) return false;

    try {
      const { data, error } = await supabase
        .from('user_subscriptions')
        .select('id')
        .eq('subscriber_id', user.id)
        .eq('subscribed_to_id', targetUserId)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      return !!data;
    } catch (error) {
      console.error('Error checking subscription status:', error);
      return false;
    }
  };

  const getSubscriberCount = async (userId: string): Promise<number> => {
    try {
      const { data, error } = await supabase
        .from('user_subscriptions')
        .select('id')
        .eq('subscribed_to_id', userId);

      if (error) throw error;
      return data?.length || 0;
    } catch (error) {
      console.error('Error getting subscriber count:', error);
      return 0;
    }
  };

  const getSubscriptionCount = async (userId: string): Promise<number> => {
    try {
      const { data, error } = await supabase
        .from('user_subscriptions')
        .select('id')
        .eq('subscriber_id', userId);

      if (error) throw error;
      return data?.length || 0;
    } catch (error) {
      console.error('Error getting subscription count:', error);
      return 0;
    }
  };

  const isSubscribed = (targetUserId: string): boolean => {
    return subscriptions.some(sub => sub.id === targetUserId);
  };

  return {
    subscriptions,
    subscribers,
    loading,
    subscribe,
    unsubscribe,
    checkSubscriptionStatus,
    getSubscriberCount,
    getSubscriptionCount,
    isSubscribed,
    refetch: () => {
      fetchSubscriptions();
      fetchSubscribers();
    }
  };
};
