
-- Create settings categories table
CREATE TABLE public.settings_categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user settings table for website-specific settings
CREATE TABLE public.user_website_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  pdf_auto_download BOOLEAN DEFAULT false,
  pdf_quality_preference TEXT DEFAULT 'medium' CHECK (pdf_quality_preference IN ('low', 'medium', 'high')),
  default_view_mode TEXT DEFAULT 'grid' CHECK (default_view_mode IN ('grid', 'list')),
  show_pdf_previews BOOLEAN DEFAULT true,
  enable_comments BOOLEAN DEFAULT true,
  enable_likes BOOLEAN DEFAULT true,
  auto_follow_uploaders BOOLEAN DEFAULT false,
  bookmark_sync BOOLEAN DEFAULT true,
  reading_progress_tracking BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

-- Create content management settings table
CREATE TABLE public.user_content_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  auto_tag_pdfs BOOLEAN DEFAULT true,
  max_upload_size_mb INTEGER DEFAULT 50,
  allowed_file_types TEXT[] DEFAULT ARRAY['pdf', 'doc', 'docx'],
  watermark_enabled BOOLEAN DEFAULT false,
  watermark_text TEXT,
  compression_enabled BOOLEAN DEFAULT true,
  ocr_enabled BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

-- Create security settings table
CREATE TABLE public.user_security_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  two_factor_enabled BOOLEAN DEFAULT false,
  login_alerts BOOLEAN DEFAULT true,
  session_timeout_minutes INTEGER DEFAULT 60,
  ip_whitelist TEXT[],
  download_restrictions BOOLEAN DEFAULT false,
  password_change_required BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable RLS on all new tables
ALTER TABLE public.settings_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_website_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_content_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_security_settings ENABLE ROW LEVEL SECURITY;

-- RLS policies for settings_categories (read-only for all authenticated users)
CREATE POLICY "Anyone can view settings categories" 
  ON public.settings_categories 
  FOR SELECT 
  TO authenticated
  USING (true);

-- RLS policies for user_website_settings
CREATE POLICY "Users can view their own website settings" 
  ON public.user_website_settings 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own website settings" 
  ON public.user_website_settings 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own website settings" 
  ON public.user_website_settings 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- RLS policies for user_content_settings
CREATE POLICY "Users can view their own content settings" 
  ON public.user_content_settings 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own content settings" 
  ON public.user_content_settings 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own content settings" 
  ON public.user_content_settings 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- RLS policies for user_security_settings
CREATE POLICY "Users can view their own security settings" 
  ON public.user_security_settings 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own security settings" 
  ON public.user_security_settings 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own security settings" 
  ON public.user_security_settings 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Insert default settings categories
INSERT INTO public.settings_categories (name, description, icon, sort_order) VALUES
('profile', 'Manage your profile information', 'User', 1),
('account', 'Account security and login settings', 'Shield', 2),
('notifications', 'Email and push notification preferences', 'Bell', 3),
('appearance', 'Theme and display settings', 'Palette', 4),
('website', 'PDF viewing and interaction preferences', 'FileText', 5),
('content', 'Upload and content management settings', 'Upload', 6),
('security', 'Advanced security and access controls', 'Lock', 7),
('privacy', 'Privacy and data settings', 'Key', 8),
('data', 'Export and manage your data', 'Download', 9);
