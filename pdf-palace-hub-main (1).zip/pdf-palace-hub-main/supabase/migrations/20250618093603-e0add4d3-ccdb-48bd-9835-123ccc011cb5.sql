
-- Create trending_searches table if it doesn't exist
CREATE TABLE IF NOT EXISTS public.trending_searches (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  query TEXT NOT NULL UNIQUE,
  search_count INTEGER DEFAULT 1,
  last_searched TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Add file_type and mime_type columns to pdfs table if they don't exist
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'pdfs' AND column_name = 'file_type') THEN
        ALTER TABLE pdfs ADD COLUMN file_type TEXT NOT NULL DEFAULT 'pdf';
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'pdfs' AND column_name = 'mime_type') THEN
        ALTER TABLE pdfs ADD COLUMN mime_type TEXT;
    END IF;
END $$;

-- Update existing records to have file_type as 'pdf'
UPDATE pdfs SET file_type = 'pdf' WHERE file_type IS NULL OR file_type = '';

-- Add constraint for supported file types (drop existing first if it exists)
DO $$
BEGIN
    BEGIN
        ALTER TABLE pdfs DROP CONSTRAINT IF EXISTS valid_file_types;
    EXCEPTION
        WHEN undefined_object THEN NULL;
    END;
    
    ALTER TABLE pdfs 
    ADD CONSTRAINT valid_file_types 
    CHECK (file_type IN ('pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'rtf', 'odt'));
END $$;

-- Update the increment function to work with documents but keep table name as pdfs
CREATE OR REPLACE FUNCTION increment_document_view_count(
  document_uuid uuid, 
  viewer_user_id uuid DEFAULT NULL::uuid, 
  viewer_ip_address inet DEFAULT NULL::inet
)
RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
  view_exists BOOLEAN := FALSE;
BEGIN
  -- Check if this user/IP has already viewed this document
  IF viewer_user_id IS NOT NULL THEN
    SELECT EXISTS(
      SELECT 1 FROM public.pdf_views 
      WHERE pdf_id = document_uuid AND user_id = viewer_user_id
    ) INTO view_exists;
  ELSIF viewer_ip_address IS NOT NULL THEN
    SELECT EXISTS(
      SELECT 1 FROM public.pdf_views 
      WHERE pdf_id = document_uuid AND ip_address = viewer_ip_address AND user_id IS NULL
    ) INTO view_exists;
  END IF;

  -- If view doesn't exist, insert new view and increment counter
  IF NOT view_exists THEN
    INSERT INTO public.pdf_views (pdf_id, user_id, ip_address)
    VALUES (document_uuid, viewer_user_id, viewer_ip_address);
    
    UPDATE public.pdfs 
    SET views_count = views_count + 1 
    WHERE id = document_uuid;
    
    RETURN TRUE;
  END IF;
  
  RETURN FALSE;
END;
$$;
