
-- Add missing columns to user_appearance_settings table
ALTER TABLE public.user_appearance_settings 
ADD COLUMN IF NOT EXISTS compact_mode BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS high_contrast BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS reduce_animations BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS custom_accent_color TEXT DEFAULT '#3b82f6',
ADD COLUMN IF NOT EXISTS sidebar_position TEXT DEFAULT 'left' CHECK (sidebar_position IN ('left', 'right')),
ADD COLUMN IF NOT EXISTS card_style TEXT DEFAULT 'default' CHECK (card_style IN ('default', 'elevated', 'outlined', 'minimal')),
ADD COLUMN IF NOT EXISTS density TEXT DEFAULT 'comfortable' CHECK (density IN ('compact', 'comfortable', 'spacious'));

-- Add missing columns to user_notification_settings table
ALTER TABLE public.user_notification_settings
ADD COLUMN IF NOT EXISTS notification_frequency TEXT DEFAULT 'immediate' CHECK (notification_frequency IN ('immediate', 'daily', 'weekly')),
ADD COLUMN IF NOT EXISTS quiet_hours_enabled BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS quiet_hours_start TIME DEFAULT '22:00',
ADD COLUMN IF NOT EXISTS quiet_hours_end TIME DEFAULT '08:00',
ADD COLUMN IF NOT EXISTS sound_enabled BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS desktop_notifications BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS mobile_notifications BOOLEAN DEFAULT true;

-- Add missing columns to user_content_settings table
ALTER TABLE public.user_content_settings
ADD COLUMN IF NOT EXISTS auto_backup BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS version_control BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS thumbnail_quality TEXT DEFAULT 'medium' CHECK (thumbnail_quality IN ('low', 'medium', 'high')),
ADD COLUMN IF NOT EXISTS auto_categorization BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS duplicate_detection BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS batch_processing BOOLEAN DEFAULT false;

-- Add missing columns to user_security_settings table
ALTER TABLE public.user_security_settings
ADD COLUMN IF NOT EXISTS suspicious_activity_alerts BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS device_management BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS api_access_enabled BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS audit_logging BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS failed_login_lockout BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS max_failed_attempts INTEGER DEFAULT 5,
ADD COLUMN IF NOT EXISTS auto_logout_inactive BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS secure_sharing_only BOOLEAN DEFAULT false;
