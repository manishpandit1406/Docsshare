
-- Create table for user notification settings
CREATE TABLE public.user_notification_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  email_new_followers BOOLEAN DEFAULT true,
  email_pdf_likes BOOLEAN DEFAULT true,
  email_pdf_comments BOOLEAN DEFAULT true,
  email_weekly_digest BOOLEAN DEFAULT false,
  email_promotions BOOLEAN DEFAULT false,
  push_new_followers BOOLEAN DEFAULT true,
  push_pdf_likes BOOLEAN DEFAULT false,
  push_pdf_comments BOOLEAN DEFAULT true,
  push_mentions BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create table for user appearance settings
CREATE TABLE public.user_appearance_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  theme VARCHAR(20) DEFAULT 'system' CHECK (theme IN ('light', 'dark', 'system')),
  language VARCHAR(10) DEFAULT 'en',
  font_size VARCHAR(20) DEFAULT 'medium' CHECK (font_size IN ('small', 'medium', 'large', 'extra-large')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create table for user privacy settings
CREATE TABLE public.user_privacy_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  profile_visibility VARCHAR(20) DEFAULT 'public' CHECK (profile_visibility IN ('public', 'followers', 'private')),
  show_email BOOLEAN DEFAULT false,
  allow_messages BOOLEAN DEFAULT true,
  index_profile BOOLEAN DEFAULT true,
  analytics_opt_out BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS on all new tables
ALTER TABLE public.user_notification_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_appearance_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_privacy_settings ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for notification settings
CREATE POLICY "Users can view their own notification settings" 
  ON public.user_notification_settings 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own notification settings" 
  ON public.user_notification_settings 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own notification settings" 
  ON public.user_notification_settings 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Create RLS policies for appearance settings
CREATE POLICY "Users can view their own appearance settings" 
  ON public.user_appearance_settings 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own appearance settings" 
  ON public.user_appearance_settings 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own appearance settings" 
  ON public.user_appearance_settings 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Create RLS policies for privacy settings
CREATE POLICY "Users can view their own privacy settings" 
  ON public.user_privacy_settings 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own privacy settings" 
  ON public.user_privacy_settings 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own privacy settings" 
  ON public.user_privacy_settings 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Create a storage bucket for user data exports
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('exports', 'exports', false, 52428800, ARRAY['application/json', 'application/zip']);

-- Create storage policy for exports bucket
CREATE POLICY "Users can upload their own exports"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'exports' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can view their own exports"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'exports' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete their own exports"
  ON storage.objects FOR DELETE
  USING (bucket_id = 'exports' AND auth.uid()::text = (storage.foldername(name))[1]);
