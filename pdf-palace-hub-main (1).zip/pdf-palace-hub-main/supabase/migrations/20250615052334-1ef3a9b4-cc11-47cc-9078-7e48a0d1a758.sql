
-- Create a table to track PDF views by users to prevent duplicate counting
CREATE TABLE public.pdf_views (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  pdf_id UUID REFERENCES public.pdfs(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  ip_address INET,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(pdf_id, user_id, ip_address)
);

-- Enable RLS on pdf_views table
ALTER TABLE public.pdf_views ENABLE ROW LEVEL SECURITY;

-- PDF views are viewable by everyone for counting purposes
CREATE POLICY "PDF views are viewable by everyone" ON public.pdf_views
  FOR SELECT USING (true);

-- Anyone can insert a view record
CREATE POLICY "Anyone can track PDF views" ON public.pdf_views
  FOR INSERT WITH CHECK (true);

-- Create function to safely increment view count
CREATE OR REPLACE FUNCTION increment_pdf_view_count(pdf_uuid UUID, viewer_user_id UUID DEFAULT NULL, viewer_ip_address INET DEFAULT NULL)
RETURNS BOOLEAN
LANGUAGE plpgsql
AS $$
DECLARE
  view_exists BOOLEAN := FALSE;
BEGIN
  -- Check if this user/IP has already viewed this PDF
  IF viewer_user_id IS NOT NULL THEN
    SELECT EXISTS(
      SELECT 1 FROM public.pdf_views 
      WHERE pdf_id = pdf_uuid AND user_id = viewer_user_id
    ) INTO view_exists;
  ELSIF viewer_ip_address IS NOT NULL THEN
    SELECT EXISTS(
      SELECT 1 FROM public.pdf_views 
      WHERE pdf_id = pdf_uuid AND ip_address = viewer_ip_address AND user_id IS NULL
    ) INTO view_exists;
  END IF;

  -- If view doesn't exist, insert new view and increment counter
  IF NOT view_exists THEN
    INSERT INTO public.pdf_views (pdf_id, user_id, ip_address)
    VALUES (pdf_uuid, viewer_user_id, viewer_ip_address);
    
    UPDATE public.pdfs 
    SET views_count = views_count + 1 
    WHERE id = pdf_uuid;
    
    RETURN TRUE;
  END IF;
  
  RETURN FALSE;
END;
$$;
