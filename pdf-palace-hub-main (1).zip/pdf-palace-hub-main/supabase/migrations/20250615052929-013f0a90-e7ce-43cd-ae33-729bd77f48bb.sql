
-- Clear all PDF view tracking data
DELETE FROM public.pdf_views;

-- Reset all PDF view counts to 0
UPDATE public.pdfs 
SET views_count = 0;

-- Reset the sequence/auto-increment if needed
-- This ensures clean start for new view tracking
