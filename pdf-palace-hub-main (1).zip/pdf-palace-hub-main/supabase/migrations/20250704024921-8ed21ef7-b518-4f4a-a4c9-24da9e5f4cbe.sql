
-- Create table for document versions to track edit history
CREATE TABLE public.document_versions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  document_id UUID NOT NULL REFERENCES public.pdfs(id) ON DELETE CASCADE,
  version_number INTEGER NOT NULL DEFAULT 1,
  content JSONB NOT NULL DEFAULT '{}',
  changes_summary TEXT,
  created_by UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  file_url TEXT,
  file_size BIGINT,
  is_published BOOLEAN DEFAULT false
);

-- Create table for document editing sessions
CREATE TABLE public.document_edit_sessions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  document_id UUID NOT NULL REFERENCES public.pdfs(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  session_data JSONB DEFAULT '{}',
  last_saved_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (now() + INTERVAL '24 hours')
);

-- Create table for document collaboration
CREATE TABLE public.document_collaborators (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  document_id UUID NOT NULL REFERENCES public.pdfs(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  permission_level TEXT NOT NULL DEFAULT 'view', -- view, comment, edit, admin
  invited_by UUID NOT NULL,
  invited_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  accepted_at TIMESTAMP WITH TIME ZONE,
  status TEXT NOT NULL DEFAULT 'pending' -- pending, accepted, declined
);

-- Add RLS policies for document versions
ALTER TABLE public.document_versions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view versions of documents they own or collaborate on" 
  ON public.document_versions 
  FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.pdfs 
      WHERE pdfs.id = document_versions.document_id 
      AND pdfs.user_id = auth.uid()
    ) OR
    EXISTS (
      SELECT 1 FROM public.document_collaborators 
      WHERE document_collaborators.document_id = document_versions.document_id 
      AND document_collaborators.user_id = auth.uid()
      AND document_collaborators.status = 'accepted'
    )
  );

CREATE POLICY "Users can create versions for documents they own or can edit" 
  ON public.document_versions 
  FOR INSERT 
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.pdfs 
      WHERE pdfs.id = document_versions.document_id 
      AND pdfs.user_id = auth.uid()
    ) OR
    EXISTS (
      SELECT 1 FROM public.document_collaborators 
      WHERE document_collaborators.document_id = document_versions.document_id 
      AND document_collaborators.user_id = auth.uid()
      AND document_collaborators.status = 'accepted'
      AND document_collaborators.permission_level IN ('edit', 'admin')
    )
  );

-- Add RLS policies for edit sessions
ALTER TABLE public.document_edit_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage their own edit sessions" 
  ON public.document_edit_sessions 
  FOR ALL 
  USING (user_id = auth.uid());

-- Add RLS policies for collaborators
ALTER TABLE public.document_collaborators ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view collaborators for documents they own or collaborate on" 
  ON public.document_collaborators 
  FOR SELECT 
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM public.pdfs 
      WHERE pdfs.id = document_collaborators.document_id 
      AND pdfs.user_id = auth.uid()
    )
  );

CREATE POLICY "Document owners can manage collaborators" 
  ON public.document_collaborators 
  FOR ALL 
  USING (
    EXISTS (
      SELECT 1 FROM public.pdfs 
      WHERE pdfs.id = document_collaborators.document_id 
      AND pdfs.user_id = auth.uid()
    )
  );

-- Add function to cleanup expired edit sessions
CREATE OR REPLACE FUNCTION cleanup_expired_edit_sessions()
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE public.document_edit_sessions 
  SET is_active = false 
  WHERE expires_at < now() AND is_active = true;
END;
$$;

-- Add function to create new document version
CREATE OR REPLACE FUNCTION create_document_version(
  p_document_id UUID,
  p_content JSONB,
  p_changes_summary TEXT DEFAULT NULL,
  p_file_url TEXT DEFAULT NULL,
  p_file_size BIGINT DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  version_id UUID;
  next_version INTEGER;
BEGIN
  -- Get next version number
  SELECT COALESCE(MAX(version_number), 0) + 1 
  INTO next_version
  FROM public.document_versions 
  WHERE document_id = p_document_id;
  
  -- Insert new version
  INSERT INTO public.document_versions (
    document_id, 
    version_number, 
    content, 
    changes_summary, 
    created_by, 
    file_url, 
    file_size
  )
  VALUES (
    p_document_id, 
    next_version, 
    p_content, 
    p_changes_summary, 
    auth.uid(), 
    p_file_url, 
    p_file_size
  )
  RETURNING id INTO version_id;
  
  RETURN version_id;
END;
$$;
