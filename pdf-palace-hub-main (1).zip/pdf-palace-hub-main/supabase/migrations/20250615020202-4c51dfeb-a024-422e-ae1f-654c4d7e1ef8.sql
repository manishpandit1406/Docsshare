
-- Create pdf_wishlist table for storing user wishlists
CREATE TABLE public.pdf_wishlist (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  pdf_id UUID REFERENCES public.pdfs(id) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, pdf_id)
);

-- Enable Row Level Security
ALTER TABLE public.pdf_wishlist ENABLE ROW LEVEL SECURITY;

-- Create policies for pdf_wishlist
CREATE POLICY "Users can view their own wishlist items" 
  ON public.pdf_wishlist 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can add to their own wishlist" 
  ON public.pdf_wishlist 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can remove from their own wishlist" 
  ON public.pdf_wishlist 
  FOR DELETE 
  USING (auth.uid() = user_id);
