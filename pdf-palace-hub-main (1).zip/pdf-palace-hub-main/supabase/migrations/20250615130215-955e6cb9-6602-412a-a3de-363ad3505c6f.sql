
-- Create a table for comment replies
CREATE TABLE public.pdf_comment_replies (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  comment_id UUID REFERENCES public.pdf_comments(id) ON DELETE CASCADE NOT NULL,
  user_id UUID NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.pdf_comment_replies ENABLE ROW LEVEL SECURITY;

-- Create policies for comment replies
CREATE POLICY "Users can view all comment replies" 
  ON public.pdf_comment_replies 
  FOR SELECT 
  USING (true);

CREATE POLICY "Users can create their own comment replies" 
  ON public.pdf_comment_replies 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own comment replies" 
  ON public.pdf_comment_replies 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own comment replies" 
  ON public.pdf_comment_replies 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Add replies_count column to pdf_comments table
ALTER TABLE public.pdf_comments ADD COLUMN replies_count INTEGER DEFAULT 0;

-- Create function to update replies count
CREATE OR REPLACE FUNCTION public.update_comment_replies_count()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.pdf_comments SET replies_count = replies_count + 1 WHERE id = NEW.comment_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.pdf_comments SET replies_count = replies_count - 1 WHERE id = OLD.comment_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$function$;

-- Create trigger for replies count
CREATE TRIGGER update_comment_replies_count_trigger
  AFTER INSERT OR DELETE ON public.pdf_comment_replies
  FOR EACH ROW EXECUTE FUNCTION public.update_comment_replies_count();
