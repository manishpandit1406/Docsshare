
-- Reset all PDF view counts to match actual unique views
UPDATE public.pdfs 
SET views_count = (
  SELECT COUNT(DISTINCT COALESCE(user_id::text, ip_address::text))
  FROM public.pdf_views 
  WHERE pdf_views.pdf_id = pdfs.id
);

-- For PDFs with no views recorded, set count to 0
UPDATE public.pdfs 
SET views_count = 0 
WHERE views_count IS NULL;

-- Create a function to recalculate view counts if needed
CREATE OR REPLACE FUNCTION recalculate_pdf_view_counts()
RETURNS VOID
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE public.pdfs 
  SET views_count = (
    SELECT COUNT(DISTINCT COALESCE(user_id::text, ip_address::text))
    FROM public.pdf_views 
    WHERE pdf_views.pdf_id = pdfs.id
  );
  
  -- Ensure no NULL view counts
  UPDATE public.pdfs 
  SET views_count = 0 
  WHERE views_count IS NULL;
END;
$$;
