
-- Create library bundles table for organizing PDFs into collections
CREATE TABLE public.pdf_library_bundles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  is_public BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create junction table for PDFs in bundles
CREATE TABLE public.pdf_bundle_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  bundle_id UUID REFERENCES public.pdf_library_bundles(id) ON DELETE CASCADE NOT NULL,
  pdf_id UUID REFERENCES public.pdfs(id) ON DELETE CASCADE NOT NULL,
  added_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  sort_order INTEGER DEFAULT 0,
  UNIQUE(bundle_id, pdf_id)
);

-- Add RLS policies for library bundles
ALTER TABLE public.pdf_library_bundles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own bundles and public bundles" 
  ON public.pdf_library_bundles 
  FOR SELECT 
  USING (auth.uid() = user_id OR is_public = true);

CREATE POLICY "Users can create their own bundles" 
  ON public.pdf_library_bundles 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own bundles" 
  ON public.pdf_library_bundles 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own bundles" 
  ON public.pdf_library_bundles 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Add RLS policies for bundle items
ALTER TABLE public.pdf_bundle_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view bundle items for accessible bundles" 
  ON public.pdf_bundle_items 
  FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.pdf_library_bundles 
      WHERE id = bundle_id 
      AND (user_id = auth.uid() OR is_public = true)
    )
  );

CREATE POLICY "Users can manage items in their own bundles" 
  ON public.pdf_bundle_items 
  FOR ALL 
  USING (
    EXISTS (
      SELECT 1 FROM public.pdf_library_bundles 
      WHERE id = bundle_id 
      AND user_id = auth.uid()
    )
  );

-- Create function to update bundle item count
CREATE OR REPLACE FUNCTION update_bundle_items_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    -- Could add a count column to bundles table if needed
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    -- Could update count here
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Add trigger for bundle items count (optional)
CREATE TRIGGER bundle_items_count_trigger
  AFTER INSERT OR DELETE ON public.pdf_bundle_items
  FOR EACH ROW EXECUTE FUNCTION update_bundle_items_count();
